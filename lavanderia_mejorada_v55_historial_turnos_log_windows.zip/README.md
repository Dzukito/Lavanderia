# Sistema local para lavandería

MVP web local para gestionar una lavandería desde una PC. Está pensado para usuarios no técnicos, con botones grandes, colores por estado y operación simple desde navegador.

## Cómo abrirlo localmente

Opción rápida:

1. Abrir `index.html` con doble clic en la computadora de la lavandería.
2. El sistema guarda los datos en el navegador mediante `localStorage`.

Opción recomendada para pruebas:

```bash
python3 -m http.server 8080
```

Luego abrir `http://localhost:8080`.

## Importante sobre navegadores y datos

Los datos se guardan en el `localStorage` del navegador que se usa. Chrome, Firefox y Edge no comparten ese almacenamiento entre sí, y cada perfil/ruta local puede tener un espacio separado. Si cargás pedidos en Chrome y abrís el mismo `index.html` en Firefox o Edge, cada navegador tendrá su propia caja y pedidos. Para respaldo contable, usá **Caja → Exportar caja histórica CSV**, que descarga un archivo `.csv` compatible con Excel en la carpeta de descargas configurada del navegador.

## Funciones incluidas

- Clientes con nombre, teléfono, dirección, notas, botón de historial de pedidos y personas autorizadas a retirar.
- Pedidos con código visible compuesto por depósito + id interno, por ejemplo `A2#1001`; si está retirado usa formato `R#1001`, y si no tiene depósito pero sigue activo muestra `Sin depósito#1001`, prendas/trabajos manuales con cantidad, estado simple, horario estimado, total calculado, pago, medio de pago y observaciones visibles.
- Servicios iniciales: valet, lavado, secado, lavado + secado y otro.
- Estados simplificados del pedido: pendiente, listo y retirado.
- Turnos rediseñados como tablero: máquinas al centro, tickets pendientes a la derecha para arrastrar y agenda diaria integrada por horarios.
- Asignación manual por arrastrar y soltar tickets a lavarropas/secadoras; también permite mover turnos dentro de la agenda diaria y consultar detalle con **Ver**.
- Capacidad configurable: lavarropas chicos, secadoras, duración de lavado y duración de secado.
- Depósito visual con ubicaciones tipo A1, A2, A3 para encontrar paquetes rápido; al hacer clic se abre la vista del pedido sin editarlo, más cartel/aviso configurable para pedidos no retirados.
- Avisos al cliente por WhatsApp Web desde un único menú: recibimos tu pedido, tu pedido está listo y retiró su pedido; el texto cambia automáticamente si está pago o pendiente.
- Caja protegida con clave inicial `1234`, editable desde configuración, ingresos, egresos, efectivo y transferencia; al marcar un pedido como abonado se genera el ingreso correspondiente, y cada movimiento diario puede borrarse si se cargó mal.
- Gastos por categorías como agua, luz, gas, insumos, alquiler y otros servicios.
- Caja diaria protegida por clave cada vez que se entra, botón visible para **Empezar nuevo día** que archiva la caja actual en caja histórica, exportación CSV de caja histórica y históricos mensuales protegidos con clave propia editable, inicial `1111`, selector de mes y año, top 5 clientes, gráfico lineal protagonista de evolución mensual, comparación anual, caja mensual visible y exportación CSV solo de la caja mensual seleccionada.
- Configuración de horarios, máquinas, ciclos, mensajes simples de WhatsApp, clave de caja, clave de históricos e importación CSV de clientes o pedidos.

## Flujo diario sugerido

1. Cargar o buscar cliente con el buscador de **Clientes**.
2. Crear pedido desde **Nuevo pedido**.
3. Elegir depósito, cargar cada prenda/trabajo con cantidad, servicio y precio unitario; el total se calcula solo.
4. Cambiar el estado con el botón **Estado** y editar prendas, precios, datos de pago y observaciones con **Editar**.
5. Usar **WhatsApp** para elegir entre recibido, listo o retirado; el sistema agrega automáticamente si está pago o pendiente.
6. Al retirar, cambiar el estado a **Retirado** y registrar el pago si corresponde.
7. Revisar caja con la clave del dueño cada vez que se entra; al cerrar el día tocar **Empezar nuevo día** para pasar los movimientos al histórico y poder exportarlo desde **Caja → Exportar caja histórica CSV**. En **Históricos**, el botón **Exportar caja mensual CSV** descarga únicamente el mes seleccionado.

### Nuevo flujo de Turnos

La sección **Turnos** quedó reducida a lo esencial:

1. A la derecha están los **tickets pendientes** en versión reducida.
2. Se puede arrastrar un ticket a un lavarropas o secadora para asignarlo.
3. Al soltarlo, se completa la agenda hacia abajo según el servicio: lavado y, si corresponde, secado.
4. Se puede mover un turno arrastrándolo a otra hora de la agenda.
5. El horario de inicio lo marca el bloque horario donde se suelta el ticket, sin depender de la hora de la PC.

Cuando un pedido pasa a **Listo** o **Retirado**, deja de aparecer como trabajo activo en Turnos, para que las máquinas se liberen visualmente.

### Importar CSV desde Configuración

En **Config. → Importar CSV** se puede elegir si el archivo contiene **Clientes** o **Pedidos**. El importador acepta archivos separados por coma o punto y coma y suma datos sin borrar lo existente.

- Clientes: columnas sugeridas `nombre`, `telefono`, `direccion`, `notas`, `autorizados`.
- Pedidos: columnas sugeridas `cliente`, `telefono`, `prenda`, `cantidad`, `precio`, `estado`, `pago`, `medio`, `deposito`, `notas`.

## Si la pantalla queda en blanco

- Actualizar el navegador de la PC de la lavandería.
- Abrirlo con el servidor local recomendado: `python3 -m http.server 8080` y entrar a `http://localhost:8080`.
- Esta versión carga `polyfills.js` antes de la agenda y la app, y los scripts principales están publicados en sintaxis ES5 para evitar errores de parseo en navegadores viejos.

## Aviso legal de depósito

El sistema incluye un texto editable para avisar condiciones de guarda de prendas no retiradas. El texto propuesto está redactado como condición comercial informada al cliente y se apoya en el deber de brindar información clara conforme la Ley 24.240 de Defensa del Consumidor. Validar el plazo y la redacción final con asesoría legal/local antes de imprimirlo o enviarlo.

Fuentes de referencia:

- Ley 24.240, texto actualizado: https://www.argentina.gob.ar/normativa/nacional/ley-24240-638/actualizacion
- Ley simple de Defensa del Consumidor: https://www.argentina.gob.ar/justicia/derechofacil/leysimple/defensa-del-consumidor

## Pruebas

```bash
npm test
node --check app.js
node --check scheduler.js
node tests/startup.test.js
```

## Nota para producción

Este MVP no usa servidor ni base de datos externa. Para uso real prolongado se recomienda agregar:

- Backup automático diario.
- Usuario y contraseña reales con hash seguro.
- Base de datos SQLite local.
- Exportación CSV/Excel.
- Instalador de escritorio con Electron o Tauri.

## Cambios de esta versión

- La sección **Métricas** pasa a llamarse **Históricos** en la navegación y en los textos visibles.
- **Históricos** incorpora un gráfico lineal principal con ingresos, egresos, diferencia neta y pedidos por mes, más comparación por mes/año y top 5 clientes.
- **Config.** permite elegir tema **Claro**, **Nocturno / oscuro** o **Sistema**; la preferencia queda guardada en el navegador.
- La importación de pedidos CSV respeta `estado`, `fecha_ingreso`, `fecha_retiro`, `pago`, `medio`, `deposito` y `notas` cuando vienen en el archivo.
- En **Caja**, los egresos se cargan solo con concepto y monto; internamente quedan como egreso en efectivo para que impacten en caja e históricos.
- En **Turnos**, la disponibilidad global de lavarropas/secadoras se calcula por superposición horaria real en el momento seleccionado, no por cualquier turno cargado en el día.
- Se agregaron ajustes responsive para pantallas medianas y chicas, con scroll horizontal controlado en tablas, gráficos y calendario cuando haga falta.

## Ajuste v4 de Turnos

- Se retiraron los carteles grandes de disponibilidad de la parte superior de Turnos.
- El cronograma diario queda como elemento central de la sección.
- Al hacer clic en una franja horaria se abre un cartel con lavadoras y secadoras disponibles para esa hora.
- Si hay un ticket pendiente seleccionado, desde ese cartel se puede ubicar el pedido en esa hora o asignarlo directamente a una máquina libre.
- Los turnos con máquina asignada se muestran en naranja; los pendientes de máquina quedan en azul.
- Las filas del cronograma fueron ajustadas para que el texto quede extendido y alineado.

## Cambios v6

- En Turnos se eliminó el bloque desplegable de Opciones manuales.
- Al abrir la asignación de máquina de un turno, ahora hay un botón **Remover del calendario** para sacar el pedido del cronograma si fue arrastrado por error. El pedido queda pendiente para volver a ubicarlo después.
- La sección Pedidos ahora muestra **todos los pedidos por defecto**, sin filtrar automáticamente por el día actual.
- Se reforzó el modo nocturno para que cards, formularios, tablas, modales, tickets, badges, turnos e históricos mantengan colores coherentes.

## Cambios v8

- En **Pedidos**, la lista principal se pagina de a 50 pedidos para evitar que la pantalla tarde cuando hay muchos registros. Abajo aparece navegación por páginas con anterior/siguiente y números.
- En **Configuración**, se puede cargar un **logo PNG**. El logo se muestra a la izquierda del encabezado “Sistema local / La Vieja Esquina” y queda guardado en el navegador.
- Se reforzó el modo nocturno en modales de estado, tarjetas activas, botones, paginación y formularios para evitar textos claros sobre fondos claros.

## Ajuste v11

- El logo PNG de cabecera se muestra más grande y se fuerza una nueva limpieza/recorte automático de logos ya guardados en el navegador mediante `logoCropVersion`.

## Roles locales y gastos privados del local

Esta versión agrega un sistema local de roles preparado para una futura autenticación real:

- **Usuario normal**: ve y usa la operación diaria: pedidos, clientes, turnos, depósito e ingreso a caja operativa si conoce la clave de caja.
- **Administrador**: ve todo lo anterior y además accede a configuración, importación CSV, históricos y gastos del local.

El rol actual se cambia desde el botón de la cabecera **Rol: ...**. Para subir de usuario normal a administrador se pide la clave admin local. La clave inicial es `1111` y se puede cambiar desde Configuración.

Las secciones privadas no aparecen en el menú del usuario normal y también quedan bloqueadas desde la lógica interna si alguien intenta forzar la vista manualmente.

### Gastos del local

La sección **Gastos local** permite registrar gastos privados del negocio separados de la caja operativa diaria. Cada gasto tiene concepto, monto, fecha y notas opcionales. Se pueden consultar por mes y por año.

En **Históricos**, estos gastos se integran como **Gastos local** para calcular la diferencia real:

```text
Diferencia real = ingresos mensuales - egresos operativos - gastos internos del local
```

La caja operativa diaria no se mezcla visualmente con estos gastos privados.

## Cambios v13

- Roles separados por vista activa: el rol **Usuario normal** ve operación diaria; el rol **Administrador** ve solo secciones administrativas. Para operar pedidos/clientes/turnos/caja desde una sesión administrativa, cambiá temporalmente el rol a Usuario normal desde el botón de rol de la cabecera.
- Vistas administrativas protegidas: Históricos, Gastos local, Configuración e Importar CSV siguen bloqueados para Usuario normal incluso si se intenta entrar manualmente desde consola.
- Los campos de fecha usados como filtros o selección principal tienen botón de calendario y bloquean escritura manual para evitar fechas mal cargadas.
- La caja operativa muestra el botón **Exportar Caja Histórica Excel**. Descarga un CSV compatible con Excel.
- La sección **Gastos del local** fue rediseñada como caja privada del administrador, con métricas del mes/año, carga de gasto privado y consulta por mes/año.
- En Turnos, cada horario del cronograma muestra un botón/ícono de disponibilidad para indicar que al tocar la celda se abre el cartel de lavadoras/secadoras libres.

## Cambios v14

- Ventana de cambio de rol simplificada con dos modos: Empleado y Administrador.
- Históricos ya no pide PIN. Sigue siendo visible solo para administrador.
- Gastos del local ahora tiene PIN propio configurable desde Configuración. Clave inicial: `2222`.
- Gastos del local incorpora gráfico anual de gastos mes a mes, resumen anual visual y tonos rojos.
- Historial global de turnos paginado de a 50 movimientos y con exportación compatible con Excel.
- Caja operativa incluye desplegable para consultar caja mensual.

## Cambios v15

- La caja mensual del empleado muestra 50 movimientos por página y permite navegar con anterior/siguiente y números.
- Los avatares de clientes usan iniciales neutras en lugar de un ícono de persona masculino.
- Configuración incorpora Lavadoras grandes. En Turnos, los ciclos de lavado pueden asignarse a Lavarropas chicos o Lavadoras grandes; las secadoras siguen separadas.

## Cambios v17 - Turnos simplificados

- La sección **Turnos** ahora usa una vista principal llamada **Plan del día**.
- Cada pedido aparece una sola vez, con sus etapas internas de lavado/secado/lavadora grande dentro de la misma tarjeta.
- La columna derecha ahora funciona como **Por ubicar**, mostrando únicamente pedidos pendientes sin turno asignado.
- Para ubicar un pedido, seleccionar **Ubicar** en la columna derecha y luego elegir una hora en **Horas rápidas**.
- Las horas rápidas muestran disponibilidad sin desplegar todos los ciclos dentro del cronograma.
- Los pedidos programados pueden sacarse del plan con **Sacar del plan**.
- Se mantiene una vista secundaria de estado de máquinas y el historial global de turnos.

## Actualización v18: Turnos en modo simple

La sección **Turnos** fue simplificada como **Trabajo del día**. La vista principal ahora es un tablero de máquinas: cada lavarropas, lavadora grande y secadora muestra si está libre u ocupada, qué pedido tiene cargado, cuándo termina y cuál es el próximo paso. Los pedidos pendientes quedan a la derecha con botón **Usar**. El flujo recomendado es: elegir un pedido pendiente, tocar **Poner acá** en una máquina libre y luego usar **Pasar a secadora**, **Marcar listo** o **Liberar** según corresponda.

## Ajuste Turnos v19

La sección Turnos se simplificó para operación diaria: primero se elige un pedido pendiente con **Poner**, luego se elige una máquina libre. Las máquinas muestran únicamente si están libres u ocupadas, el pedido actual, la hora estimada de finalización y una sola acción principal.

## Administración de máquinas

En el rol Administrador hay una sección **Máquinas** para controlar cada lavarropas, lavadora grande y secadora. Desde ahí se puede cargar estado, observaciones, repuestos y una alarma de mantenimiento con fecha y hora.

- Estado **Operativa**: la máquina queda disponible para turnos.
- Estado **En mantenimiento** o **En reparación**: la máquina se bloquea automáticamente y deja de aparecer como disponible en el sistema.
- La alarma muestra una notificación dentro del sistema cuando llega la fecha y hora programada, por ejemplo para limpieza de tambores.

La notificación aparece mientras el sistema está abierto en el navegador.
