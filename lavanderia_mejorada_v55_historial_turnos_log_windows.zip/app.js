"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var appStarted = false;
function isOpaqueExternalError(event) {
    var message = event && event.message ? event.message : "";
    return (message === "Script error." || message === "Script error") && !(event && event.filename) && !(event && event.error);
}
window.addEventListener("error", function (event) {
    if (isOpaqueExternalError(event)) {
        if (window.console && console.warn)
            console.warn("Se ignoró un error externo sin detalle del navegador/extensión.", event);
        return;
    }
    if (appStarted) {
        if (window.console && console.error)
            console.error("Error no crítico luego del arranque", event && (event.error || event.message || event));
        return;
    }
    var root = document.querySelector(".content");
    if (!root)
        return;
    var detail = event && event.message ? event.message : "Error desconocido";
    if (event && event.filename)
        detail += " (" + event.filename + ":" + (event.lineno || "?") + ":" + (event.colno || "?") + ")";
    if (event && event.error && event.error.stack)
        detail += "\n" + event.error.stack;
    root.innerHTML = "<section class=\"view active\"><div class=\"card\"><h2>No se pudo iniciar el sistema</h2><p>Prob\u00E1 actualizar el navegador o abrir el sistema con <code>python3 -m http.server 8080</code>.</p><p><strong>Detalle:</strong></p><pre class=\"error-detail\">".concat(escapeHtml(detail), "</pre></div></section>" );
});
var STORAGE_KEY = "lavanderia-local-v1";
var LOGO_CROP_VERSION = 11;
var STATES = ["Pendiente", "Listo", "Retirado"];
var defaultData = {
    settings: {
        openHour: "09:00",
        closeHour: "19:00",
        washingMinutes: 30,
        dryingMinutes: 50,
        smallWashers: 4,
        largeWashers: 1,
        dryers: 6,
        whatsappReceivedMessage: "Hola {cliente}, recibimos tu pedido {pedido} el {fecha}. Total: {total}. {pago} Te avisamos cuando esté listo para retirar. Gracias.",
        whatsappMessage: "Hola {cliente}, tu pedido {pedido} ya está listo para retirar. Total: {total}. {pago} Podés pasar cuando quieras.",
        whatsappRetiredMessage: "Hola {cliente}, tu pedido {pedido} fue marcado como *retirado* el {fecha} y quedó registrado en nuestro sistema. {pago} Cualquier consulta o inconveniente, podés escribirnos por este medio. ¡Te esperamos nuevamente!",
        storageNoticeDays: 30,
        storageNoticeText: "Condiciones de guarda: conforme las condiciones informadas al momento de recepción y el deber de información clara previsto por la Ley 24.240 de Defensa del Consumidor, los pedidos no retirados dentro de {dias} días corridos desde el aviso de disponibilidad podrán generar cargos de guarda y/o ser derivados a donación previa comunicación fehaciente al cliente. Texto sujeto a validación legal local.",
        cashPin: "1234",
        metricsPin: "1111",
        localExpensesPin: "2222",
        adminPin: "1111",
        employeePin: "0000",
        deleteOrdersPin: "1111",
        currentRole: "admin",
        theme: "light",
        logoDataUrl: "",
        logoCropVersion: 0,
    },
    services: [
        { id: 1, name: "Valet", price: 3500, wash: true, dry: true },
        { id: 2, name: "Lavado", price: 1800, wash: true, dry: false },
        { id: 3, name: "Secado", price: 1600, wash: false, dry: true },
        { id: 4, name: "Lavado + secado", price: 3000, wash: true, dry: true },
        { id: 5, name: "Otro", price: 0, wash: false, dry: false },
    ],
    clients: [
        { id: 1, name: "María Gómez", phone: "5491112345678", address: "", notes: "Prefiere WhatsApp", authorizedPickups: "Hijo: Lucas Gómez" },
        { id: 2, name: "Juan Pérez", phone: "5491198765432", address: "", notes: "", authorizedPickups: "" },
    ],
    orders: [],
    cash: [],
    cashHistory: [],
    businessExpenses: [],
    locations: buildDefaultLocations(),
    machineRecords: [],
    machineAlertLog: {},
    machineAlertNoticeLog: {},
    machineAlertDismissedByRole: { admin: {}, user: {} },
    machineHistory: [],
};
function cloneData(value) {
    try {
        return JSON.parse(JSON.stringify(value));
    }
    catch (error) {
        console.warn("No se pudo clonar la información inicial", error);
        return value;
    }
}
function safeReplaceAll(value, search, replacement) {
    return String(value).split(search).join(replacement);
}
function normalizeText(value) {
    return String(value == null ? "" : value).trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}
function normalizeOrderStatus(value, preserveCustom) {
    var raw = String(value == null ? "" : value).trim();
    var text = normalizeText(raw);
    if (!text)
        return "Pendiente";
    if (["retirado", "retirada", "entregado", "entregada", "abonado"].includes(text))
        return "Retirado";
    if (["listo", "lista", "listo para retirar", "lista para retirar"].includes(text))
        return "Listo";
    if (["pendiente", "recibido", "recibida", "nuevo", "nueva"].includes(text))
        return "Pendiente";
    return preserveCustom ? raw : "Pendiente";
}
function normalizePaymentStatus(value) {
    var raw = String(value == null ? "" : value).trim();
    var text = normalizeText(raw);
    if (["abonado", "pagado", "pago", "si", "sí", "true", "1", "ok"].includes(text))
        return "Abonado";
    return raw === "Abonado" ? "Abonado" : "Pendiente";
}
function normalizePaymentMethod(value) {
    var text = normalizeText(value);
    if (text.indexOf("trans") >= 0 || text.indexOf("mp") >= 0 || text.indexOf("mercado") >= 0)
        return "Transferencia";
    return "Efectivo";
}
function parseCsvDateValue(value, fallback) {
    var raw = String(value == null ? "" : value).trim();
    if (!raw)
        return fallback || "";
    var iso = new Date(raw);
    if (!isNaN(iso.getTime()))
        return iso.toISOString();
    var match = raw.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})(?:[ T](\d{1,2}):(\d{2}))?$/);
    if (match) {
        var year = Number(match[3]);
        if (year < 100)
            year += 2000;
        var parsed = new Date(year, Number(match[2]) - 1, Number(match[1]), Number(match[4] || 12), Number(match[5] || 0), 0, 0);
        if (!isNaN(parsed.getTime()))
            return parsed.toISOString();
    }
    return fallback || "";
}
function buildDefaultLocations() {
    var rows = ["A", "B", "C", "D", "E", "F"];
    var locations = [];
    for (var rowIndex = 0; rowIndex < rows.length; rowIndex += 1) {
        for (var slot = 1; slot <= 6; slot += 1) {
            locations.push({ id: locations.length + 1, code: rows[rowIndex] + slot });
        }
    }
    return locations;
}
function forEachNode(nodes, callback) {
    for (var index = 0; index < nodes.length; index += 1) callback(nodes[index], index);
}
function listFrom(nodes) {
    var list = [];
    for (var index = 0; index < nodes.length; index += 1) list.push(nodes[index]);
    return list;
}
function storageGet(key) {
    try {
        return window.localStorage ? window.localStorage.getItem(key) : null;
    }
    catch (error) {
        console.warn("No se pudo leer el almacenamiento local. El sistema queda en modo temporal.", error);
        return null;
    }
}
function storageSet(key, value) {
    try {
        if (window.localStorage)
            window.localStorage.setItem(key, value);
    }
    catch (error) {
        console.warn("No se pudo guardar en el almacenamiento local. Revisá permisos del navegador.", error);
    }
}
function leftPad(value, length, character) {
    var text = String(value || "");
    var pad = character || "0";
    while (text.length < length)
        text = pad + text;
    return text;
}
function formDataToObject(form) {
    var result = {};
    if (window.FormData) {
        try {
            var data = new FormData(form);
            if (data.forEach) {
                data.forEach(function (value, key) { result[key] = value; });
                return result;
            }
        }
        catch (error) {}
    }
    forEachNode(form.elements || [], function (field) {
        if (field.name && !field.disabled)
            result[field.name] = field.value;
    });
    return result;
}
function formatShortDateTime(date) {
    var value = new Date(date);
    if (isNaN(value.getTime()))
        return "Sin estimar";
    return "".concat(leftPad(value.getDate(), 2, "0"), "/").concat(leftPad(value.getMonth() + 1, 2, "0"), "/").concat(String(value.getFullYear()).slice(-2), " ").concat(leftPad(value.getHours(), 2, "0"), ":").concat(leftPad(value.getMinutes(), 2, "0"));
}
function flatten(list) {
    return Array.prototype.concat.apply([], list);
}
var state = loadState();
var currentView = "dashboard";
var cashUnlocked = false;
var businessExpensesUnlocked = true;
var sessionLoggedIn = false;
var sessionRole = "";
var sessionIsDev = false;
var adminOrdersUnlocked = false;
var selectedMachine = null;
var scheduleWeekStart = currentWeekStart(new Date()).toISOString().slice(0, 10);
var scheduleSelectedDate = localDateInput();
var selectedScheduleTicketId = 0;
var draggedScheduleTicketId = 0;
var draggedScheduleCycle = null;
var scheduleViewMode = "day";
var scheduleSlotMinutes = 30;
var scheduleSimpleMode = true;
var schedulePreview = null;
var selectedMetricsMonth = "";
var selectedMetricsYear = "";
var selectedMetricsCompareMonth = "";
var selectedCashMonth = localDateInput().slice(0, 7);
var cashMonthlyPage = 1;
var cashMonthlyPageSize = 50;
var cashMonthlyPanelOpen = false;
var scheduleHistoryPage = 1;
var scheduleHistoryPageSize = 50;
var machineHistoryPage = 1;
var machineHistoryPageSize = 50;
function mergeLocations(defaultLocations, savedLocations) {
    if (savedLocations === void 0) { savedLocations = []; }
    var result = [];
    function addLocation(location) {
        if (!location || !location.code)
            return;
        for (var index = 0; index < result.length; index += 1) {
            if (result[index].code === location.code)
                return;
        }
        result.push({ id: result.length + 1, code: location.code });
    }
    defaultLocations.forEach(addLocation);
    (savedLocations || []).forEach(addLocation);
    return result;
}
function currentWeekStart(reference) {
    var day = reference.getDay() || 7;
    var monday = new Date(reference);
    monday.setDate(reference.getDate() - day + 1);
    monday.setHours(0, 0, 0, 0);
    return monday;
}
function loadState() {
    var defaults = cloneData(defaultData);
    var saved = storageGet(STORAGE_KEY);
    if (!saved)
        return defaults;
    var parsed;
    try {
        parsed = JSON.parse(saved);
    }
    catch (error) {
        console.warn("No se pudieron leer los datos guardados. Se cargan datos iniciales.", error);
        return defaults;
    }
    var merged = __assign(__assign(__assign({}, defaults), parsed), { settings: __assign(__assign({}, defaults.settings), (parsed.settings || {})), services: parsed.services && parsed.services.length ? parsed.services : defaults.services, clients: parsed.clients && parsed.clients.length ? parsed.clients : defaults.clients, orders: parsed.orders || defaults.orders, cash: parsed.cash || defaults.cash, businessExpenses: parsed.businessExpenses || defaults.businessExpenses, locations: mergeLocations(defaults.locations, parsed.locations), cashHistory: parsed.cashHistory || defaults.cashHistory, machineRecords: parsed.machineRecords || defaults.machineRecords, machineAlertLog: parsed.machineAlertLog || defaults.machineAlertLog, machineAlertNoticeLog: parsed.machineAlertNoticeLog || defaults.machineAlertNoticeLog, machineAlertDismissedByRole: parsed.machineAlertDismissedByRole || defaults.machineAlertDismissedByRole, machineHistory: parsed.machineHistory || defaults.machineHistory });
    merged.machineAlertDismissedByRole = __assign({ admin: {}, user: {} }, merged.machineAlertDismissedByRole || {});
    if (!parsed.settings || !Object.prototype.hasOwnProperty.call(parsed.settings, "metricsPin") || parsed.settings.metricsPin === "1234")
        merged.settings.metricsPin = defaults.settings.metricsPin;
    if (!merged.settings.adminPin)
        merged.settings.adminPin = merged.settings.metricsPin || defaults.settings.adminPin;
    if (!merged.settings.localExpensesPin)
        merged.settings.localExpensesPin = defaults.settings.localExpensesPin;
    if (!merged.settings.employeePin)
        merged.settings.employeePin = defaults.settings.employeePin;
    if (!merged.settings.deleteOrdersPin)
        merged.settings.deleteOrdersPin = defaults.settings.deleteOrdersPin;
    if (!["admin", "user"].includes(merged.settings.currentRole))
        merged.settings.currentRole = "admin";
    if (!parsed.settings || parsed.settings.whatsappReceivedMessage === "Hola {cliente}. Recibimos tu pedido {pedido}. {pago}. Te avisamos cuando esté listo. Gracias." || parsed.settings.whatsappReceivedMessage === "Hola {cliente}. Recibimos tu pedido {pedido}. Total: {total}. {pago} Te avisamos cuando esté listo para retirar. Gracias." )
        merged.settings.whatsappReceivedMessage = defaults.settings.whatsappReceivedMessage;
    if (!parsed.settings || parsed.settings.whatsappMessage === "Hola {cliente}. Tu pedido {pedido} ya está listo para retirar. {pago}. Te esperamos." || parsed.settings.whatsappMessage === "Hola {cliente}. Tu pedido {pedido} ya está listo para retirar. Total: {total}. {pago} Podés pasar cuando quieras." )
        merged.settings.whatsappMessage = defaults.settings.whatsappMessage;
    if (!parsed.settings || parsed.settings.whatsappRetiredMessage === "Hola {cliente}. Dejamos constancia de que retiró su pedido {pedido} el {fecha}. {pago}. Muchas gracias." || parsed.settings.whatsappRetiredMessage === "Hola {cliente}. Ya registramos la entrega de tu pedido {pedido}. {pago} Muchas gracias por elegirnos." )
        merged.settings.whatsappRetiredMessage = defaults.settings.whatsappRetiredMessage;
    merged.clients = merged.clients.map(function (client) { return (__assign({ authorizedPickups: "" }, client)); });
    merged.orders = merged.orders.map(function (order) {
        var paymentStatus = normalizePaymentStatus(order.paymentStatus || (order.status === "Abonado" ? "Abonado" : "Pendiente"));
        var status = normalizeOrderStatus(order.status || "Pendiente", true);
        var items = order.items && order.items.length ? order.items : [{ name: serviceSummary(order), serviceId: order.serviceId, price: Number(order.total || 0), quantity: 1 }];
        items = items.map(function (item) { return __assign({ quantity: 1 }, item); });
        return ensureOrderCycleIds(__assign(__assign({}, order), { status: status, paymentStatus: paymentStatus, paymentMethod: normalizePaymentMethod(order.paymentMethod || "Efectivo"), cycles: (order.cycles || []).map(function (cycle) { return __assign(__assign({}, cycle), { machine: canonicalMachineName(cycle.machine || "") }); }), items: items, retrievedAt: order.retrievedAt || (status === "Retirado" ? order.updatedAt || new Date().toISOString() : "") }));
    });
    return merged;
}
function saveState() {
    storageSet(STORAGE_KEY, JSON.stringify(state));
}
var ADMIN_VIEWS = { cashReports: true, businessExpenses: true, machines: true, adminOrders: true, settings: true };
var USER_VIEWS = { dashboard: true, orders: true, clients: true, schedule: true, storage: true, cash: true };
var PRIVATE_ACTIONS = { importCsvData: true, saveSettings: true, resetDemo: true, exportHistoricalCash: true, exportMonthlyCash: true, saveBusinessExpense: true, deleteBusinessExpense: true, exportGlobalTurnHistory: true, deleteOrderAdmin: true, confirmDeleteOrderAdmin: true, openAddBusinessExpenseModal: true, saveMachineRecord: true, exportMachineHistory: true, unlockAdminOrders: true };
var DEV_ACTIONS = { importCsvData: true, resetDemo: true };
var MASTER_ADMIN_PIN = "devseijo2121";
function currentRole() {
    return sessionLoggedIn && sessionRole === "admin" ? "admin" : "user";
}
function isAdmin() {
    return sessionLoggedIn && currentRole() === "admin";
}
function isDevAdmin() {
    return isAdmin() && sessionIsDev;
}
function isPrivateView(view) {
    return Boolean(ADMIN_VIEWS[view]);
}
function isUserOperationalView(view) {
    return Boolean(USER_VIEWS[view]);
}
function isViewAllowed(view) {
    return isAdmin() ? Boolean(ADMIN_VIEWS[view]) : Boolean(USER_VIEWS[view]);
}
function fallbackViewForRole() {
    return isAdmin() ? "cashReports" : "orders";
}
function accessDeniedHtml() {
    return '<div class="card access-denied"><h2>Acceso restringido</h2><p>Esta sección no está disponible para la sesión actual.</p></div>';
}
function requireAdminAccess() {
    if (isAdmin())
        return true;
    alert("Acceso restringido: necesitás rol Administrador.");
    return false;
}
function requireDevAccess() {
    if (isDevAdmin())
        return true;
    alert("Esta acción está reservada para soporte técnico.");
    return false;
}
function updateRoleUi() {
    var admin = isAdmin();
    forEachNode(document.querySelectorAll(".nav-button"), function (button) {
        var view = button.getAttribute("data-view");
        button.hidden = !isViewAllowed(view);
    });
    forEachNode(document.querySelectorAll("[data-admin-only]"), function (node) {
        node.hidden = !admin;
    });
    var rolePill = document.getElementById("rolePill");
    if (rolePill) {
        rolePill.textContent = "Rol: " + (admin ? "Administrador" : "Empleado");
        rolePill.classList.toggle("admin", admin);
        rolePill.classList.toggle("user", !admin);
    }
    document.documentElement.setAttribute("data-role", admin ? "admin" : "user");
}
function resolvedThemePreference(preference) {
    return preference === "dark" ? "dark" : "light";
}
function applyThemePreference() {
    var preference = state && state.settings && state.settings.theme === "dark" ? "dark" : "light";
    if (state && state.settings)
        state.settings.theme = preference;
    var resolved = resolvedThemePreference(preference);
    if (document && document.documentElement) {
        document.documentElement.setAttribute("data-theme", resolved);
        document.documentElement.setAttribute("data-theme-preference", preference);
    }
    updateThemeSwitcherUi(preference);
}
function updateThemeSwitcherUi(preference) {
    var selected = preference === "dark" ? "dark" : "light";
    forEachNode(document.querySelectorAll("[data-theme-value]"), function (button) {
        button.classList.toggle("active", button.getAttribute("data-theme-value") === selected);
    });
}
function setThemePreference(value) {
    var next = value === "dark" ? "dark" : "light";
    state.settings.theme = next;
    saveState();
    applyThemePreference();
}
function setupSystemThemeListener() {}
function updateBranding() {
    var logo = document.getElementById("businessLogo");
    if (!logo)
        return;
    var value = state && state.settings ? state.settings.logoDataUrl || "" : "";
    if (value) {
        logo.src = value;
        logo.hidden = false;
        if (state.settings && value.indexOf("data:image/png") === 0 && state.settings.logoCropVersion !== LOGO_CROP_VERSION) {
            state.settings.logoCropVersion = LOGO_CROP_VERSION;
            state.settings.logoAutoCropped = true;
            trimLogoDataUrl(value, function (trimmed) {
                if (trimmed && trimmed !== value) {
                    state.settings.logoDataUrl = trimmed;
                    logo.src = trimmed;
                    refreshLogoPreview();
                }
                saveState();
            });
        }
    }
    else {
        logo.removeAttribute("src");
        logo.hidden = true;
    }
}
function money(value) {
    var amount = Number(value || 0);
    try {
        if (window.Intl && window.Intl.NumberFormat)
            return new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(amount);
    }
    catch (error) {}
    return "$ " + Math.round(amount);
}
function formatDateTime(value) {
    if (!value)
        return "Sin estimar";
    return formatShortDateTime(value);
}
function normalizeClass(text) {
    return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ /g, "-");
}
function nextId(list) {
    return list.length ? Math.max.apply(Math, list.map(function (item) { return item.id; })) + 1 : 1;
}
function nextOrderNumber() {
    return leftPad(1000 + nextId(state.orders), 4, "0");
}
function getClient(id) {
    return state.clients.find(function (client) { return client.id === Number(id); });
}
function getService(id) {
    return state.services.find(function (service) { return service.id === Number(id); });
}
function getOrder(id) {
    return state.orders.find(function (order) { return order.id === Number(id); });
}
function serviceSummary(order) {
    var service = getService(order.serviceId);
    return service ? service.name : "Servicio eliminado";
}
function orderClient(order) {
    var client = getClient(order.clientId);
    return client ? client.name : "Cliente eliminado";
}
function escapeHtml(value) {
    return String(value == null ? "" : value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
function availableLocations(currentOrderId) {
    if (currentOrderId === void 0) { currentOrderId = null; }
    var busy = {};
    state.orders.filter(function (order) { return order.id !== Number(currentOrderId) && order.location && order.status !== "Retirado"; }).forEach(function (order) {
        busy[order.location] = true;
    });
    return state.locations.filter(function (location) { return !busy[location.code]; });
}
function createOrderSchedule(service, createdAt) {
    return { estimate: createdAt || new Date().toISOString(), cycles: [] };
}
function nextCycleId(orderId, index) {
    return "c" + String(orderId || "nuevo") + "-" + String(index || 0) + "-" + String(new Date().getTime());
}
function ensureOrderCycleIds(order) {
    (order.cycles || []).forEach(function (cycle, index) {
        if (!cycle.cycleId)
            cycle.cycleId = nextCycleId(order.id, index);
    });
    return order;
}
function refreshOrderEstimate(order) {
    var latest = order.createdAt || new Date().toISOString();
    (order.cycles || []).forEach(function (cycle) {
        if (cycle.end && new Date(cycle.end) > new Date(latest))
            latest = cycle.end;
    });
    order.estimate = latest;
}
function currentWeekDays(reference) {
    if (reference === void 0) { reference = new Date(); }
    var monday = currentWeekStart(reference);
    var days = [];
    for (var index = 0; index < 5; index += 1) {
        var date = new Date(monday);
        date.setDate(monday.getDate() + index);
        days.push(date);
    }
    return days;
}
function dateKey(date) {
    return new Date(date).toISOString().slice(0, 10);
}
function hourLabel(hour) {
    return "".concat(leftPad(hour, 2, "0"), ":00");
}
function cycleOverlapsHour(cycle, day, hour) {
    var start = new Date(cycle.start);
    var end = new Date(cycle.end);
    var blockStart = new Date(day);
    blockStart.setHours(hour, 0, 0, 0);
    var blockEnd = new Date(blockStart);
    blockEnd.setHours(hour + 1, 0, 0, 0);
    return start < blockEnd && end > blockStart;
}
function monthKey(value) {
    return new Date(value).toISOString().slice(0, 7);
}
function allCashEntries() {
    var archived = [];
    (state.cashHistory || []).forEach(function (day) {
        (day.entries || []).forEach(function (entry) { archived.push(__assign({ archivedDay: day.closedAt }, entry)); });
    });
    return __spreadArray(__spreadArray([], state.cash || [], true), archived, true);
}
function allBusinessExpenses() {
    return (state.businessExpenses || []).map(function (expense) { return __assign({}, expense); });
}
function businessExpensesForMonth(month) {
    return allBusinessExpenses().filter(function (expense) { return monthKey(expense.date) === month; }).sort(function (a, b) { return new Date(b.date) - new Date(a.date); });
}
function businessExpensesForYear(year) {
    return allBusinessExpenses().filter(function (expense) { return String(expense.date || "").slice(0, 4) === String(year); }).sort(function (a, b) { return new Date(b.date) - new Date(a.date); });
}
function businessExpenseTotal(list) {
    return (list || []).reduce(function (sum, expense) { return sum + Number(expense.amount || 0); }, 0);
}
function topMetrics(values, limit) {
    var list = [];
    for (var key in values) {
        if (Object.prototype.hasOwnProperty.call(values, key))
            list.push(values[key]);
    }
    list.sort(function (a, b) { return b.count - a.count; });
    return list.slice(0, limit || 3);
}
function emptyHourlyCounts() {
    var hours = [];
    for (var hour = 0; hour < 24; hour += 1)
        hours.push({ hour: hour, label: leftPad(hour, 2, "0") + ":00", count: 0 });
    return hours;
}
function monthlyCashSummary() {
    var summary = {};
    allCashEntries().forEach(function (entry) {
        var key = monthKey(entry.date);
        if (!summary[key])
            summary[key] = { income: 0, expense: 0, businessExpense: 0, cash: 0, transfer: 0 };
        var amount = Number(entry.amount || 0);
        if (entry.type === "Ingreso")
            summary[key].income += amount;
        if (entry.type === "Egreso")
            summary[key].expense += amount;
        if (entry.method === "Efectivo")
            summary[key].cash += entry.type === "Ingreso" ? amount : -amount;
        if (entry.method === "Transferencia")
            summary[key].transfer += entry.type === "Ingreso" ? amount : -amount;
    });
    allBusinessExpenses().forEach(function (expense) {
        var key = monthKey(expense.date);
        if (!summary[key])
            summary[key] = { income: 0, expense: 0, businessExpense: 0, cash: 0, transfer: 0 };
        summary[key].businessExpense += Number(expense.amount || 0);
    });
    operationalOrders().forEach(function (order) {
        var orderMonth = monthKey(order.createdAt);
        if (!summary[orderMonth])
            summary[orderMonth] = { income: 0, expense: 0, businessExpense: 0, cash: 0, transfer: 0 };
    });
    var months = [];
    for (var month in summary) {
        if (Object.prototype.hasOwnProperty.call(summary, month))
            months.push(month);
    }
    months.sort();
    return months.map(function (month, index) {
        var values = summary[month];
        var operationalBalance = values.income - values.expense;
        var balance = operationalBalance - Number(values.businessExpense || 0);
        var previousValues = index > 0 ? summary[months[index - 1]] : null;
        var previous = previousValues ? previousValues.income - previousValues.expense - Number(previousValues.businessExpense || 0) : null;
        var diff = previous ? Math.round(((balance - previous) / Math.abs(previous)) * 100) : null;
        var monthOrders = operationalOrders().filter(function (order) { return monthKey(order.createdAt) === month; });
        var hourlyCounts = emptyHourlyCounts();
        var clients = {};
        monthOrders.forEach(function (order) {
            var client = getClient(order.clientId);
            var clientKey = String(order.clientId || orderClient(order));
            if (!clients[clientKey])
                clients[clientKey] = { id: order.clientId, name: client ? client.name : orderClient(order), count: 0 };
            clients[clientKey].count += 1;
            var hour = new Date(order.createdAt).getHours();
            if (hourlyCounts[hour])
                hourlyCounts[hour].count += 1;
        });
        var orderTotal = monthOrders.reduce(function (sum, order) { return sum + Number(order.total || 0); }, 0);
        var averageTicket = monthOrders.length ? Math.round(orderTotal / monthOrders.length) : 0;
        var margin = values.income ? Math.round((balance / values.income) * 100) : 0;
        return __assign(__assign({ month: month }, values), { operationalBalance: operationalBalance, balance: balance, diff: diff, orders: monthOrders.length, orderTotal: orderTotal, averageTicket: averageTicket, margin: margin, topClients: topMetrics(clients, 5), hourlyCounts: hourlyCounts });
    });
}
function signedCashAmount(entry) {
    var amount = Number(entry.amount || 0);
    return entry.type === "Egreso" ? -Math.abs(amount) : amount;
}
function moneySigned(value) {
    var amount = Number(value || 0);
    return amount < 0 ? "-" + money(Math.abs(amount)) : money(amount);
}
function historicalCashRows() {
    var rows = [];
    (state.cashHistory || []).forEach(function (day) {
        (day.entries || []).forEach(function (entry) {
            rows.push(__assign({ closedAt: day.closedAt }, entry));
        });
    });
    rows.sort(function (a, b) { return new Date(b.closedAt || b.date) - new Date(a.closedAt || a.date); });
    return rows;
}
function cashRowsForMonth(month) {
    var rows = [];
    (state.cash || []).forEach(function (entry) { return rows.push(__assign({ closedAt: "Caja actual" }, entry)); });
    historicalCashRows().forEach(function (entry) { return rows.push(entry); });
    rows = rows.filter(function (entry) { return monthKey(entry.date) === month; });
    rows.sort(function (a, b) { return new Date(b.date) - new Date(a.date); });
    return rows;
}
function monthlyCashHtml(month) {
    var rows = cashRowsForMonth(month);
    return '<details class="monthly-cash-panel"><summary class="secondary history-toggle">Ver caja mensual</summary><div class="toolbar compact-toolbar"><h3>Caja mensual ' + escapeHtml(month || "sin mes") + '</h3><button class="secondary" data-action="exportMonthlyCash" data-month="' + escapeHtml(month || "") + '">Exportar caja mensual</button></div><div class="table-wrap"><table class="cash-history-table"><thead><tr><th>Cierre</th><th>Movimiento</th><th>Tipo</th><th>Categoría</th><th>Descripción</th><th>Medio</th><th>Importe</th></tr></thead><tbody>'.concat(rows.map(function (entry) { return '<tr class="'.concat(entry.type === "Ingreso" ? "cash-income-row" : "cash-expense-row", '"><td>').concat((entry.closedAt === "Caja actual" ? "Caja actual" : formatDateTime(entry.closedAt)), '</td><td>').concat(formatDateTime(entry.date), '</td><td>').concat(escapeHtml(entry.type), '</td><td>').concat(escapeHtml(entry.category), '</td><td>').concat(escapeHtml(entry.description), '</td><td>').concat(paymentMethodLabel(entry.method), '</td><td class="').concat(signedCashAmount(entry) < 0 ? 'negative-amount' : '', '">').concat(moneySigned(signedCashAmount(entry)), '</td></tr>'); }).join('') || '<tr><td colspan="7">No hay caja archivada para este mes.</td></tr>', '</tbody></table></div></details>');
}
function metricYearOptions(rows) {
    var years = {};
    rows.forEach(function (row) { years[row.month.slice(0, 4)] = true; });
    var list = [];
    for (var year in years) { if (Object.prototype.hasOwnProperty.call(years, year)) list.push(year); }
    list.sort();
    return list;
}
function metricsControlsHtml(rows, selectedMonth, selectedYear, compareMonth) {
    var years = metricYearOptions(rows);
    var yearValue = selectedYear || (selectedMonth ? selectedMonth.slice(0, 4) : (years[years.length - 1] || ""));
    var monthOptions = rows.map(function (row) { return '<option value="'.concat(escapeHtml(row.month), '" ').concat(row.month === selectedMonth ? 'selected' : '', '>').concat(escapeHtml(row.month), '</option>'); }).join('');
    var compareOptions = '<option value="">Sin comparación</option>' + rows.map(function (row) { return '<option value="'.concat(escapeHtml(row.month), '" ').concat(row.month === compareMonth ? 'selected' : '', '>').concat(escapeHtml(row.month), '</option>'); }).join('');
    var yearOptions = '<option value="all" ' + (yearValue === "all" ? 'selected' : '') + '>Todos los años</option>' + years.map(function (year) { return '<option value="'.concat(escapeHtml(year), '" ').concat(year === yearValue ? 'selected' : '', '>').concat(escapeHtml(year), '</option>'); }).join('');
    return '<div class="metrics-controls"><label>Año<select data-metrics-year>'.concat(yearOptions, '</select></label><label>Mes principal<select data-metrics-month>').concat(monthOptions, '</select></label><label>Comparar con<select data-metrics-compare>').concat(compareOptions, '</select></label></div>');
}
function monthlyPerformanceLineChart(rows, selectedMonth, compareMonth, selectedYear) {
    var chartRows = rows.filter(function (row) { return selectedYear === "all" || !selectedYear || row.month.slice(0, 4) === selectedYear; });
    if (!chartRows.length)
        chartRows = rows;
    if (!chartRows.length)
        chartRows = [{ month: "Sin datos", balance: 0, income: 0, expense: 0 }];
    var values = chartRows.map(function (row) { return Number(row.balance || 0); });
    var max = Math.max.apply(Math, values.concat([0]));
    var min = Math.min.apply(Math, values.concat([0]));
    if (max === min) { max += 1; min -= 1; }
    var chartTop = 30;
    var chartBottom = 250;
    var chartLeft = 76;
    var chartRight = 760;
    var span = max - min;
    var xFor = function (index) { return chartRows.length === 1 ? chartLeft : chartLeft + index * ((chartRight - chartLeft) / (chartRows.length - 1)); };
    var yFor = function (value) { return chartBottom - ((Number(value || 0) - min) / span) * (chartBottom - chartTop); };
    var points = chartRows.map(function (row, index) { return Math.round(xFor(index)) + "," + Math.round(yFor(row.balance)); }).join(" ");
    var yTicks = [];
    for (var tick = 0; tick <= 4; tick += 1) {
        var value = min + (span / 4) * tick;
        yTicks.push({ value: value, y: Math.round(yFor(value)) });
    }
    var yLines = yTicks.map(function (tick) { return '<g><line class="grid-line" x1="'.concat(chartLeft, '" y1="').concat(tick.y, '" x2="').concat(chartRight, '" y2="').concat(tick.y, '"></line><text x="6" y="').concat(tick.y + 4, '">').concat(escapeHtml(money(tick.value)), '</text></g>'); }).join("");
    var dots = chartRows.map(function (row, index) {
        var selected = row.month === selectedMonth ? ' selected-point' : row.month === compareMonth ? ' compare-point' : '';
        return '<circle class="performance-point'.concat(selected, '" cx="').concat(Math.round(xFor(index)), '" cy="').concat(Math.round(yFor(row.balance)), '" r="').concat(row.month === selectedMonth || row.month === compareMonth ? 7 : 4, '"><title>').concat(escapeHtml(row.month), ': resultado real ').concat(escapeHtml(money(row.balance)), ', ingresos ').concat(escapeHtml(money(row.income)), ', egresos operativos ').concat(escapeHtml(money(row.expense)), ', gastos local ').concat(escapeHtml(money(row.businessExpense || 0)), '</title></circle>');
    }).join("");
    var xLabels = chartRows.map(function (row, index) {
        var anchor = index === 0 ? "start" : index === chartRows.length - 1 ? "end" : "middle";
        return '<text class="x-axis-label" x="' + Math.round(xFor(index)) + '" y="278" text-anchor="' + anchor + '">' + escapeHtml(row.month.slice(5, 7) + '/' + row.month.slice(2, 4)) + '</text>';
    }).join("");
    var selected = rows.find(function (row) { return row.month === selectedMonth; });
    var compare = rows.find(function (row) { return row.month === compareMonth; });
    var comparison = compare && selected ? '<div class="comparison-chip"><strong>Comparación</strong><span>'.concat(escapeHtml(selected.month), ': ').concat(money(selected.balance), '</span><span>').concat(escapeHtml(compare.month), ': ').concat(money(compare.balance), '</span><em>Diferencia: ').concat(money(selected.balance - compare.balance), '</em></div>') : '<div class="comparison-chip muted-chip">Elegí otro mes para comparar el resultado.</div>';
    return '<article class="performance-line-card"><div class="metric-month-head"><div><h3>Evolución mensual del resultado</h3><p>El eje X muestra los meses y el eje Y muestra el resultado real: ingresos menos egresos operativos y gastos internos del local.</p></div>'.concat(comparison, '</div><div class="performance-chart-wrap"><span class="y-axis-title">Resultado real ($)</span><svg viewBox="0 0 800 300" role="img" aria-label="Evolución mensual del resultado"><g class="y-axis-labels">').concat(yLines, '</g><line class="axis-line" x1="').concat(chartLeft, '" y1="').concat(chartBottom, '" x2="').concat(chartRight, '" y2="').concat(chartBottom, '"></line><line class="axis-line" x1="').concat(chartLeft, '" y1="').concat(chartTop, '" x2="').concat(chartLeft, '" y2="').concat(chartBottom, '"></line><polyline points="').concat(points, '"></polyline><g class="performance-points">').concat(dots, '</g><g class="performance-x-labels">').concat(xLabels, '</g></svg><div class="x-axis-title">Meses del año</div></div></article>');
}
function monthSelectorHtml(rows, selectedMonth) {
    return metricsControlsHtml(rows, selectedMonth, selectedMetricsYear, selectedMetricsCompareMonth);
}
function annualSummaryRows(rows) {
    var years = {};
    rows.forEach(function (row) {
        var year = row.month.slice(0, 4);
        if (!years[year])
            years[year] = { year: year, income: 0, expense: 0, businessExpense: 0, operationalBalance: 0, balance: 0, orders: 0, months: 0 };
        years[year].income += Number(row.income || 0);
        years[year].expense += Number(row.expense || 0);
        years[year].businessExpense += Number(row.businessExpense || 0);
        years[year].operationalBalance += Number(row.operationalBalance || 0);
        years[year].balance += Number(row.balance || 0);
        years[year].orders += Number(row.orders || 0);
        years[year].months += 1;
    });
    var list = [];
    for (var year in years) {
        if (Object.prototype.hasOwnProperty.call(years, year)) {
            years[year].averageBalance = years[year].months ? Math.round(years[year].balance / years[year].months) : 0;
            list.push(years[year]);
        }
    }
    list.sort(function (a, b) { return Number(a.year) - Number(b.year); });
    return list;
}
function annualComparisonHtml(rows) {
    var years = annualSummaryRows(rows);
    return '<article class="metric-month-card annual-comparison-card"><h3>Comparación anual</h3><div class="table-wrap"><table><thead><tr><th>Año</th><th>Ingresos</th><th>Egresos operativos</th><th>Gastos local</th><th>Diferencia real</th><th>Pedidos</th><th>Promedio mensual</th></tr></thead><tbody>' + (years.map(function (row) { return '<tr><td><strong>' + escapeHtml(row.year) + '</strong></td><td>' + money(row.income) + '</td><td>' + money(row.expense) + '</td><td>' + money(row.businessExpense || 0) + '</td><td class="' + (row.balance < 0 ? 'negative-amount' : '') + '">' + money(row.balance) + '</td><td>' + row.orders + '</td><td>' + money(row.averageBalance) + '</td></tr>'; }).join('') || '<tr><td colspan="7">Todavía no hay datos anuales.</td></tr>') + '</tbody></table></div></article>';
}
function messageForOrder(order, type) {
    var templates = {
        received: state.settings.whatsappReceivedMessage,
        ready: state.settings.whatsappMessage,
        retired: state.settings.whatsappRetiredMessage,
    };
    var isPaid = order.paymentStatus === "Abonado";
    var unpaidText = type === "ready" ? "Al retirar, el total a pagar es ".concat(money(order.total), ".") : "Queda pendiente de pago ".concat(money(order.total), ".");
    var paymentText = isPaid ? "El pago ya figura abonado." : unpaidText;
    var eventDate = type === "received"
        ? (order.createdAt || new Date().toISOString())
        : type === "retired"
            ? (order.retrievedAt || new Date().toISOString())
            : (order.estimate || new Date().toISOString());
    return safeReplaceAll(safeReplaceAll(safeReplaceAll(safeReplaceAll(safeReplaceAll(safeReplaceAll(templates[type], "{cliente}", orderClient(order)), "{pedido}", customerOrderCode(order)), "{fecha}", formatDateTime(eventDate)), "{estimado}", formatDateTime(order.estimate)), "{pago}", paymentText), "{total}", money(order.total));
}
function safeRenderView(id, callback) {
    try {
        callback();
    }
    catch (error) {
        var target = document.getElementById(id);
        if (target)
            target.innerHTML = "<div class=\"card\"><h2>La secci\u00F3n no pudo cargar</h2><pre class=\"error-detail\">".concat(escapeHtml(error && (error.stack || error.message) || error), "</pre></div>");
        if (window.console && console.error)
            console.error("No se pudo renderizar " + id, error);
    }
}
function render() {
    if (!sessionLoggedIn) {
        showLoginScreen();
        return;
    }
    hideLoginScreen();
    if (!isViewAllowed(currentView))
        currentView = fallbackViewForRole();
    updateBranding();
    updateRoleUi();
    updateThemeSwitcherUi(state.settings.theme === "dark" ? "dark" : "light");
    forEachNode(document.querySelectorAll(".view"), function (view) { return view.classList.toggle("active", view.id === currentView); });
    forEachNode(document.querySelectorAll(".nav-button"), function (button) { return button.classList.toggle("active", button.getAttribute("data-view") === currentView); });
    if (isAdmin()) {
        ["dashboard", "orders", "clients", "schedule", "storage", "cash"].forEach(function (id) {
            var node = document.getElementById(id);
            if (node) node.innerHTML = accessDeniedHtml();
        });
        safeRenderView("cashReports", renderCashReports);
        safeRenderView("businessExpenses", renderBusinessExpenses);
        safeRenderView("machines", renderMachines);
        safeRenderView("adminOrders", renderAdminOrders);
        safeRenderView("settings", renderSettings);
    }
    else {
        safeRenderView("dashboard", renderDashboard);
        safeRenderView("orders", renderOrders);
        safeRenderView("clients", renderClients);
        safeRenderView("schedule", renderSchedule);
        safeRenderView("storage", renderStorage);
        safeRenderView("cash", renderCash);
        ["cashReports", "businessExpenses", "machines", "adminOrders", "settings"].forEach(function (id) {
            var node = document.getElementById(id);
            if (node) node.innerHTML = accessDeniedHtml();
        });
    }
    setTimeout(function () { checkMaintenanceAlerts(false); }, 0);
}
function setView(view) {
    if (!isViewAllowed(view)) {
        alert(isAdmin() ? "Estás en modo Administrador. Cambiá a Empleado para usar la operación diaria." : "Acceso restringido: necesitás rol Administrador.");
        currentView = fallbackViewForRole();
        render();
        return;
    }
    if (view === "cash")
        cashUnlocked = false;
    currentView = view;
    render();
}
forEachNode(document.querySelectorAll(".nav-button"), function (button) { return button.addEventListener("click", function () { return setView(button.getAttribute("data-view")); }); });
document.addEventListener("submit", function (event) {
    if (event.target && event.target.id === "loginForm") {
        event.preventDefault();
        handleLogin();
    }
});
document.addEventListener("click", function (event) {
    var target = event.target.closest("[data-action]");
    if (!target)
        return;
    var action = target.getAttribute("data-action");
    var id = target.getAttribute("data-id");
    var handlers = {
        newOrder: openOrderModal,
        newClient: openClientModal,
        editClient: function () { return openClientModal(id); },
        clientHistory: function () { return openClientHistoryModal(id); },
        viewOrder: function () { return openOrderViewModal(id); },
        editOrderStatus: function () { return openOrderEditModal(id); },
        orderState: function () { return openOrderStateModal(id); },
        dashboardTab: function () { return setDashboardTab(target.getAttribute("data-tab")); },
        clearOrderDate: clearOrderDate,
        prevOrdersPage: function () { return changeOrdersPage(-1); },
        nextOrdersPage: function () { return changeOrdersPage(1); },
        ordersPage: function () { return setOrdersPage(target.getAttribute("data-page")); },
        prevCashMonthlyPage: function () { return changeCashMonthlyPage(-1); },
        nextCashMonthlyPage: function () { return changeCashMonthlyPage(1); },
        cashMonthlyPage: function () { return setCashMonthlyPage(target.getAttribute("data-page")); },
        prevAdminOrdersPage: function () { return changeAdminOrdersPage(-1); },
        nextAdminOrdersPage: function () { return changeAdminOrdersPage(1); },
        adminOrdersPage: function () { return setAdminOrdersPage(target.getAttribute("data-page")); },
        confirmDeleteOrderAdmin: function () { return confirmDeleteOrderAdmin(id); },
        setTheme: function () { return setThemePreference(target.getAttribute("data-theme-value")); },
        prevScheduleHistoryPage: function () { return changeScheduleHistoryPage(-1); },
        nextScheduleHistoryPage: function () { return changeScheduleHistoryPage(1); },
        scheduleHistoryPage: function () { return setScheduleHistoryPage(target.getAttribute("data-page")); },
        prevMachineHistoryPage: function () { return changeMachineHistoryPage(-1); },
        nextMachineHistoryPage: function () { return changeMachineHistoryPage(1); },
        machineHistoryPage: function () { return setMachineHistoryPage(target.getAttribute("data-page")); },
        removeLogo: removeLogo,
        whatsapp: function () { return openWhatsappMenu(id); },
        storageNotice: function () { return openStorageNoticeModal(id); },
        openStorageOrder: function () { return openStorageOrder(id); },
        prevWeek: function () { return moveScheduleWeek(-7); },
        nextWeek: function () { return moveScheduleWeek(7); },
        todayWeek: function () { return setScheduleDate(localDateInput()); },
        scheduleViewMode: function () { return setScheduleViewMode(target.getAttribute("data-mode")); },
        openMachineBlockModal: openMachineBlockModal,
        saveMachineBlock: function () { return saveMachineBlock(target); },
        rescheduleActiveOrders: rescheduleActiveOrders,
        openFreeSlotFinder: openFreeSlotFinder,
        openUnscheduledOrdersModal: openUnscheduledOrdersModal,
        openSlotAvailability: function () { return openScheduleSlotAvailabilityModal(target.getAttribute("data-slot-start")); },
        assignSelectedTicketToSlot: function () { return assignSelectedTicketToSlot(target.getAttribute("data-slot-start")); },
        assignSelectedTicketToSlotMachine: function () { return assignSelectedTicketToSlotMachine(target.getAttribute("data-slot-start"), target.getAttribute("data-machine"), target.getAttribute("data-machine-type")); },
        openCycleEdit: function () { return openMachineAssignModal(id, target.getAttribute("data-cycle-id")); },
        saveCycleEdit: function () { return saveCycleEdit(target); },
        saveCycleMachine: function () { return saveCycleMachine(target); },
        clearCycleMachine: function () { return clearCycleMachine(id, target.getAttribute("data-cycle-id")); },
        removeOrderSchedule: function () { return removeOrderSchedule(id); },
        deleteCycle: function () { return deleteCycle(id, target.getAttribute("data-cycle-id")); },
        shiftCycle: function () { return shiftCycleMinutes(id, target.getAttribute("data-cycle-id"), target.getAttribute("data-minutes")); },
        moveCycleNextFree: function () { return moveCycleToNextFreeSlot(id, target.getAttribute("data-cycle-id")); },
        moveCycleFreeMachine: function () { return moveCycleToFreeMachine(id, target.getAttribute("data-cycle-id")); },
        finishCycleNow: function () { return finishCycleNow(id, target.getAttribute("data-cycle-id")); },
        assignNextOrder: assignNextOrder,
        openAssignAtSuggestedSlot: function () { return openAssignAtSuggestedSlot(target.getAttribute("data-type")); },
        confirmSuggestedSlot: function () { return confirmSuggestedSlot(target); },
        toggleScheduleAdvancedMode: toggleScheduleAdvancedMode,
        sendWhatsapp: function () { return sendWhatsapp(id, target.getAttribute("data-message-type")); },
        copyWhatsapp: function () { return copyWhatsapp(id, target.getAttribute("data-message-type")); },
        copyNotice: copyVisibleNotice,
        sendStorageNotice: function () { return sendStorageNotice(id); },
        machineEdit: function () { return openMachineModal(target.getAttribute("data-machine")); },
        saveMachineSlot: function () { return saveMachineSlot(target); },
        saveQuickMachineSlot: function () { return saveQuickMachineSlot(target); },
        selectScheduleTicket: function () { return selectScheduleTicket(id); },
        assignSelectedTicketToMachine: function () { return assignSelectedTicketToMachine(target.getAttribute("data-machine"), target.getAttribute("data-machine-type")); },
        putSelectedTicketOnMachineNow: function () { return putSelectedTicketOnMachineNow(target.getAttribute("data-machine"), target.getAttribute("data-machine-type")); },
        openPutOrderOnMachine: function () { return openPutOrderOnMachineModal(target.getAttribute("data-machine"), target.getAttribute("data-machine-type")); },
        putOrderOnMachine: function () { return putOrderOnMachine(target); },
        openQuickPlaceOrder: function () { return openQuickPlaceOrderModal(id); },
        quickPlaceOrder: function () { return quickPlaceOrder(target); },
        openTimelineSlotModal: function () { return openTimelineSlotModal(target.getAttribute("data-slot-start"), target.getAttribute("data-group")); },
        startOrderAtTimelineSlot: function () { return startOrderAtTimelineSlot(target); },
        openPassToDryer: function () { return openPassToDryerModal(id, target.getAttribute("data-cycle-id")); },
        passToDryer: function () { return passToDryer(target); },
        markOrderReadyFromCycle: function () { return markOrderReadyFromCycle(id, target.getAttribute("data-cycle-id")); },
        scheduleTicketDetail: function () { return openOrderViewModal(id); },
        calculateScheduleFromSelectedTime: calculateScheduleFromSelectedTime,
        cashIncome: function () { return openCashModal("Ingreso"); },
        cashExpense: function () { return openCashModal("Egreso"); },
        closeCashDay: closeCashDay,
        exportHistoricalCash: exportHistoricalCash,
        exportGlobalTurnHistory: exportGlobalTurnHistory,
        exportMachineHistory: exportMachineHistory,
        exportMonthlyCash: function () { return exportMonthlyCash(target.getAttribute("data-month")); },
        importCsvData: importCsvData,
        unlockCash: unlockCash,
        unlockBusinessExpenses: unlockBusinessExpenses,
        unlockAdminOrders: unlockAdminOrders,
        handleLogin: handleLogin,
        logout: logout,
        saveSettings: saveSettings,
        resetDemo: resetDemo,
        openRoleModal: openRoleModal,
        saveRole: function () { return saveRole(target); },
        saveBusinessExpense: function () { return saveBusinessExpense(target); },
        saveMachineRecord: function () { return saveMachineRecord(target); },
        ackMaintenanceAlert: function () { return ackMaintenanceAlert(target); },
        deleteBusinessExpense: function () { return deleteBusinessExpense(id); },
        openAddBusinessExpenseModal: openAddBusinessExpenseModal,
        deleteOrderAdmin: function () { return openDeleteOrderAdminModal(id); },
        openDatePicker: function () { return openDatePickerById(target.getAttribute("data-target")); },
    };
    if (PRIVATE_ACTIONS[action] && !requireAdminAccess())
        return;
    if (DEV_ACTIONS[action] && !requireDevAccess())
        return;
    if (handlers[action])
        handlers[action]();
});
document.addEventListener("click", function (event) {
    if (event.target.matches("[data-close-modal]"))
        closeModal();
});
document.addEventListener("click", function (event) {
    if (isCalendarOnlyInput(event.target))
        openDatePickerInput(event.target);
});
document.addEventListener("keydown", function (event) {
    if (isCalendarOnlyInput(event.target) && !["Tab", "Escape"].includes(event.key))
        event.preventDefault();
});
document.addEventListener("paste", function (event) {
    if (isCalendarOnlyInput(event.target))
        event.preventDefault();
});
document.addEventListener("input", function (event) {
    if (event.target.matches("[data-search-orders], [data-order-date]"))
        applyOrderFilters();
    if (event.target.matches("[data-search-clients]"))
        filterClients(event.target.value);
    if (event.target.matches("[data-search-admin-orders]"))
        filterAdminOrdersDelete(event.target.value);
    if (event.target.matches("[data-preview-field]"))
        updateSchedulePreview(event.target.closest(".modal-backdrop"));
});
document.addEventListener("change", function (event) {
    if (event.target.matches("[data-logo-upload]")) {
        if (!requireDevAccess())
            return;
        importLogoFile(event.target);
        return;
    }
    if (event.target.matches("[data-metrics-month]")) {
        selectedMetricsMonth = event.target.value;
        renderCashReports();
        return;
    }
    if (event.target.matches("[data-metrics-year]")) {
        selectedMetricsYear = event.target.value;
        renderCashReports();
        return;
    }
    if (event.target.matches("[data-metrics-compare]")) {
        selectedMetricsCompareMonth = event.target.value;
        renderCashReports();
        return;
    }
    if (event.target.matches("[data-business-expense-filter]")) {
        renderBusinessExpenses();
        return;
    }
    if (event.target.matches("[data-cash-month-filter]")) {
        selectedCashMonth = event.target.value || localDateInput().slice(0, 7);
        cashMonthlyPage = 1;
        cashMonthlyPanelOpen = true;
        renderCash();
        return;
    }
    if (event.target.matches("[data-schedule-week], [data-schedule-date]")) {
        setScheduleDate(event.target.value);
        return;
    }
    if (event.target.matches("[data-schedule-slot]")) {
        scheduleSlotMinutes = Number(event.target.value || 30);
        renderSchedule();
        return;
    }
    if (event.target.matches("[data-preview-field]")) {
        updateSchedulePreview(event.target.closest(".modal-backdrop"));
        return;
    }
    if (!event.target.matches("[data-service-select]"))
        return;
    var selected = event.target.options[event.target.selectedIndex];
    var form = event.target.closest("form");
    var priceInput = form ? form.querySelector("[name='total']") : null;
    if (priceInput && selected && selected.getAttribute("data-price"))
        priceInput.value = selected.getAttribute("data-price");
});
document.addEventListener("dragstart", function (event) {
    var ticket = event.target.closest("[data-drag-ticket]");
    var cycle = event.target.closest("[data-drag-cycle]");
    if (ticket) {
        document.body.classList.add("schedule-dragging");
        draggedScheduleTicketId = Number(ticket.getAttribute("data-order-id") || 0);
        selectedScheduleTicketId = draggedScheduleTicketId;
        if (event.dataTransfer)
            event.dataTransfer.setData("text/plain", "ticket:" + draggedScheduleTicketId);
        ticket.className += " dragging";
        return;
    }
    if (cycle) {
        document.body.classList.add("schedule-dragging");
        draggedScheduleCycle = { orderId: cycle.getAttribute("data-id"), cycleId: cycle.getAttribute("data-cycle-id") };
        if (event.dataTransfer)
            event.dataTransfer.setData("text/plain", "cycle:" + draggedScheduleCycle.orderId + ":" + draggedScheduleCycle.cycleId);
    }
});
document.addEventListener("dragend", function () {
    document.body.classList.remove("schedule-dragging");
    draggedScheduleTicketId = 0;
    draggedScheduleCycle = null;
    forEachNode(document.querySelectorAll(".dragging, .drop-hover"), function (node) {
        node.className = node.className.replace(/\s?dragging/g, "").replace(/\s?drop-hover/g, "");
    });
});
document.addEventListener("dragover", function (event) {
    var dropTime = event.target.closest("[data-drop-time]");
    if (dropTime)
        event.preventDefault();
});
document.addEventListener("drop", function (event) {
    document.body.classList.remove("schedule-dragging");
    var dropTime = event.target.closest("[data-drop-time]");
    var data = event.dataTransfer ? event.dataTransfer.getData("text/plain") : "";
    if (dropTime) {
        event.preventDefault();
        if (draggedScheduleCycle) {
            moveCycleToTime(draggedScheduleCycle.orderId, draggedScheduleCycle.cycleId, dropTime.getAttribute("data-slot-start"));
            return;
        }
        assignOrderToCalendarTime(draggedScheduleTicketId || Number(String(data).replace("ticket:", "")), dropTime.getAttribute("data-slot-start"));
    }
});
function fourDigitId(id) {
    return leftPad(id, 4, "0");
}
function orderDisplayCode(order) {
    if (order.status === "Retirado")
        return "R#" + fourDigitId(order.id);
    if (!order.location)
        return "Sin depósito#" + fourDigitId(order.id);
    return "".concat(order.location, "#").concat(fourDigitId(order.id));
}
function customerOrderCode(order) {
    return order && order.id ? "#" + fourDigitId(order.id) : "Sin pedido";
}
function itemLineTotal(item) {
    return Number(item.price || 0) * Number(item.quantity || 1);
}
function orderItemsTotal(items) {
    return (items || []).reduce(function (sum, item) { return sum + itemLineTotal(item); }, 0);
}
function itemSummary(order) {
    return (order.items || []).map(function (item) {
        var quantity = Number(item.quantity || 1);
        var prefix = quantity > 1 ? quantity + " x " : "";
        return "".concat(prefix).concat(item.name, " (").concat(money(itemLineTotal(item)), ")");
    }).join(" · ") || serviceSummary(order);
}
function orderItemsHtml(order) {
    var items = order.items || [];
    return "<div class=\"order-items-list\">".concat(items.map(function (item) {
        return "<div class=\"order-item-line\"><span>".concat(Number(item.quantity || 1), " x ").concat(escapeHtml(item.name), "</span><small>").concat(escapeHtml(item.serviceName || serviceSummary(order)), " · unit. ").concat(money(item.price), "</small><strong>").concat(money(itemLineTotal(item)), "</strong></div>");
    }).join("") || "<p>Sin prendas cargadas.</p>", "</div>");
}
function paymentBadge(order) {
    var status = order.paymentStatus || "Pendiente";
    return "<span class=\"payment-badge ".concat(status === "Abonado" ? "paid" : "due", "\">").concat(status === "Abonado" ? "✅ Abonado" : "🟠 Pendiente", "</span>");
}
function paymentMethodLabel(method) {
    return method === "Transferencia" ? "Transferencia" : "Efectivo";
}
function nextFreeLocation() {
    return (availableLocations()[0] && availableLocations()[0].code) || "";
}
var dashboardTab = "Pendiente";
var ordersPage = 1;
var ordersPageSize = 50;
var ordersLastQuery = "";
var ordersLastDate = "";
var adminOrdersDeletePage = 1;
var adminOrdersDeletePageSize = 50;
var adminOrdersDeleteQuery = "";
function operationalOrders() {
    return state.orders.filter(function (order) { return !order.block; });
}
function orderGroup(order) {
    if (order.status === "Retirado")
        return "Retirado";
    if (order.status === "Listo")
        return "Listo";
    return "Pendiente";
}
function ordersByGroup(group) {
    return operationalOrders().filter(function (order) { return orderGroup(order) === group; }).sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
}
function dashboardOrdersByGroup(group) {
    var list = ordersByGroup(group);
    if (group === "Retirado") {
        var today = localDateInput();
        list = list.filter(function (order) { return order.retrievedAt && dateKey(order.retrievedAt) === today; });
    }
    return list;
}
function dashboardGroupTitle(group) {
    return group === "Retirado" ? "Pedidos retirados hoy" : "Pedidos " + group.toLowerCase() + "s";
}
function setDashboardTab(tab) {
    dashboardTab = tab;
    renderDashboard();
}
function localDateInput(date) {
    if (date === void 0) { date = new Date(); }
    return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}
function clearOrderDate() {
    var input = document.getElementById("orderDateFilter");
    if (input)
        input.value = "";
    applyOrderFilters();
}
function applyOrderFilters() {
    var query = (document.getElementById("orderSearch") && document.getElementById("orderSearch").value) || "";
    var date = (document.getElementById("orderDateFilter") && document.getElementById("orderDateFilter").value) || "";
    filterOrders(query, date);
}
function renderDashboard() {
    var groups = ["Pendiente", "Listo", "Retirado"];
    var selectedOrders = dashboardOrdersByGroup(dashboardTab);
    document.getElementById("dashboard").innerHTML = "\n    <div class=\"simple-home\">\n      <div class=\"home-actions\"><button class=\"primary big-action\" data-action=\"newOrder\">+ Nuevo pedido</button><button class=\"secondary big-action\" data-action=\"newClient\">+ Nuevo cliente</button></div>\n      <div class=\"tabs\">".concat(groups.map(function (group) { return "<button class=\"tab-button ".concat(dashboardTab === group ? "active" : "", "\" data-action=\"dashboardTab\" data-tab=\"").concat(group, "\">").concat(group, "<strong>").concat(dashboardOrdersByGroup(group).length, "</strong></button>"); }).join(""), "</div>\n      ").concat(orderCards(selectedOrders, dashboardGroupTitle(dashboardTab), true), "\n    </div>");
}
function renderOrders() {
    ordersPage = 1;
    ordersLastQuery = "";
    ordersLastDate = "";
    document.getElementById("orders").innerHTML = `
    <div class="card section-card">
      <div class="toolbar"><div><p class="eyebrow-dark">Operación</p><h2>Pedidos</h2></div><button class="primary" data-action="newOrder">+ Nuevo pedido</button></div>
      <div class="filters-row"><input id="orderSearch" data-search-orders placeholder="Buscar por depósito, cliente, teléfono, estado u observaciones" /><label class="date-picker-label">Fecha<span class="calendar-input-wrap"><input id="orderDateFilter" class="date-picker-input" data-order-date type="date" value="" inputmode="none" /><button class="calendar-open-button" type="button" data-action="openDatePicker" data-target="orderDateFilter" aria-label="Abrir calendario">📅</button></span></label><button class="secondary" data-action="clearOrderDate">Ver todos</button></div>
    </div>
    <div id="ordersTable"></div>
  `;
    renderOrdersList();
}
function filteredOrdersList(query, date) {
    var q = String(query || "").toLowerCase();
    return operationalOrders().filter(function (order) {
        var matchesQuery = "".concat(order.number, " ").concat(order.location || "", " ").concat(orderClient(order), " ").concat(orderDisplayCode(order), " ").concat((getClient(order.clientId) && getClient(order.clientId).phone) || "", " ").concat(order.status, " ").concat(order.notes || "").toLowerCase().includes(q);
        var matchesDate = !date || dateKey(order.createdAt) === date;
        return matchesQuery && matchesDate;
    }).sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
}
function renderOrdersList() {
    var target = document.getElementById("ordersTable");
    if (!target)
        return;
    var filtered = filteredOrdersList(ordersLastQuery, ordersLastDate);
    var totalPages = Math.max(1, Math.ceil(filtered.length / ordersPageSize));
    if (ordersPage > totalPages)
        ordersPage = totalPages;
    if (ordersPage < 1)
        ordersPage = 1;
    var start = (ordersPage - 1) * ordersPageSize;
    var pageOrders = filtered.slice(start, start + ordersPageSize);
    var baseTitle = ordersLastDate || ordersLastQuery ? "Pedidos filtrados" : "Todos los pedidos";
    var title = baseTitle + " · " + String(filtered.length) + " total" + (filtered.length === 1 ? "" : "es");
    target.innerHTML = orderCards(pageOrders, title, false) + ordersPaginationHtml(filtered.length, ordersPage, totalPages, start, pageOrders.length);
}
function ordersPaginationHtml(total, page, totalPages, start, count) {
    if (!total)
        return "";
    var from = start + 1;
    var to = start + count;
    var firstPage = Math.max(1, page - 4);
    var lastPage = Math.min(totalPages, firstPage + 9);
    firstPage = Math.max(1, lastPage - 9);
    var buttons = [];
    for (var item = firstPage; item <= lastPage; item += 1) {
        buttons.push('<button class="page-button ' + (item === page ? 'active' : '') + '" data-action="ordersPage" data-page="' + item + '">' + item + '</button>');
    }
    return '<div class="orders-pagination"><div><strong>Mostrando ' + from + '-' + to + '</strong><span> de ' + total + ' pedidos</span></div><div class="page-controls"><button class="secondary" data-action="prevOrdersPage" ' + (page <= 1 ? 'disabled' : '') + '>‹ Anterior</button>' + buttons.join('') + '<button class="secondary" data-action="nextOrdersPage" ' + (page >= totalPages ? 'disabled' : '') + '>Siguiente ›</button></div></div>';
}
function setOrdersPage(page) {
    ordersPage = Number(page || 1);
    renderOrdersList();
}
function changeOrdersPage(delta) {
    ordersPage += Number(delta || 0);
    renderOrdersList();
}
window.filterOrders = function (query, date) {
    if (date === void 0) { date = ""; }
    ordersLastQuery = query || "";
    ordersLastDate = date || "";
    ordersPage = 1;
    renderOrdersList();
};
function orderCards(orders, title, compact) {
    if (compact === void 0) { compact = false; }
    return "\n    <div class=\"card orders-panel\">\n      <h2>".concat(escapeHtml(title), "</h2>\n      <div class=\"order-card-list\">").concat(orders.map(function (order) { return "\n        <article class=\"order-card ".concat(normalizeClass(orderGroup(order)), "\">\n          <div class=\"order-main\"><strong class=\"order-code\">").concat(escapeHtml(orderDisplayCode(order)), "</strong><span class=\"badge ").concat(normalizeClass(orderGroup(order)), "\">").concat(escapeHtml(orderGroup(order)), "</span></div>\n          <div><strong>").concat(escapeHtml(orderClient(order)), "</strong><br><small>Ingreso: ").concat(formatDateTime(order.createdAt), " · Retiro: ").concat(order.retrievedAt ? formatDateTime(order.retrievedAt) : "Pendiente", "</small></div>\n          ").concat(orderItemsHtml(order), "\n          <p class=\"order-notes\">").concat(escapeHtml(order.notes || "Sin observaciones"), "</p>\n          <div class=\"order-meta\"><span>Pago: ").concat(paymentBadge(order), " ").concat(paymentMethodLabel(order.paymentMethod), "</span><span>Total: ").concat(money(order.total), "</span></div>\n          <div class=\"actions\"><button class=\"secondary\" data-action=\"orderState\" data-id=\"").concat(order.id, "\">Estado</button><button class=\"secondary\" data-action=\"editOrderStatus\" data-id=\"").concat(order.id, "\">Editar</button><button class=\"success\" data-action=\"whatsapp\" data-id=\"").concat(order.id, "\">WhatsApp</button></div>\n        </article>"); }).join("") || "<p>No hay pedidos para mostrar.</p>", "</div>\n    </div>");
}
function ordersTable(orders, title) {
    return orderCards(orders, title, false);
}
function renderAdminOrders() {
    if (!adminOrdersUnlocked) {
        document.getElementById("adminOrders").innerHTML = '<div class="card section-card admin-orders-section"><p class="eyebrow-dark">Administración privada</p><h2>Borrar pedidos</h2><p>Ingresá el PIN de borrado para buscar y eliminar pedidos.</p><div class="form-grid"><label>PIN de borrado<input id="deleteOrdersPinUnlock" type="password" placeholder="PIN" autocomplete="current-password" /></label></div><br><button class="danger" data-action="unlockAdminOrders">Entrar a borrar pedidos</button></div>';
        return;
    }
    adminOrdersDeletePage = 1;
    adminOrdersDeleteQuery = "";
    document.getElementById("adminOrders").innerHTML = `
    <div class="card section-card admin-orders-section">
      <div class="toolbar"><div><p class="eyebrow-dark">Administración privada</p><h2>Borrar pedidos</h2><p>Buscá cualquier pedido y eliminalo del sistema. Esta acción también borra sus cobros vinculados en caja y agenda.</p></div></div>
      <div class="filters-row"><input id="adminOrderSearch" data-search-admin-orders placeholder="Buscar por código, cliente, teléfono, estado u observaciones" /></div>
    </div>
    <div id="adminOrdersTable"></div>`;
    renderAdminOrdersList();
}
function unlockAdminOrders() {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
    var pinInput = document.getElementById("deleteOrdersPinUnlock");
    if (!pinInput || String(pinInput.value || "") !== String(state.settings.deleteOrdersPin || "1111")) {
        alert("PIN incorrecto.");
        return;
    }
    adminOrdersUnlocked = true;
    renderAdminOrders();
}
function filteredAdminOrdersDelete(query) {
    var q = String(query || "").toLowerCase();
    return operationalOrders().filter(function (order) {
        return "".concat(order.number, " ").concat(order.location || "", " ").concat(orderClient(order), " ").concat(orderDisplayCode(order), " ").concat((getClient(order.clientId) && getClient(order.clientId).phone) || "", " ").concat(order.status, " ").concat(order.notes || "").toLowerCase().includes(q);
    }).sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
}
function renderAdminOrdersList() {
    var target = document.getElementById("adminOrdersTable");
    if (!target)
        return;
    var filtered = filteredAdminOrdersDelete(adminOrdersDeleteQuery);
    var totalPages = Math.max(1, Math.ceil(filtered.length / adminOrdersDeletePageSize));
    if (adminOrdersDeletePage > totalPages)
        adminOrdersDeletePage = totalPages;
    if (adminOrdersDeletePage < 1)
        adminOrdersDeletePage = 1;
    var start = (adminOrdersDeletePage - 1) * adminOrdersDeletePageSize;
    var pageOrders = filtered.slice(start, start + adminOrdersDeletePageSize);
    target.innerHTML = '<div class="card orders-panel admin-delete-panel"><h2>Pedidos encontrados · ' + filtered.length + '</h2><div class="table-wrap"><table><thead><tr><th>Código</th><th>Cliente</th><th>Estado</th><th>Ingreso</th><th>Total</th><th></th></tr></thead><tbody>' + (pageOrders.map(function (order) { return '<tr><td><strong>' + escapeHtml(orderDisplayCode(order)) + '</strong></td><td>' + escapeHtml(orderClient(order)) + '<br><small>' + escapeHtml((getClient(order.clientId) && getClient(order.clientId).phone) || '-') + '</small></td><td><span class="badge ' + normalizeClass(orderGroup(order)) + '">' + escapeHtml(orderGroup(order)) + '</span></td><td>' + escapeHtml(formatDateTime(order.createdAt)) + '</td><td>' + money(order.total) + '</td><td><div class="actions mini"><button class="secondary" data-action="viewOrder" data-id="' + order.id + '">Ver</button><button class="danger" data-action="deleteOrderAdmin" data-id="' + order.id + '">Eliminar</button></div></td></tr>'; }).join('') || '<tr><td colspan="6">No hay pedidos que coincidan.</td></tr>') + '</tbody></table></div>' + adminOrdersPaginationHtml(filtered.length, adminOrdersDeletePage, totalPages, start, pageOrders.length) + '</div>';
}
function adminOrdersPaginationHtml(total, page, totalPages, start, count) {
    if (!total)
        return "";
    var from = start + 1;
    var to = start + count;
    var firstPage = Math.max(1, page - 4);
    var lastPage = Math.min(totalPages, firstPage + 9);
    firstPage = Math.max(1, lastPage - 9);
    var buttons = [];
    for (var item = firstPage; item <= lastPage; item += 1)
        buttons.push('<button class="page-button ' + (item === page ? 'active' : '') + '" data-action="adminOrdersPage" data-page="' + item + '">' + item + '</button>');
    return '<div class="orders-pagination"><div><strong>Mostrando ' + from + '-' + to + '</strong><span> de ' + total + ' pedidos</span></div><div class="page-controls"><button class="secondary" data-action="prevAdminOrdersPage" ' + (page <= 1 ? 'disabled' : '') + '>‹ Anterior</button>' + buttons.join('') + '<button class="secondary" data-action="nextAdminOrdersPage" ' + (page >= totalPages ? 'disabled' : '') + '>Siguiente ›</button></div></div>';
}
function filterAdminOrdersDelete(query) {
    adminOrdersDeleteQuery = query || "";
    adminOrdersDeletePage = 1;
    renderAdminOrdersList();
}
function setAdminOrdersPage(page) {
    adminOrdersDeletePage = Number(page || 1);
    renderAdminOrdersList();
}
function changeAdminOrdersPage(delta) {
    adminOrdersDeletePage += Number(delta || 0);
    renderAdminOrdersList();
}
function openDeleteOrderAdminModal(id) {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
    if (!adminOrdersUnlocked) { alert("Primero ingresá el PIN de borrado."); renderAdminOrders(); return; }
    var order = getOrder(id);
    if (!order)
        return;
    var html = '<div class="delete-order-modal"><p><strong>Pedido:</strong> ' + escapeHtml(orderDisplayCode(order)) + ' · ' + escapeHtml(orderClient(order)) + '</p><p><strong>Estado:</strong> ' + escapeHtml(order.status) + '</p><p><strong>Total:</strong> ' + escapeHtml(money(order.total)) + '</p><div class="card warning-card"><p>Se va a eliminar este pedido de forma permanente.</p><ul><li>Se borra de Pedidos.</li><li>Se borra de la agenda / turnos.</li><li>Se liberan ubicación y ciclos.</li><li>Se eliminan ingresos vinculados en caja actual e histórica.</li></ul></div><div class="actions"><button class="secondary" data-close-modal>Cancelar</button><button class="danger" data-action="confirmDeleteOrderAdmin" data-id="' + order.id + '">Eliminar pedido</button></div></div>';
    openModal('Eliminar pedido ' + escapeHtml(orderDisplayCode(order)), html);
}
function confirmDeleteOrderAdmin(id) {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
    if (!adminOrdersUnlocked) { alert("Primero ingresá el PIN de borrado."); return; }
    var orderId = Number(id);
    state.orders = (state.orders || []).filter(function (order) { return order.id !== orderId; });
    state.cash = (state.cash || []).filter(function (entry) { return Number(entry.orderId || 0) !== orderId; });
    state.cashHistory = (state.cashHistory || []).map(function (day) { return __assign(__assign({}, day), { entries: (day.entries || []).filter(function (entry) { return Number(entry.orderId || 0) !== orderId; }) }); });
    saveState();
    closeModal();
    render();
    if (isAdmin() && currentView === 'adminOrders')
        renderAdminOrdersList();
}
function clientInitials(name) {
    var parts = String(name || "Cliente").trim().split(/\s+/).filter(Boolean);
    var first = parts[0] ? parts[0].charAt(0) : "C";
    var second = parts.length > 1 ? parts[parts.length - 1].charAt(0) : "";
    return (first + second).toUpperCase();
}
function clientCards(clients) {
    return clients.map(function (client) { return "<article class=\"client-card\"><div class=\"client-avatar client-initials\" aria-label=\"Cliente\">".concat(escapeHtml(clientInitials(client.name)), "</div><h3>").concat(escapeHtml(client.name), "</h3><p><strong>Tel:</strong> ").concat(escapeHtml(client.phone), "</p><p><strong>Autorizados y celulares:</strong> ").concat(escapeHtml(client.authorizedPickups || "Solo titular"), "</p><p><strong>Notas:</strong> ").concat(escapeHtml(client.notes || "-"), "</p><div class=\"actions\"><button class=\"success\" data-action=\"clientHistory\" data-id=\"").concat(client.id, "\">Historial</button><button class=\"primary\" data-action=\"editClient\" data-id=\"").concat(client.id, "\">Editar cliente</button></div></article>"); }).join("") || "<p>No hay clientes para mostrar.</p>";
}
function filterClients(query) {
    var value = String(query || "").toLowerCase();
    var filtered = state.clients.filter(function (client) {
        return (client.name + " " + client.phone + " " + (client.address || "") + " " + (client.notes || "") + " " + (client.authorizedPickups || "")).toLowerCase().indexOf(value) !== -1;
    });
    var target = document.getElementById("clientsList");
    if (target)
        target.innerHTML = clientCards(filtered);
}
function renderClients() {
    document.getElementById("clients").innerHTML = "\n    <div class=\"card section-card\">\n      <div class=\"toolbar\"><div><p class=\"eyebrow-dark\">Personas</p><h2>Clientes</h2></div><button class=\"primary\" data-action=\"newClient\">+ Nuevo cliente</button></div>\n      <div class=\"filters-row\"><input id=\"clientSearch\" data-search-clients placeholder=\"Buscar cliente por nombre, teléfono, autorizado o notas\" /></div>\n      <div id=\"clientsList\" class=\"client-card-grid\">".concat(clientCards(state.clients), "</div>\n    </div>");
}
function canonicalMachineName(name) {
    var text = String(name || "").trim();
    var bigWasher = text.match(/^Lavadora\s+grande\s+(\d+)$/i);
    if (bigWasher)
        return "Lavadora grande " + String(Number(bigWasher[1]));
    var washer = text.match(/^Lavarropas(?:\s+chico)?\s+(\d+)$/i);
    if (washer)
        return "Lavarropas " + String(Number(washer[1]));
    var dryer = text.match(/^Secadora\s+(\d+)$/i);
    if (dryer)
        return "Secadora " + String(Number(dryer[1]));
    return text;
}
function scheduleMachineNames(type, count, label) {
    var prefix = label || (type === "Lavado" ? "Lavarropas" : "Secadora");
    var names = [];
    for (var index = 1; index <= Number(count || 0); index += 1)
        names.push(prefix + " " + String(index));
    return names;
}
function scheduleMachines() {
    var washMachines = __spreadArray([], scheduleMachineNames("Lavado", state.settings.smallWashers, "Lavarropas").map(function (name) { return ({ type: "Lavado", subtype: "small", name: name }); }), true);
    washMachines = __spreadArray(washMachines, scheduleMachineNames("Lavado", state.settings.largeWashers, "Lavadora grande").map(function (name) { return ({ type: "Lavado", subtype: "large", name: name }); }), true);
    return __spreadArray(washMachines, scheduleMachineNames("Secado", state.settings.dryers, "Secadora").map(function (name) { return ({ type: "Secado", subtype: "dryer", name: name }); }), true);
}

function machineIconForName(name) {
    if (String(name || "").indexOf("Secadora") === 0) return "🌬️";
    if (String(name || "").indexOf("Lavadora grande") === 0) return "🧺";
    return "💧";
}
function machineTypeClass(name) {
    if (String(name || "").indexOf("Secadora") === 0) return "dryer";
    if (String(name || "").indexOf("Lavadora grande") === 0) return "large";
    return "washer";
}
function normalizeMachineStatus(value) {
    return value === "maintenance" || value === "repair" ? "maintenance" : "ok";
}
function ensureMachineHistory() {
    state.machineHistory = Array.isArray(state.machineHistory) ? state.machineHistory : [];
    state.machineAlertNoticeLog = state.machineAlertNoticeLog && typeof state.machineAlertNoticeLog === "object" ? state.machineAlertNoticeLog : {};
    state.machineAlertDismissedByRole = state.machineAlertDismissedByRole && typeof state.machineAlertDismissedByRole === "object" ? state.machineAlertDismissedByRole : { admin: {}, user: {} };
    state.machineAlertDismissedByRole.admin = state.machineAlertDismissedByRole.admin || {};
    state.machineAlertDismissedByRole.user = state.machineAlertDismissedByRole.user || {};
}
function addMachineHistory(machine, type, detail) {
    ensureMachineHistory();
    state.machineHistory.push({
        id: nextId(state.machineHistory),
        date: new Date().toISOString(),
        machine: machineRecordKey(machine),
        type: type || "Registro",
        detail: detail || ""
    });
    if (state.machineHistory.length > 1000) state.machineHistory = state.machineHistory.slice(-1000);
}
function machineHistoryRows() {
    ensureMachineHistory();
    return (state.machineHistory || []).slice().sort(function (a,b) { return new Date(b.date) - new Date(a.date); });
}
function renderMachineHistoryPanel() {
    var rows = machineHistoryRows();
    var totalPages = Math.max(1, Math.ceil(rows.length / machineHistoryPageSize));
    if (machineHistoryPage > totalPages) machineHistoryPage = totalPages;
    var start = (machineHistoryPage - 1) * machineHistoryPageSize;
    var visible = rows.slice(start, start + machineHistoryPageSize);
    var body = visible.map(function (row) {
        return '<tr><td>' + escapeHtml(formatShortDateTime(row.date)) + '</td><td>' + escapeHtml(row.machine || '-') + '</td><td>' + escapeHtml(row.type || '-') + '</td><td>' + escapeHtml(row.detail || '-') + '</td></tr>';
    }).join('') || '<tr><td colspan="4">Todavía no hay movimientos registrados.</td></tr>';
    var pages = machineHistoryPaginationHtml(rows.length, machineHistoryPage, totalPages, start, visible.length);
    return '<details class="machine-history-panel"><summary>📋 Historial de máquinas</summary><div class="toolbar compact"><div><p>Estados, observaciones y alarmas registradas.</p></div><button class="secondary" type="button" data-action="exportMachineHistory">Exportar hoja de cálculo</button></div><div class="table-scroll"><table><thead><tr><th>Fecha</th><th>Máquina</th><th>Tipo</th><th>Detalle</th></tr></thead><tbody>' + body + '</tbody></table></div>' + pages + '</details>';
}
function machineHistoryPaginationHtml(total, page, totalPages, start, count) {
    var from = total ? start + 1 : 0;
    var to = start + count;
    var buttons = [];
    var firstPage = Math.max(1, page - 4);
    var lastPage = Math.min(totalPages, firstPage + 9);
    firstPage = Math.max(1, lastPage - 9);
    for (var item = firstPage; item <= lastPage; item += 1)
        buttons.push('<button class="page-button ' + (item === page ? 'active' : '') + '" data-action="machineHistoryPage" data-page="' + item + '">' + item + '</button>');
    return '<div class="orders-pagination machine-history-pagination"><div><strong>Mostrando ' + from + '-' + to + '</strong><span> de ' + total + ' movimientos</span></div><div class="page-controls"><button class="secondary" data-action="prevMachineHistoryPage" ' + (page <= 1 ? 'disabled' : '') + '>‹ Anterior</button>' + buttons.join('') + '<button class="secondary" data-action="nextMachineHistoryPage" ' + (page >= totalPages ? 'disabled' : '') + '>Siguiente ›</button></div></div>';
}

function changeMachineHistoryPage(delta) {
    machineHistoryPage = Math.max(1, machineHistoryPage + Number(delta || 0));
    renderMachines();
}
function setMachineHistoryPage(page) {
    machineHistoryPage = Math.max(1, Number(page || 1));
    renderMachines();
}
function exportMachineHistory() {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
    var rows = [["Fecha", "Máquina", "Tipo", "Detalle"]];
    machineHistoryRows().forEach(function (row) {
        rows.push([formatShortDateTime(row.date), row.machine || "", row.type || "", row.detail || ""]);
    });
    downloadCsv(rows, "historial-maquinas-" + localDateInput() + ".csv", "Historial de máquinas compatible con hoja de cálculo");
}


function machineRecordKey(name) {
    return canonicalMachineName(name || "");
}
function defaultMachineRecord(name) {
    return { name: machineRecordKey(name), status: "ok", observations: "", parts: "", maintenanceAt: "", maintenanceTask: "Limpieza de tambores", updatedAt: "" };
}
function ensureMachineRecords() {
    state.machineRecords = Array.isArray(state.machineRecords) ? state.machineRecords : [];
    state.machineAlertLog = state.machineAlertLog && typeof state.machineAlertLog === "object" ? state.machineAlertLog : {};
    state.machineAlertNoticeLog = state.machineAlertNoticeLog && typeof state.machineAlertNoticeLog === "object" ? state.machineAlertNoticeLog : {};
    state.machineAlertDismissedByRole = state.machineAlertDismissedByRole && typeof state.machineAlertDismissedByRole === "object" ? state.machineAlertDismissedByRole : { admin: {}, user: {} };
    state.machineAlertDismissedByRole.admin = state.machineAlertDismissedByRole.admin || {};
    state.machineAlertDismissedByRole.user = state.machineAlertDismissedByRole.user || {};
    state.machineHistory = Array.isArray(state.machineHistory) ? state.machineHistory : [];
    var names = scheduleMachines().map(function (machine) { return machineRecordKey(machine.name); });
    names.forEach(function (name) {
        if (!state.machineRecords.some(function (record) { return machineRecordKey(record.name) === name; }))
            state.machineRecords.push(defaultMachineRecord(name));
    });
    state.machineRecords = state.machineRecords.filter(function (record) { return names.includes(machineRecordKey(record.name)); }).map(function (record) {
        var normalized = __assign(__assign({}, defaultMachineRecord(record.name)), record, { name: machineRecordKey(record.name) });
        normalized.status = normalizeMachineStatus(normalized.status);
        normalized.parts = "";
        return normalized;
    });
}
function getMachineRecord(machineName) {
    ensureMachineRecords();
    var wanted = machineRecordKey(machineName);
    return state.machineRecords.filter(function (record) { return machineRecordKey(record.name) === wanted; })[0] || defaultMachineRecord(wanted);
}
function allMachineRecords() {
    ensureMachineRecords();
    return scheduleMachines().map(function (machine) { return getMachineRecord(machine.name); });
}
function machineStatusLabelFromRecord(record) {
    if (!record || record.status === "ok")
        return "Operativa";
    return "En mantenimiento";
}
function machineStatusClass(record) {
    if (!record || record.status === "ok")
        return "ok";
    return "maintenance";
}
function isMachineOutOfService(machineName) {
    var record = getMachineRecord(machineName);
    return record && record.status && record.status !== "ok";
}
function machineOutOfServiceConflict(machineName, start, end) {
    var record = getMachineRecord(machineName);
    if (!record || record.status === "ok")
        return null;
    return {
        type: "Bloqueo",
        machine: machineRecordKey(machineName),
        start: start.toISOString(),
        end: end.toISOString(),
        description: machineStatusLabelFromRecord(record),
        cycleId: "machine-status-" + machineRecordKey(machineName).replace(/\s+/g, "-"),
        order: { id: 0, block: true, status: "Pendiente" }
    };
}
function maintenanceAlertKey(record) {
    return machineRecordKey(record.name) + "|" + String(record.maintenanceAt || "");
}
function clearMachineAlertStateForMachine(machineName) {
    ensureMachineHistory();
    var prefix = machineRecordKey(machineName) + "|";
    [state.machineAlertLog, state.machineAlertNoticeLog].forEach(function (bucket) {
        if (!bucket)
            return;
        Object.keys(bucket).forEach(function (key) {
            if (String(key).indexOf(prefix) === 0)
                delete bucket[key];
        });
    });
    if (state.machineAlertDismissedByRole) {
        ["admin", "user"].forEach(function (role) {
            var bucket = state.machineAlertDismissedByRole[role] || {};
            Object.keys(bucket).forEach(function (key) {
                if (String(key).indexOf(prefix) === 0)
                    delete bucket[key];
            });
            state.machineAlertDismissedByRole[role] = bucket;
        });
    }
}
function dueMaintenanceRecords(now) {
    ensureMachineRecords();
    var reference = now || new Date();
    return allMachineRecords().filter(function (record) {
        if (!record || !record.maintenanceAt)
            return false;
        var when = new Date(record.maintenanceAt);
        if (isNaN(when.getTime()) || when > reference)
            return false;
        return true;
    });
}
function overdueMaintenanceRecords(now) {
    return dueMaintenanceRecords(now);
}
function machineAvailabilityNoticeHtml() {
    ensureMachineRecords();
    var out = allMachineRecords().filter(function (record) { return record.status !== "ok"; });
    var due = overdueMaintenanceRecords();
    if (!out.length && !due.length)
        return "";
    return '<div class="machine-system-alerts">' +
        (out.length ? '<article><strong>Máquinas bloqueadas</strong><span>' + out.map(function (record) { return escapeHtml(record.name + " · " + machineStatusLabelFromRecord(record)); }).join('<br>') + '</span></article>' : '') +
        (due.length ? '<article class="due"><strong>Mantenimiento pendiente</strong><span>' + due.map(function (record) { return escapeHtml(record.name + " · " + (record.maintenanceTask || "Limpieza de tambores") + " · " + formatDateTime(record.maintenanceAt)); }).join('<br>') + '</span></article>' : '') +
        '</div>';
}
function machineRecordCardHtml(record) {
    var status = machineStatusClass(record);
    var machineType = record.name.indexOf("Secadora") === 0 ? "Secadora" : record.name.indexOf("Lavadora grande") === 0 ? "Lavadora grande" : "Lavarropas";
    var due = record.status !== "ok" && record.maintenanceAt && new Date(record.maintenanceAt) <= new Date();
    var dueClass = due ? " due" : "";
    var typeClass = machineTypeClass(record.name);
    var alertText = record.maintenanceAt ? (due ? "Vencido: " : "Próximo: ") + formatDateTime(record.maintenanceAt) : "Sin alarma programada";
    return '<article class="machine-admin-card type-' + typeClass + ' status-' + status + dueClass + '">' +
        '<form class="machine-admin-form">' +
        '<input type="hidden" name="machine" value="' + escapeHtml(record.name) + '" />' +
        '<div class="machine-admin-head"><div><small>' + machineIconForName(record.name) + ' ' + escapeHtml(machineType) + '</small><h3>' + escapeHtml(record.name) + '</h3></div><span class="machine-admin-status ' + status + '">' + escapeHtml(machineStatusLabelFromRecord(record)) + '</span></div>' +
        '<label>Estado<select name="status"><option value="ok" ' + (record.status === "ok" ? "selected" : "") + '>✅ Operativa</option><option value="maintenance" ' + (record.status === "maintenance" ? "selected" : "") + '>🛠️ En mantenimiento</option></select></label>' +
        '<div class="machine-alarm-row single"><label>Alarma de mantenimiento<input type="datetime-local" name="maintenanceAt" value="' + escapeHtml(record.maintenanceAt || "") + '" /></label></div>' +
        '<label class="full">Tarea de la alarma<input name="maintenanceTask" value="' + escapeHtml(record.maintenanceTask || "Limpieza de tambores") + '" placeholder="Limpieza de tambores" /></label>' +
        '<label class="full">Observaciones<textarea name="observations" rows="3" placeholder="Ej: limpieza de tambor, ruido raro, revisar manguera...">' + escapeHtml(record.observations || "") + '</textarea></label>' +
        '<div class="machine-admin-footer"><span>' + escapeHtml(alertText) + '</span><button class="primary" type="button" data-action="saveMachineRecord">Actualizar</button></div>' +
        '</form>' +
        '</article>';
}

function renderMachines() {
    ensureMachineRecords();
    var records = allMachineRecords();
    var blocked = records.filter(function (record) { return record.status !== "ok"; }).length;
    var due = overdueMaintenanceRecords().length;
    var cards = records.map(machineRecordCardHtml).join("");
    document.getElementById("machines").innerHTML = '<div class="machines-admin-page"><div class="card machines-admin-hero"><div><p class="eyebrow-dark">Administración</p><h2>⚙️ Máquinas</h2><p>Control simple de estado, observaciones y alarmas de mantenimiento.</p></div><div class="machines-admin-kpis"><article><span>Bloqueadas</span><strong>' + blocked + '</strong></article><article><span>Alarmas vencidas</span><strong>' + due + '</strong></article></div></div>' + machineAvailabilityNoticeHtml() + '<div class="machine-admin-help">🛠️ Si una máquina queda en mantenimiento, se bloquea automáticamente para turnos y disponibilidad.</div><div class="machine-admin-grid">' + cards + '</div>' + renderMachineHistoryPanel() + '</div>';
}

function saveMachineRecord(button) {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
    var form = button.closest("form");
    var data = formDataToObject(form);
    var machine = machineRecordKey(data.machine || "");
    if (!machine) {
        alert("No se pudo identificar la máquina.");
        return;
    }
    ensureMachineRecords();
    var record = getMachineRecord(machine);
    var previousStatus = normalizeMachineStatus(record.status);
    var previousObservations = String(record.observations || "");
    var previousMaintenanceAt = String(record.maintenanceAt || "");
    var previousTask = String(record.maintenanceTask || "Limpieza de tambores");
    var nextStatus = normalizeMachineStatus(data.status);
    var returnsToOperative = previousStatus !== "ok" && nextStatus === "ok";
    record.status = nextStatus;
    if (returnsToOperative) {
        record.observations = "";
        record.parts = "";
        record.maintenanceAt = "";
        record.maintenanceTask = "Limpieza de tambores";
        clearMachineAlertStateForMachine(machine);
    }
    else {
        record.observations = String(data.observations || "").trim();
        record.parts = "";
        record.maintenanceAt = String(data.maintenanceAt || "").trim();
        record.maintenanceTask = String(data.maintenanceTask || "Limpieza de tambores").trim() || "Limpieza de tambores";
    }
    record.updatedAt = new Date().toISOString();
    if (previousStatus !== record.status) {
        addMachineHistory(machine, "Estado", previousStatus === "ok" && record.status === "maintenance" ? "Pasó a mantenimiento" : record.status === "ok" ? "Volvió a operativa y se reiniciaron alarma y observaciones" : "Cambio de estado");
    }
    if (!returnsToOperative && previousObservations !== record.observations) {
        addMachineHistory(machine, "Observación", record.observations || "Observación vacía");
    }
    if (returnsToOperative) {
        if (previousMaintenanceAt)
            addMachineHistory(machine, "Alarma eliminada", "La máquina volvió a operativa");
    }
    else if (previousMaintenanceAt !== record.maintenanceAt || previousTask !== record.maintenanceTask) {
        addMachineHistory(machine, record.maintenanceAt ? "Alarma programada" : "Alarma eliminada", record.maintenanceAt ? (record.maintenanceTask + " · " + formatDateTime(record.maintenanceAt)) : "Sin alarma");
        clearMachineAlertStateForMachine(machine);
    }
    saveState();
    render();
    alert(record.status === "ok" ? machine + " quedó operativa." : machine + " quedó bloqueada para turnos.");
}

function playMaintenanceSound() {
    try {
        var AudioContextRef = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextRef) return;
        var ctx = new AudioContextRef();
        var gain = ctx.createGain();
        gain.gain.value = 0.045;
        gain.connect(ctx.destination);
        [0, 280, 560].forEach(function (delay, index) {
            var oscillator = ctx.createOscillator();
            oscillator.type = "sine";
            oscillator.frequency.value = index === 1 ? 740 : 880;
            oscillator.connect(gain);
            setTimeout(function () { oscillator.start(); }, delay);
            setTimeout(function () { try { oscillator.stop(); } catch (error) {} }, delay + 170);
        });
        setTimeout(function () { ctx.close && ctx.close(); }, 1050);
    } catch (error) {}
}
function alertRoleKey() {
    return currentRole() === "admin" ? "admin" : "user";
}
function alertDismissedForCurrentRole(key) {
    ensureMachineRecords();
    var role = alertRoleKey();
    return Boolean(state.machineAlertDismissedByRole && state.machineAlertDismissedByRole[role] && state.machineAlertDismissedByRole[role][key]);
}
function dismissMaintenanceAlertForCurrentRole(key) {
    if (!key)
        return;
    ensureMachineRecords();
    var role = alertRoleKey();
    state.machineAlertDismissedByRole[role] = state.machineAlertDismissedByRole[role] || {};
    state.machineAlertDismissedByRole[role][key] = new Date().toISOString();
    saveState();
}
function ackMaintenanceAlert(button) {
    var machine = machineRecordKey(button.getAttribute("data-machine") || "");
    var record = getMachineRecord(machine);
    if (!record || !record.maintenanceAt)
        return;
    var roleLabel = alertRoleKey() === "admin" ? "Administrador" : "Empleado";
    var key = maintenanceAlertKey(record);
    dismissMaintenanceAlertForCurrentRole(key);
    addMachineHistory(machine, "Alarma confirmada", roleLabel + " · " + (record.maintenanceTask || "Limpieza de tambores") + " · " + formatDateTime(record.maintenanceAt));
    saveState();
    closeModal();
    render();
}
function checkMaintenanceAlerts(force) {
    if (!state || !state.machineRecords)
        return;
    if (!force && document.querySelector(".modal-backdrop"))
        return;
    var due = dueMaintenanceRecords().filter(function (record) { return !alertDismissedForCurrentRole(maintenanceAlertKey(record)); });
    if (!due.length)
        return;
    var record = due[0];
    var key = maintenanceAlertKey(record);
    if (!state.machineAlertNoticeLog[key]) {
        state.machineAlertNoticeLog[key] = new Date().toISOString();
        addMachineHistory(record.name, "Alarma disparada", (record.maintenanceTask || "Limpieza de tambores") + " · " + formatDateTime(record.maintenanceAt));
        saveState();
    }
    playMaintenanceSound();
    var html = '<div class="maintenance-alert-modal"><div class="maintenance-alert-icon">🔔</div><h3>Alarma de mantenimiento</h3><p><strong>' + escapeHtml(record.name) + '</strong></p><p>' + escapeHtml(record.maintenanceTask || "Limpieza de tambores") + '</p><p>Programado para ' + escapeHtml(formatDateTime(record.maintenanceAt)) + '.</p><div class="actions"><button class="primary" data-action="ackMaintenanceAlert" data-machine="' + escapeHtml(record.name) + '">Entendido</button></div></div>';
    var modal = openModal("Alarma de mantenimiento", html);
    if (modal) {
        modal.setAttribute("data-maintenance-alert", "true");
        modal.setAttribute("data-alert-key", key);
    }
}

function isDeferredAutoDryCycle(cycle, order) {
    return Boolean(order && order.status === "Pendiente" && cycle && cycle.type === "Secado" && cycle.manual === false);
}
function activeScheduleCycles() {
    var cycles = state.orders
        .filter(function (order) { return order.block || order.status === "Pendiente"; })
        .reduce(function (list, order) { return list.concat((order.cycles || []).map(function (cycle, index) { return (__assign(__assign({}, cycle), { order: order, cycleIndex: index, cycleId: cycle.cycleId || String(order.id) + "-" + String(index) })); })); }, [])
        .filter(function (cycle) { return cycle.type !== "Preparación"; })
        .sort(function (a, b) { return new Date(a.start) - new Date(b.start); });
    return cycles;
}
function calendarScheduleCycles() {
    var cycles = state.orders
        .filter(function (order) { return order.block || (order.cycles || []).length; })
        .reduce(function (list, order) { return list.concat((order.cycles || []).map(function (cycle, index) { return (__assign(__assign({}, cycle), { order: order, cycleIndex: index, cycleId: cycle.cycleId || String(order.id) + "-" + String(index) })); })); }, [])
        .filter(function (cycle) { return cycle.type !== "Preparación"; })
        .sort(function (a, b) { return new Date(a.start) - new Date(b.start); });
    return cycles;
}
function scheduleVisibleDays() {
    if (scheduleViewMode === "week")
        return currentWeekDays(new Date("".concat(scheduleWeekStart, "T00:00:00")));
    return [new Date("".concat(scheduleSelectedDate, "T00:00:00"))];
}
function setScheduleDate(value) {
    scheduleSelectedDate = value || localDateInput();
    scheduleWeekStart = currentWeekStart(new Date("".concat(scheduleSelectedDate, "T00:00:00"))).toISOString().slice(0, 10);
    renderSchedule();
}
function setScheduleViewMode(mode) {
    scheduleViewMode = mode === "week" ? "week" : "day";
    renderSchedule();
}
function scheduleTimeSlots() {
    var openHour = Number(state.settings.openHour.split(":")[0]);
    var closeHour = Number(state.settings.closeHour.split(":")[0]);
    var slots = [];
    var cursor = openHour * 60;
    var end = closeHour * 60;
    while (cursor < end) {
        slots.push({ minutes: cursor, label: hourLabel(Math.floor(cursor / 60)).replace(":00", ":") + leftPad(cursor % 60, 2, "0") });
        cursor += Number(scheduleSlotMinutes || 30);
    }
    return slots;
}
function cycleOverlapsRange(cycle, start, end) {
    return new Date(cycle.start) < end && new Date(cycle.end) > start;
}
function machineConflicts(machineName, start, end, ignoreOrderId, ignoreCycleId) {
    var wantedMachine = canonicalMachineName(machineName);
    var outOfService = machineOutOfServiceConflict(wantedMachine, start, end);
    var conflicts = outOfService ? [outOfService] : [];
    return conflicts.concat(calendarScheduleCycles().filter(function (cycle) {
        if (!wantedMachine || !cycle.machine || canonicalMachineName(cycle.machine) !== wantedMachine)
            return false;
        if (ignoreOrderId && cycle.order.id === Number(ignoreOrderId) && String(cycle.cycleId) === String(ignoreCycleId))
            return false;
        return cycleOverlapsRange(cycle, start, end);
    }));
}
function machineConflictsInCycles(machineName, start, end, cycles) {
    var wantedMachine = canonicalMachineName(machineName);
    var outOfService = machineOutOfServiceConflict(wantedMachine, start, end);
    var conflicts = outOfService ? [outOfService] : [];
    return conflicts.concat((cycles || []).filter(function (cycle) {
        if (!wantedMachine || !cycle.machine || canonicalMachineName(cycle.machine) !== wantedMachine)
            return false;
        return cycleOverlapsRange(cycle, start, end);
    }));
}
function nextFreeMachineSlotFromCycles(type, durationMinutes, fromDate, cycles) {
    var machines = scheduleMachines().filter(function (machine) { return machine.type === type; });
    var cursor = LaundryScheduler.normalizeBusinessStart(fromDate || new Date(), state.settings);
    var guard = 0;
    while (guard < 80) {
        for (var index = 0; index < machines.length; index += 1) {
            var end = LaundryScheduler.addWorkingMinutes(cursor, Number(durationMinutes || 30), state.settings);
            if (!machineConflictsInCycles(machines[index].name, cursor, end, cycles).length)
                return { machine: machines[index].name, start: new Date(cursor), end: end };
        }
        cursor = new Date(cursor.getTime() + Number(scheduleSlotMinutes || 30) * 60000);
        cursor = LaundryScheduler.normalizeBusinessStart(cursor, state.settings);
        guard += 1;
    }
    return null;
}
function timelineProjectedCycles(baseCycles, selectedDate) {
    var combined = __spreadArray([], baseCycles || [], true);
    state.orders.filter(function (order) { return order && order.status === "Pendiente" && orderNeedsDry(order); }).forEach(function (order) {
        var related = combined.filter(function (cycle) { return cycle.order && cycle.order.id === order.id; });
        if (related.some(function (cycle) { return cycle.type === "Secado" && !cycle.projected; }))
            return;
        var lastWash = related.filter(function (cycle) { return cycle.type === "Lavado"; }).sort(function (a, b) { return new Date(a.end) - new Date(b.end); }).pop();
        if (!lastWash)
            return;
        var start = new Date(lastWash.end);
        var duration = Number(state.settings.dryingMinutes || 50);
        var slot = nextFreeMachineSlotFromCycles("Secado", duration, start, combined);
        if (!slot)
            return;
        combined.push({
            type: "Secado",
            machine: slot.machine,
            start: slot.start.toISOString(),
            end: slot.end.toISOString(),
            minutes: duration,
            order: order,
            cycleId: "forecast-" + String(order.id),
            projected: true,
            description: "Secado estimado"
        });
    });
    return combined.sort(function (a, b) { return new Date(a.start) - new Date(b.start); });
}
function nextFreeMachineSlot(type, durationMinutes, fromDate) {
    var machines = scheduleMachines().filter(function (machine) { return machine.type === type; });
    var cursor = LaundryScheduler.normalizeBusinessStart(fromDate || new Date(), state.settings);
    var guard = 0;
    while (guard < 80) {
        for (var index = 0; index < machines.length; index += 1) {
            var end = new Date(cursor.getTime() + Number(durationMinutes || 30) * 60000);
            if (!machineConflicts(machines[index].name, cursor, end).length)
                return { machine: machines[index].name, start: cursor, end: end };
        }
        cursor = new Date(cursor.getTime() + Number(scheduleSlotMinutes || 30) * 60000);
        cursor = LaundryScheduler.normalizeBusinessStart(cursor, state.settings);
        guard += 1;
    }
    return null;
}
function schedulePredictions(activeCycles, machines, days) {
    var now = new Date();
    var todayKey = dateKey(now);
    var occupied = activeCycles.filter(function (cycle) { return cycle.machine && cycleOverlapsRange(cycle, now, new Date(now.getTime() + 1)); });
    var today = activeCycles.filter(function (cycle) { return dateKey(cycle.start) === todayKey; });
    var wash = nextFreeMachineSlot("Lavado", state.settings.washingMinutes, now);
    var dry = nextFreeMachineSlot("Secado", state.settings.dryingMinutes, now);
    return { occupied: occupied.length, free: Math.max(0, machines.length - occupied.length), today: today.length, wash: wash, dry: dry, days: days.length };
}
function machineTypeFromCycle(cycle) {
    return cycle && cycle.type === "Secado" ? "Secado" : cycle && cycle.type === "Bloqueo" ? "Reservada" : "Lavando";
}
function scheduleAvailabilityReference() {
    var selectedKey = scheduleSelectedDate || localDateInput();
    var todayKey = localDateInput();
    if (selectedKey === todayKey) {
        var now = new Date();
        var open = LaundryScheduler.startOfWorkday(new Date(selectedKey + "T00:00:00"), state.settings);
        var close = LaundryScheduler.endOfWorkday(new Date(selectedKey + "T00:00:00"), state.settings);
        if (now >= open && now <= close)
            return now;
    }
    return LaundryScheduler.startOfWorkday(new Date(selectedKey + "T00:00:00"), state.settings);
}
function currentCycleForMachine(machineName, activeCycles, referenceDate) {
    var reference = referenceDate || scheduleAvailabilityReference();
    var rangeEnd = new Date(reference.getTime() + 60000);
    var statusConflict = machineOutOfServiceConflict(machineName, reference, rangeEnd);
    if (statusConflict)
        return statusConflict;
    for (var index = 0; index < activeCycles.length; index += 1) {
        if (canonicalMachineName(activeCycles[index].machine) === canonicalMachineName(machineName) && cycleOverlapsRange(activeCycles[index], reference, rangeEnd))
            return activeCycles[index];
    }
    return null;
}
function nextCycleForMachine(machineName, activeCycles) {
    var now = new Date();
    var list = activeCycles.filter(function (cycle) { return canonicalMachineName(cycle.machine) === canonicalMachineName(machineName) && new Date(cycle.start) >= now; });
    list.sort(function (a, b) { return new Date(a.start) - new Date(b.start); });
    return list[0] || null;
}
function machineStatusLabel(machine, currentCycle) {
    if (!currentCycle)
        return "Libre";
    if (currentCycle.type === "Bloqueo")
        return "Reservada";
    return currentCycle.type === "Secado" ? "Secando" : "Lavando";
}
function cyclePersonLabel(cycle) {
    if (!cycle)
        return "Sin trabajo";
    if (cycle.type === "Bloqueo")
        return cycle.description || "Reservada";
    return orderClient(cycle.order) + " · " + orderDisplayCode(cycle.order);
}
function schedulePlanningStart() {
    var date = scheduleSelectedDate || localDateInput();
    var time = state.settings.openHour || "09:00";
    return LaundryScheduler.normalizeBusinessStart(new Date(date + "T" + time + ":00"), state.settings);
}
function pendingScheduleOrders() {
    return operationalOrders().filter(function (order) { return order.status === "Pendiente"; }).sort(function (a, b) { return new Date(a.createdAt) - new Date(b.createdAt); });
}
function estimatedOrderMinutes(order) {
    var service = getService(order.serviceId) || state.services[0];
    var total = 0;
    if (service && service.wash)
        total += Number(state.settings.washingMinutes || 0);
    if (service && service.dry)
        total += Number(state.settings.dryingMinutes || 0);
    return total || Number(state.settings.washingMinutes || 30);
}
function shortTicketLabel(order) {
    var items = order.items || [];
    var count = items.reduce(function (sum, item) { return sum + Number(item.quantity || 1); }, 0);
    return count ? count + " prendas" : serviceSummary(order);
}
function compactOrderTicketHtml(order) {
    var selected = selectedScheduleTicketId === order.id ? " selected-ticket" : "";
    return '<article class="pending-ticket compact-ticket'.concat(selected, '" draggable="true" data-drag-ticket data-action="selectScheduleTicket" data-id="').concat(order.id, '" data-order-id="').concat(order.id, '" role="button" tabindex="0"><div class="pending-ticket-main"><strong class="pending-ticket-code">').concat(escapeHtml(customerOrderCode(order)), '</strong><span class="pending-ticket-client">').concat(escapeHtml(orderClient(order)), '</span><small class="pending-ticket-meta">').concat(escapeHtml(shortTicketLabel(order)), ' · ').concat(estimatedOrderMinutes(order), ' min</small></div><button class="detail-dot" data-action="scheduleTicketDetail" data-id="').concat(order.id, '">Ver</button></article>');
}
function pendingScheduleTicketsHtml() {
    var orders = pendingScheduleOrders();
    return '<aside class="pending-ticket-column"><div class="pending-ticket-header"><h3>Pendientes</h3><strong>'.concat(orders.length, '</strong></div>').concat(orders.map(compactOrderTicketHtml).join('') || '<p class="empty-mini">Sin pendientes</p>', '</aside>');
}
function compactCycleHtml(cycle, slotStart, slotEnd) {
    var hasMachine = Boolean(cycle.machine);
    var machineLabel = canonicalMachineName(cycle.machine) || (cycle.type === "Secado" ? "Secadora pendiente" : cycle.type === "Lavado" ? "Lavadora pendiente" : "Sin máquina");
    var serviceLabel = cycle.order && !cycle.order.block ? serviceSummary(cycle.order) : cycle.type;
    var clientLabel = cycle.order && cycle.order.block ? (cycle.description || "Reserva") : orderClient(cycle.order);
    var codeLabel = cycle.order && cycle.order.block ? "Bloqueo" : orderDisplayCode(cycle.order);
    var timeLabel = formatShortDateTime(cycle.start).slice(-5) + " - " + formatShortDateTime(cycle.end).slice(-5);
    var startsHere = !slotStart || !slotEnd || (new Date(cycle.start) >= slotStart && new Date(cycle.start) < slotEnd);
    var baseClass = hasMachine ? 'assigned-cycle' : 'unassigned-cycle';
    if (!startsHere) {
        return '<button class="compact-cycle compact-cycle-continuation ' + baseClass + '" draggable="true" data-drag-cycle data-id="' + cycle.order.id + '" data-cycle-id="' + escapeHtml(cycle.cycleId) + '" data-action="openCycleEdit">' +
            '<span class="cycle-time">↳ continúa</span>' +
            '<span class="cycle-machine">' + escapeHtml(codeLabel) + '<small>' + escapeHtml(machineLabel) + '</small></span>' +
            '<span class="cycle-person"><strong>mismo pedido</strong><em>' + escapeHtml(formatShortDateTime(cycle.end).slice(-5)) + '</em></span>' +
            '</button>';
    }
    return '<button class="compact-cycle compact-cycle-start ' + baseClass + '" draggable="true" data-drag-cycle data-id="' + cycle.order.id + '" data-cycle-id="' + escapeHtml(cycle.cycleId) + '" data-action="openCycleEdit">' +
        '<span class="cycle-time">' + escapeHtml(timeLabel) + '</span>' +
        '<span class="cycle-machine">' + escapeHtml(machineLabel) + '<small>' + escapeHtml(serviceLabel) + '</small></span>' +
        '<span class="cycle-person"><strong>' + escapeHtml(clientLabel) + '</strong><em>' + escapeHtml(codeLabel + " · inicia") + '</em></span>' +
        '</button>';
}
function dailyScheduleSlots(date, slotMinutes) {
    var slots = [];
    var open = Number(state.settings.openHour.split(":")[0]) * 60;
    var close = Number(state.settings.closeHour.split(":")[0]) * 60;
    var cursor = open;
    while (cursor < close) {
        var start = new Date(date);
        start.setHours(Math.floor(cursor / 60), cursor % 60, 0, 0);
        slots.push({ start: start, label: leftPad(Math.floor(cursor / 60), 2, "0") + ":" + leftPad(cursor % 60, 2, "0") });
        cursor += Number(slotMinutes || 30);
    }
    return slots;
}
function schedulePrimarySummary(prediction) {
    var reference = scheduleAvailabilityReference();
    var label = formatShortDateTime(reference).slice(-5);
    return '<div class="simple-schedule-summary"><article><span>Lavarropas libres a las ' + label + '</span><strong>' + freeMachineCount("Lavado", reference) + '/' + Number(state.settings.smallWashers || 0) + '</strong></article><article><span>Secadoras libres a las ' + label + '</span><strong>' + freeMachineCount("Secado", reference) + '/' + Number(state.settings.dryers || 0) + '</strong></article><article><span>Trabajos de hoy</span><strong>' + prediction.today + '</strong></article></div>';
}
function schedulePredictionHtml(prediction) {
    return '<div class="schedule-prediction-strip"><article><span>Máquinas libres</span><strong>'.concat(prediction.free, '</strong><small>Trabajando: ').concat(prediction.occupied, '</small></article><article><span>Trabajos de hoy</span><strong>').concat(prediction.today, '</strong><small>Lavados, secados y reservas</small></article></div>');
}
function freeMachineCount(type, referenceDate) {
    var activeCycles = activeScheduleCycles();
    var machines = scheduleMachines().filter(function (machine) { return machine.type === type; });
    var occupied = 0;
    machines.forEach(function (machine) {
        if (currentCycleForMachine(machine.name, activeCycles, referenceDate))
            occupied += 1;
    });
    return Math.max(0, machines.length - occupied);
}
function toggleScheduleAdvancedMode() {
    scheduleSimpleMode = !scheduleSimpleMode;
    renderSchedule();
}
function renderSchedule() {
    var machines = scheduleMachines();
    var activeCycles = activeScheduleCycles();
    var calendarCycles = calendarScheduleCycles();
    var prediction = schedulePredictions(activeCycles, machines, [new Date(scheduleSelectedDate + "T00:00:00")]);
    var html = "";
    html += "<div class=\"schedule-workspace\"><main class=\"schedule-main-board\">";
    html += "<div class=\"card schedule-simple-hero\"><div><p class=\"eyebrow-dark\">Turnos</p><h2>Cronograma de hoy</h2></div></div>";
    html += scheduleDayAgendaHtml(calendarCycles, new Date(scheduleSelectedDate + "T00:00:00"));
    html += globalTurnHistoryHtml(calendarCycles);
    html += "</main>" + pendingScheduleTicketsHtml() + "</div>";
    document.getElementById("schedule").innerHTML = html;
}
function cycleModifiedAt(cycle) {
    // Fecha real de modificación: funciona como log y usa la fecha/hora de Windows del momento en que se tocó el turno.
    if (cycle && cycle.updatedAt)
        return cycle.updatedAt;
    if (cycle && cycle.order && cycle.order.updatedAt)
        return cycle.order.updatedAt;
    if (cycle && cycle.order && cycle.order.createdAt)
        return cycle.order.createdAt;
    if (cycle && cycle.start)
        return cycle.start;
    return new Date().toISOString();
}
function scheduleHistoryRows(cycles) {
    return __spreadArray([], cycles || [], true).sort(function (a, b) { return new Date(cycleModifiedAt(b)) - new Date(cycleModifiedAt(a)); });
}
function globalTurnHistoryHtml(cycles) {
    var ordered = scheduleHistoryRows(cycles);
    var totalPages = Math.max(1, Math.ceil(ordered.length / scheduleHistoryPageSize));
    if (scheduleHistoryPage > totalPages)
        scheduleHistoryPage = totalPages;
    if (scheduleHistoryPage < 1)
        scheduleHistoryPage = 1;
    var start = (scheduleHistoryPage - 1) * scheduleHistoryPageSize;
    var pageRows = ordered.slice(start, start + scheduleHistoryPageSize);
    var pagination = scheduleHistoryPaginationHtml(ordered.length, scheduleHistoryPage, totalPages, start, pageRows.length);
    return '<details class="card global-turn-history"><summary class="secondary history-toggle">Historial global de turnos</summary><div class="toolbar"><div><p class="eyebrow-dark">Historial global</p><h3>Historial de turnos</h3><p>Ordenado por la última modificación realizada.</p></div><div class="actions"><button class="secondary" data-action="exportGlobalTurnHistory">Exportar historial de turnos como hoja de cálculo</button></div></div><div class="table-wrap"><table><thead><tr><th>Fecha de modificación</th><th>Fecha agendada</th><th>Pedido</th><th>Cliente</th><th>Tipo</th><th>Máquina</th><th>Horario</th></tr></thead><tbody>'.concat(pageRows.map(function (cycle) { return '<tr><td>'.concat(formatShortDateTime(cycleModifiedAt(cycle)), '</td><td>').concat(formatShortDateTime(cycle.start).slice(0, 8), '</td><td>').concat(escapeHtml(orderDisplayCode(cycle.order)), '</td><td>').concat(escapeHtml(orderClient(cycle.order)), '</td><td>').concat(escapeHtml(cycle.type), '</td><td>').concat(escapeHtml(canonicalMachineName(cycle.machine) || "Sin máquina asignada"), '</td><td>').concat(formatShortDateTime(cycle.start).slice(-5), ' - ').concat(formatShortDateTime(cycle.end).slice(-5), '</td></tr>'); }).join('') || '<tr><td colspan="7">Todavía no hay turnos registrados.</td></tr>', '</tbody></table></div>').concat(pagination, '</details>');
}
function scheduleHistoryPaginationHtml(total, page, totalPages, start, count) {
    if (!total)
        return "";
    var from = start + 1;
    var to = start + count;
    var firstPage = Math.max(1, page - 4);
    var lastPage = Math.min(totalPages, firstPage + 9);
    firstPage = Math.max(1, lastPage - 9);
    var buttons = [];
    for (var item = firstPage; item <= lastPage; item += 1) {
        buttons.push('<button class="page-button ' + (item === page ? 'active' : '') + '" data-action="scheduleHistoryPage" data-page="' + item + '">' + item + '</button>');
    }
    return '<div class="orders-pagination schedule-history-pagination"><div><strong>Mostrando ' + from + '-' + to + '</strong><span> de ' + total + ' turnos</span></div><div class="page-controls"><button class="secondary" data-action="prevScheduleHistoryPage" ' + (page <= 1 ? 'disabled' : '') + '>‹ Anterior</button>' + buttons.join('') + '<button class="secondary" data-action="nextScheduleHistoryPage" ' + (page >= totalPages ? 'disabled' : '') + '>Siguiente ›</button></div></div>';
}
function setScheduleHistoryPage(page) {
    scheduleHistoryPage = Number(page || 1);
    renderSchedule();
}
function changeScheduleHistoryPage(delta) {
    scheduleHistoryPage += Number(delta || 0);
    renderSchedule();
}

function scheduleOrderColor(orderId, isBlock) {
    if (isBlock) {
        return { bg: "#e2e8f0", accent: "#64748b", text: "#0f172a" };
    }
    var palette = [
        { bg: "#38bdf8", accent: "#0284c7", text: "#082f49" },
        { bg: "#a78bfa", accent: "#7c3aed", text: "#2e1065" },
        { bg: "#34d399", accent: "#059669", text: "#064e3b" },
        { bg: "#fda4af", accent: "#e11d48", text: "#4c0519" },
        { bg: "#fbbf24", accent: "#d97706", text: "#451a03" },
        { bg: "#67e8f9", accent: "#0891b2", text: "#083344" },
        { bg: "#93c5fd", accent: "#2563eb", text: "#172554" },
        { bg: "#c4b5fd", accent: "#8b5cf6", text: "#312e81" }
    ];
    var numeric = Number(orderId);
    var index = (isNaN(numeric) ? 0 : Math.abs(numeric)) % palette.length;
    return palette[index];
}
function scheduleCycleBlockLayouts(dayCycles, selectedDate, slotMinutes) {
    var slots = dailyScheduleSlots(selectedDate, slotMinutes);
    if (!slots.length)
        return [];
    var slotMs = Number(slotMinutes || 30) * 60000;
    var firstStart = slots[0].start.getTime();
    var lastEnd = slots[slots.length - 1].start.getTime() + slotMs;
    var orderMap = {};
    dayCycles.forEach(function (cycle) {
        var startMs = Math.max(new Date(cycle.start).getTime(), firstStart);
        var endMs = Math.min(new Date(cycle.end).getTime(), lastEnd);
        var startIndex = Math.max(0, Math.floor((startMs - firstStart) / slotMs));
        var endIndex = Math.max(startIndex + 1, Math.ceil((endMs - firstStart) / slotMs));
        var orderKey = String(cycle.order && cycle.order.id != null ? cycle.order.id : cycle.cycleId);
        if (!orderMap[orderKey]) {
            orderMap[orderKey] = {
                key: orderKey,
                orderId: cycle.order && cycle.order.id,
                startMs: startMs,
                endMs: endMs,
                cycles: []
            };
        }
        orderMap[orderKey].startMs = Math.min(orderMap[orderKey].startMs, startMs);
        orderMap[orderKey].endMs = Math.max(orderMap[orderKey].endMs, endMs);
        orderMap[orderKey].cycles.push({
            cycle: cycle,
            startMs: startMs,
            endMs: endMs,
            startIndex: startIndex,
            endIndex: Math.min(slots.length, endIndex)
        });
    });
    var orderItems = Object.keys(orderMap).map(function (key) { return orderMap[key]; }).sort(function (a, b) {
        if (a.startMs !== b.startMs)
            return a.startMs - b.startMs;
        return b.endMs - a.endMs;
    });
    var groups = [];
    var current = null;
    orderItems.forEach(function (item) {
        if (!current || item.startMs >= current.maxEnd) {
            current = { items: [item], maxEnd: item.endMs };
            groups.push(current);
            return;
        }
        current.items.push(item);
        current.maxEnd = Math.max(current.maxEnd, item.endMs);
    });
    var layouts = [];
    groups.forEach(function (group) {
        var columnEnds = [];
        var maxCols = 0;
        group.items.forEach(function (item) {
            var column = -1;
            for (var index = 0; index < columnEnds.length; index += 1) {
                if (item.startMs >= columnEnds[index]) {
                    column = index;
                    break;
                }
            }
            if (column === -1) {
                column = columnEnds.length;
                columnEnds.push(item.endMs);
            }
            else {
                columnEnds[column] = item.endMs;
            }
            item.column = column;
            maxCols = Math.max(maxCols, columnEnds.length);
        });
        group.items.forEach(function (item) {
            var color = scheduleOrderColor(item.orderId, Boolean(item.cycles[0] && item.cycles[0].cycle.order && item.cycles[0].cycle.order.block));
            item.cycles.sort(function (a, b) { return a.startMs - b.startMs; }).forEach(function (cycleLayout) {
                cycleLayout.column = item.column;
                cycleLayout.columns = maxCols;
                cycleLayout.color = color;
                layouts.push(cycleLayout);
            });
        });
    });
    return layouts;
}
function scheduleCycleBlockHtml(layout, rowHeight) {
    var cycle = layout.cycle;
    var hasMachine = Boolean(cycle.machine);
    var machineLabel = canonicalMachineName(cycle.machine) || (cycle.type === "Secado" ? "Secadora pendiente" : cycle.type === "Lavado" ? "Lavadora pendiente" : "Sin máquina");
    var serviceLabel = cycle.order && !cycle.order.block ? serviceSummary(cycle.order) : cycle.type;
    var clientLabel = cycle.order && cycle.order.block ? (cycle.description || "Reserva") : orderClient(cycle.order);
    var codeLabel = cycle.order && cycle.order.block ? "Bloqueo" : orderDisplayCode(cycle.order);
    var timeLabel = formatShortDateTime(cycle.start).slice(-5) + " - " + formatShortDateTime(cycle.end).slice(-5);
    var top = layout.startIndex * rowHeight;
    var height = Math.max(rowHeight, (layout.endIndex - layout.startIndex) * rowHeight);
    var leftPct = (layout.column * 100) / layout.columns;
    var widthPct = 100 / layout.columns;
    var color = layout.color || scheduleOrderColor(cycle.order && cycle.order.id, cycle.order && cycle.order.block);
    var style = "top:" + top + "px;left:calc(" + leftPct + "% + 4px);width:calc(" + widthPct + "% - 8px);height:" + height + "px;--agenda-bg:" + color.bg + ";--agenda-accent:" + color.accent + ";--agenda-text:" + color.text + ";";
    var typeClass = cycle.type === "Secado" ? "dry" : cycle.type === "Bloqueo" ? "blocked" : "wash";
    var assignClass = hasMachine ? "assigned-cycle" : "unassigned-cycle";
    var orderStatus = cycle.order && !cycle.order.block ? cycle.order.status : "";
    var statusClass = orderStatus === "Listo" ? "status-listo" : orderStatus === "Retirado" ? "status-retirado" : "";
    var machineAlertHtml = hasMachine ? "" : '<span class="agenda-corner-warning" title="Sin máquina asignada" aria-label="Sin máquina asignada">!</span>';
    var statusBadgeHtml = statusClass ? '<span class="agenda-cycle-status-badge ' + statusClass + '">' + escapeHtml(orderStatus) + '</span>' : "";
    return '<button class="agenda-cycle-block ' + assignClass + ' ' + typeClass + ' ' + statusClass + '" style="' + style + '" draggable="true" data-drop-time data-slot-start="' + escapeHtml(cycle.start) + '" data-drag-cycle data-id="' + cycle.order.id + '" data-cycle-id="' + escapeHtml(cycle.cycleId) + '" data-action="openCycleEdit">' +
        machineAlertHtml +
        '<div class="agenda-cycle-top"><span class="agenda-cycle-time">' + escapeHtml(timeLabel) + '</span><span class="agenda-cycle-stage">' + escapeHtml(cycle.type) + '</span>' + statusBadgeHtml + '</div>' +
        '<strong class="agenda-cycle-client">' + escapeHtml(clientLabel) + '</strong>' +
        '<span class="agenda-cycle-meta">' + escapeHtml(codeLabel + ' · ') + '<span class="agenda-machine-name">' + escapeHtml(machineLabel) + '</span></span>' +
        '<small class="agenda-cycle-service">' + escapeHtml(serviceLabel) + '</small>' +
        '</button>';
}
function scheduleDayAgendaHtml(calendarCycles, selectedDate) {
    var key = dateKey(selectedDate);
    var dayCycles = calendarCycles.filter(function (cycle) { return dateKey(cycle.start) === key; });
    var slotMinutes = 30;
    var rowHeight = 88;
    var slots = dailyScheduleSlots(selectedDate, slotMinutes);
    var rows = slots.map(function (slot) {
        var iso = slot.start.toISOString();
        return '<div class="agenda-grid-row"><button class="agenda-grid-time" type="button" data-action="openSlotAvailability" data-slot-start="' + iso + '" aria-label="Ver disponibilidad en ' + escapeHtml(slot.label) + '"><span>' + escapeHtml(slot.label) + '</span><small>ver</small></button><div class="agenda-grid-lane" data-action="openSlotAvailability" data-drop-time data-slot-start="' + iso + '"></div></div>';
    }).join('');
    var layouts = scheduleCycleBlockLayouts(dayCycles, selectedDate, slotMinutes);
    var blocks = layouts.map(function (layout) { return scheduleCycleBlockHtml(layout, rowHeight); }).join('');
    var emptyState = !blocks ? '<div class="agenda-empty-state">Tocá una franja horaria para ver disponibilidad o ubicar un pedido.</div>' : '';
    var totalHeight = slots.length * rowHeight;
    return '<div class="card day-agenda simple-day-agenda"><div class="simple-section-title"><h3>Agenda de hoy</h3><label class="simple-date-picker date-picker-label">Fecha <span class="calendar-input-wrap"><input id="scheduleDatePicker" class="week-input date-picker-input" type="date" data-schedule-date value="' + escapeHtml(scheduleSelectedDate) + '" inputmode="none" /><button class="calendar-open-button" type="button" data-action="openDatePicker" data-target="scheduleDatePicker" aria-label="Abrir calendario">📅</button></span></label></div><div class="agenda-grid-board"><div class="agenda-grid-rows" style="height:' + totalHeight + 'px;">' + rows + '</div><div class="agenda-grid-blocks" style="height:' + totalHeight + 'px;">' + blocks + emptyState + '</div></div></div>';
}
function scheduleAgendaGroup(cycles, label) {
    cycles.sort(function (a, b) { return new Date(a.start) - new Date(b.start); });
    return '<section class="agenda-group"><h4>' + escapeHtml(label) + '</h4>' + (cycles.map(function (cycle) { return '<article class="agenda-item"><div class="agenda-time"><strong>' + formatShortDateTime(cycle.start).slice(-5) + ' - ' + formatShortDateTime(cycle.end).slice(-5) + '</strong><small>' + escapeHtml(cycle.type) + '</small></div><div class="agenda-machine">' + escapeHtml(canonicalMachineName(cycle.machine)) + '</div><div><strong>' + escapeHtml(cyclePersonLabel(cycle)) + '</strong></div><div class="actions mini"><button class="secondary" data-action="openCycleEdit" data-id="' + cycle.order.id + '" data-cycle-id="' + escapeHtml(cycle.cycleId) + '">Mover</button></div></article>'; }).join('') || '<p>Sin trabajos.</p>') + '</section>';
}

function scheduleSlotHtml(day, slot, activeCycles) {
    var start = new Date(day);
    start.setHours(Math.floor(slot.minutes / 60), slot.minutes % 60, 0, 0);
    var end = new Date(start.getTime() + Number(scheduleSlotMinutes || 30) * 60000);
    var cycles = activeCycles.filter(function (cycle) { return cycleOverlapsRange(cycle, start, end); });
    return "<div class=\"timeline-cell schedule-slot\">".concat(cycles.map(function (cycle) { return "<button class=\"timeline-event ".concat(cycle.type === "Lavado" ? "wash" : cycle.type === "Bloqueo" ? "blocked-slot" : "dry", "\" data-action=\"openCycleEdit\" data-id=\"").concat(cycle.order.id, "\" data-cycle-id=\"").concat(escapeHtml(cycle.cycleId), "\"><strong>").concat(escapeHtml(cycle.type === "Bloqueo" ? cycle.description || "Bloqueo" : orderClient(cycle.order)), "</strong><span>").concat(escapeHtml(cycle.type), " · ").concat(escapeHtml(canonicalMachineName(cycle.machine)), "</span><small>").concat(formatDateTime(cycle.start), " → ").concat(formatDateTime(cycle.end), "</small></button>"); }).join("") || "<span class=\"free-text\">Libre</span>", "</div>");
}
function setScheduleWeek(value) {
    setScheduleDate(value);
}
function moveScheduleWeek(days) {
    var next = new Date("".concat(scheduleSelectedDate, "T00:00:00"));
    next.setDate(next.getDate() + days);
    setScheduleDate(next.toISOString().slice(0, 10));
}
function machineBoard(machines, activeCycles) {
    return "<div class=\"machine-board simple-machine-grid\">".concat(machines.map(function (machine) {
        var current = currentCycleForMachine(machine.name, activeCycles);
        var status = machineStatusLabel(machine, current);
        var stateClass = current ? current.type === "Bloqueo" ? "reserved" : "working" : "free";
        return "<article class=\"machine simple-machine-card ".concat(stateClass, " type-").concat(normalizeClass(machine.type), "\"><strong>").concat(escapeHtml(machine.name), "</strong><span>").concat(escapeHtml(status), "</span><small>").concat(escapeHtml(current ? cyclePersonLabel(current) : "Libre"), "</small>").concat(current ? "<em>Hasta " + formatShortDateTime(current.end).slice(-5) + "</em>" : "", "</article>");
    }).join(""), "</div>");
}

function cycleOptionHtml(selected) {
    return '<option '.concat(selected === "Lavado" ? "selected" : "", '>Lavado</option><option ').concat(selected === "Secado" ? "selected" : "", '>Secado</option><option ').concat(selected === "Bloqueo" ? "selected" : "", '>Bloqueo</option><option ').concat(selected === "Preparación" ? "selected" : "", '>Preparación</option>');
}
function machineOptionsHtml(selected) {
    var options = '<option value="" ' + (!selected ? 'selected' : '') + '>Sin máquina asignada</option>';
    return options + scheduleMachines().map(function (machine) { var record = getMachineRecord(machine.name); var disabled = record.status !== "ok" && machine.name !== selected; return '<option value="'.concat(escapeHtml(machine.name), '" ').concat(machine.name === selected ? 'selected' : '', ' ').concat(disabled ? 'disabled' : '', '>').concat(escapeHtml(machine.name), disabled ? ' · ' + escapeHtml(machineStatusLabelFromRecord(record)) : '', '</option>'); }).join('');
}
function updateSchedulePreview(container) {
    if (!container)
        return;
    var target = container.querySelector(".schedule-preview-note");
    if (!target)
        return;
    var startInput = container.querySelector('[name="start"]');
    var minutesInput = container.querySelector('[name="minutes"]');
    var machineSelect = container.querySelector('[name="machine"]');
    var machineButton = container.querySelector('[data-action="saveMachineSlot"]');
    var machine = machineSelect ? machineSelect.value : machineButton ? machineButton.getAttribute("data-machine") : "";
    var start = startInput ? new Date(startInput.value) : null;
    var minutes = minutesInput ? Number(minutesInput.value || 0) : 0;
    if (!start || isNaN(start.getTime()) || !minutes) {
        target.textContent = "Vista previa: completá inicio y duración.";
        return;
    }
    var end = new Date(start.getTime() + minutes * 60000);
    var conflicts = machine ? machineConflicts(machine, start, end) : [];
    var openMinutes = Number(state.settings.openHour.split(":")[0]) * 60;
    var closeMinutes = Number(state.settings.closeHour.split(":")[0]) * 60;
    var startMinutes = start.getHours() * 60 + start.getMinutes();
    var endMinutes = end.getHours() * 60 + end.getMinutes();
    var outside = startMinutes < openMinutes || endMinutes > closeMinutes;
    target.textContent = "Vista previa: termina " + formatDateTime(end) + (conflicts.length ? " · choca con " + conflicts.length + " trabajo(s)" : " · libre") + (outside ? " · fuera del horario del local" : "");
}
function openMachineModal(machineName) {
    selectedMachine = machineName;
    var activeCycles = activeScheduleCycles();
    var current = currentCycleForMachine(machineName, activeCycles);
    var next = nextCycleForMachine(machineName, activeCycles);
    var machineType = machineName.indexOf("Secadora") === 0 ? "Secado" : "Lavado";
    var defaultMinutes = machineType === "Secado" ? state.settings.dryingMinutes : state.settings.washingMinutes;
    var orderOptions = operationalOrders().filter(function (order) { return order.status === "Pendiente"; }).map(function (order) { return "<option value=\"".concat(order.id, "\">").concat(escapeHtml(orderDisplayCode(order)), " · ").concat(escapeHtml(orderClient(order)), "</option>"); }).join("");
    var statusHtml = current
        ? '<div class="machine-simple-status busy"><span>Ocupada</span><strong>' + escapeHtml(cyclePersonLabel(current)) + '</strong><small>Termina ' + formatShortDateTime(current.end).slice(-5) + '</small></div><div class="machine-simple-actions"><button class="primary" data-action="finishCycleNow" data-id="' + current.order.id + '" data-cycle-id="' + escapeHtml(current.cycleId) + '">Terminó</button><button class="secondary" data-action="shiftCycle" data-minutes="15" data-id="' + current.order.id + '" data-cycle-id="' + escapeHtml(current.cycleId) + '">+15 min</button><button class="secondary" data-action="openCycleEdit" data-id="' + current.order.id + '" data-cycle-id="' + escapeHtml(current.cycleId) + '">Cambiar</button></div>'
        : '<div class="machine-simple-status free"><span>Libre</span><strong>' + escapeHtml(machineName) + '</strong><small>Lista para usar</small></div>';
    var nextHtml = next && (!current || String(next.cycleId) !== String(current.cycleId)) ? '<p class="schedule-help">Sigue: ' + escapeHtml(cyclePersonLabel(next)) + ' a las ' + formatShortDateTime(next.start).slice(-5) + '.</p>' : '';
    var assignHtml = '<details class="simple-assign-details" ' + (current ? '' : 'open') + '><summary>' + (current ? 'Agregar otro trabajo' : 'Asignar pedido ahora') + '</summary><form class="form-grid machine-assign-form simple-assign-form"><label class="full">Pedido<select name="orderId" required>' + (orderOptions || '<option value="">No hay pedidos pendientes</option>') + '</select></label><label>Minutos<input name="minutes" type="number" min="1" value="' + Number(defaultMinutes || 30) + '" required /></label><button class="primary full" type="button" data-action="saveQuickMachineSlot" data-machine="' + escapeHtml(machineName) + '" data-type="' + escapeHtml(machineType) + '">Guardar</button></form></details>';
    openModal(escapeHtml(machineName), '<div class="simple-machine-modal">' + statusHtml + nextHtml + assignHtml + '</div>');
}

function touchOrderCycle(order, cycle) {
    // El historial de turnos se usa como log: esta fecha debe ser la fecha/hora real de la PC, no la fecha de agenda.
    var stamp = new Date().toISOString();
    if (cycle)
        cycle.updatedAt = stamp;
    if (order)
        order.updatedAt = stamp;
}
function addCycleToOrder(order, cycle) {
    order.cycles = order.cycles || [];
    cycle.cycleId = cycle.cycleId || nextCycleId(order.id, order.cycles.length);
    touchOrderCycle(order, cycle);
    order.cycles.push(cycle);
    refreshOrderEstimate(order);
}
function saveMachineSlot(button) {
    var form = button.closest("form");
    var data = formDataToObject(form);
    var order = getOrder(data.orderId);
    if (!order) {
        alert("Elegí un pedido activo.");
        return;
    }
    var start = new Date(data.start);
    if (isNaN(start.getTime())) {
        alert("Indicá fecha y hora de inicio.");
        return;
    }
    var minutes = Number(data.minutes || 0);
    if (!minutes) {
        alert("Indicá duración en minutos.");
        return;
    }
    var end = new Date(start.getTime() + minutes * 60000);
    var conflicts = machineConflicts(button.getAttribute("data-machine"), start, end);
    if (conflicts.length && !confirm("Este horario choca con otro trabajo en la misma máquina. ¿Guardar igual?"))
        return;
    addCycleToOrder(order, { type: data.type || "Preparación", machine: button.getAttribute("data-machine"), start: start.toISOString(), end: end.toISOString(), minutes: minutes, manual: true });
    saveState();
    closeModal();
    render();
}
function selectScheduleTicket(id) {
    selectedScheduleTicketId = Number(id || 0);
    renderSchedule();
}
function assignSelectedTicketToMachine(machineName, machineType) {
    if (!selectedScheduleTicketId) {
        openMachineModal(machineName);
        return;
    }
    assignOrderToMachineFromDrop(selectedScheduleTicketId, machineName, machineType);
}
function nextFreeSlotForMachine(machineName, durationMinutes, fromDate) {
    var cursor = LaundryScheduler.normalizeBusinessStart(fromDate || schedulePlanningStart(), state.settings);
    var guard = 0;
    while (guard < 80) {
        var end = new Date(cursor.getTime() + Number(durationMinutes || 30) * 60000);
        if (!machineConflicts(machineName, cursor, end).length)
            return { start: cursor, end: end };
        cursor = new Date(cursor.getTime() + Number(scheduleSlotMinutes || 30) * 60000);
        cursor = LaundryScheduler.normalizeBusinessStart(cursor, state.settings);
        guard += 1;
    }
    return null;
}
function clearAutomaticCycles(order) {
    order.cycles = [];
}
function cyclesForServiceFromType(order, firstType) {
    var service = getService(order.serviceId) || state.services[0];
    var cycles = [];
    if (firstType === "Secado")
        cycles.push({ type: "Secado", minutes: Number(state.settings.dryingMinutes || 50) });
    else {
        cycles.push({ type: "Lavado", minutes: Number(state.settings.washingMinutes || 30) });
        if (service && service.dry)
            cycles.push({ type: "Secado", minutes: Number(state.settings.dryingMinutes || 50) });
    }
    return cycles;
}
function firstAvailableMachine(type, start, minutes, preferredMachine) {
    var machines = scheduleMachines().filter(function (machine) { return machine.type === type; });
    if (preferredMachine)
        machines.sort(function (a, b) { return a.name === preferredMachine ? -1 : b.name === preferredMachine ? 1 : 0; });
    for (var index = 0; index < machines.length; index += 1) {
        var end = LaundryScheduler.addWorkingMinutes(start, minutes, state.settings);
        if (!machineConflicts(machines[index].name, start, end).length)
            return { machine: machines[index].name, start: start, end: end };
    }
    return null;
}
function nextSlotAnyMachine(type, minutes, fromDate, preferredMachine) {
    var cursor = LaundryScheduler.normalizeBusinessStart(fromDate || schedulePlanningStart(), state.settings);
    var guard = 0;
    while (guard < 120) {
        var slot = firstAvailableMachine(type, cursor, minutes, preferredMachine);
        if (slot)
            return slot;
        cursor = new Date(cursor.getTime() + 15 * 60000);
        cursor = LaundryScheduler.normalizeBusinessStart(cursor, state.settings);
        guard += 1;
    }
    return null;
}
function assignOrderSequence(order, firstType, firstMachine, startAt) {
    clearAutomaticCycles(order);
    var cursor = LaundryScheduler.normalizeBusinessStart(startAt || schedulePlanningStart(), state.settings);
    var requested = cyclesForServiceFromType(order, firstType);
    for (var index = 0; index < requested.length; index += 1) {
        var preferred = index === 0 ? firstMachine : "";
        var slot = nextSlotAnyMachine(requested[index].type, requested[index].minutes, cursor, preferred);
        if (!slot)
            return false;
        addCycleToOrder(order, { type: requested[index].type, machine: slot.machine, start: slot.start.toISOString(), end: slot.end.toISOString(), minutes: requested[index].minutes, manual: index === 0 });
        cursor = slot.end;
    }
    return true;
}
function assignOrderSequenceWithoutMachine(order, firstType, startAt) {
    clearAutomaticCycles(order);
    var cursor = LaundryScheduler.normalizeBusinessStart(startAt || schedulePlanningStart(), state.settings);
    var requested = cyclesForServiceFromType(order, firstType);
    for (var index = 0; index < requested.length; index += 1) {
        var start = new Date(cursor);
        var end = LaundryScheduler.addWorkingMinutes(start, requested[index].minutes, state.settings);
        addCycleToOrder(order, { type: requested[index].type, machine: "", start: start.toISOString(), end: end.toISOString(), minutes: requested[index].minutes, manual: true, pendingMachine: true });
        cursor = end;
    }
    return true;
}
function assignOrderToCalendarTime(orderId, slotStart) {
    var order = getOrder(orderId);
    var start = new Date(slotStart);
    if (!order || isNaN(start.getTime()))
        return;
    var service = getService(order.serviceId) || state.services[0];
    var firstType = service && service.dry && !(service && service.wash) ? "Secado" : "Lavado";
    assignOrderSequenceWithoutMachine(order, firstType, start);
    selectedScheduleTicketId = 0;
    saveState();
    renderSchedule();
}
function scheduleSlotAvailability(slotStart, durationMinutes) {
    var start = new Date(slotStart);
    var end = new Date(start.getTime() + Number(durationMinutes || scheduleSlotMinutes || 30) * 60000);
    var result = {};
    ["Lavado", "Secado"].forEach(function (type) {
        var machines = scheduleMachines().filter(function (machine) { return machine.type === type; });
        var available = [];
        var occupied = [];
        machines.forEach(function (machine) {
            var conflicts = machineConflicts(machine.name, start, end);
            if (conflicts.length)
                occupied.push({ machine: machine.name, conflict: conflicts[0] });
            else
                available.push(machine.name);
        });
        result[type] = { available: available, occupied: occupied, total: machines.length };
    });
    return { start: start, end: end, Lavado: result.Lavado, Secado: result.Secado };
}
function slotMachineListHtml(items) {
    return items.length ? items.map(function (name) { return '<span class="machine-mini-chip">' + escapeHtml(name) + '</span>'; }).join('') : '<span class="muted-inline">Ninguna</span>';
}
function openScheduleSlotAvailabilityModal(slotStart) {
    var slot = scheduleSlotAvailability(slotStart, scheduleSlotMinutes || 30);
    if (isNaN(slot.start.getTime()))
        return;
    var selectedOrder = selectedScheduleTicketId ? getOrder(selectedScheduleTicketId) : null;
    var orderService = selectedOrder ? (getService(selectedOrder.serviceId) || state.services[0]) : null;
    var firstType = orderService && orderService.dry && !(orderService && orderService.wash) ? "Secado" : "Lavado";
    var relevant = firstType === "Secado" ? slot.Secado : slot.Lavado;
    var assignmentHtml = '';
    if (selectedOrder) {
        var machineButtons = relevant.available.map(function (machineName) {
            return '<button class="secondary" type="button" data-action="assignSelectedTicketToSlotMachine" data-slot-start="' + escapeHtml(slot.start.toISOString()) + '" data-machine="' + escapeHtml(machineName) + '" data-machine-type="' + escapeHtml(firstType) + '">Asignar a ' + escapeHtml(machineName) + '</button>';
        }).join('');
        assignmentHtml = '<div class="slot-assignment-box"><p><strong>Pedido seleccionado:</strong> ' + escapeHtml(customerOrderCode(selectedOrder)) + ' · ' + escapeHtml(orderClient(selectedOrder)) + '</p><div class="actions"><button class="primary" type="button" data-action="assignSelectedTicketToSlot" data-slot-start="' + escapeHtml(slot.start.toISOString()) + '">Ubicar en esta hora sin máquina</button>' + (machineButtons || '<button class="secondary" type="button" disabled>No hay máquinas libres para el primer ciclo</button>') + '</div></div>';
    }
    else {
        assignmentHtml = '<p class="slot-help-text">Seleccioná primero un ticket pendiente de la columna derecha y después hacé clic en una hora para asignarlo desde este cartel.</p>';
    }
    var html = '<div class="slot-availability-modal">' +
        '<div class="slot-time-banner"><span>Horario elegido</span><strong>' + formatShortDateTime(slot.start).slice(-5) + ' - ' + formatShortDateTime(slot.end).slice(-5) + '</strong></div>' +
        '<div class="slot-availability-grid">' +
        '<article><span>Lavadoras disponibles</span><strong>' + slot.Lavado.available.length + '/' + slot.Lavado.total + '</strong><div class="machine-chip-list">' + slotMachineListHtml(slot.Lavado.available) + '</div></article>' +
        '<article><span>Secadoras disponibles</span><strong>' + slot.Secado.available.length + '/' + slot.Secado.total + '</strong><div class="machine-chip-list">' + slotMachineListHtml(slot.Secado.available) + '</div></article>' +
        '</div>' + assignmentHtml + '</div>';
    openModal('Disponibilidad de máquinas', html);
}
function assignSelectedTicketToSlot(slotStart) {
    if (!selectedScheduleTicketId) {
        alert('Seleccioná primero un ticket pendiente.');
        return;
    }
    assignOrderToCalendarTime(selectedScheduleTicketId, slotStart);
    closeModal();
}
function assignSelectedTicketToSlotMachine(slotStart, machineName, machineType) {
    if (!selectedScheduleTicketId) {
        alert('Seleccioná primero un ticket pendiente.');
        return;
    }
    var order = getOrder(selectedScheduleTicketId);
    var start = new Date(slotStart);
    if (!order || isNaN(start.getTime()) || !machineName)
        return;
    var ok = assignOrderSequence(order, machineType === "Secado" ? "Secado" : "Lavado", machineName, start);
    if (!ok) {
        alert('No hay hueco disponible para esa máquina en ese horario.');
        return;
    }
    selectedScheduleTicketId = 0;
    saveState();
    closeModal();
    renderSchedule();
}
function assignOrderToMachineFromDrop(orderId, machineName, machineType) {
    var order = getOrder(orderId);
    if (!order || !machineName)
        return;
    var ok = assignOrderSequence(order, machineType === "Secado" ? "Secado" : "Lavado", machineName, schedulePlanningStart());
    if (!ok) {
        alert("No hay hueco disponible.");
        return;
    }
    selectedScheduleTicketId = 0;
    saveState();
    renderSchedule();
}

function moveCycleToMachineName(orderId, cycleId, machineName) {
    var found = findOrderCycle(orderId, cycleId);
    if (!found || !machineName)
        return;
    var start = new Date(found.cycle.start);
    var end = new Date(found.cycle.end);
    var conflicts = machineConflicts(machineName, start, end, found.order.id, found.cycle.cycleId);
    if (conflicts.length && !confirm("Esa máquina está ocupada en ese horario. ¿Mover igual?"))
        return;
    found.cycle.machine = machineName;
    found.cycle.manual = true;
    touchOrderCycle(found.order, found.cycle);
    refreshOrderEstimate(found.order);
    saveState();
    renderSchedule();
}
function moveCycleToTime(orderId, cycleId, newStart) {
    var found = findOrderCycle(orderId, cycleId);
    if (!found) return;
    var start = new Date(newStart);
    if (isNaN(start.getTime())) return;
    var delta = start.getTime() - new Date(found.cycle.start).getTime();
    var cycles = found.order.cycles || [];
    for (var i = 0; i < cycles.length; i += 1) {
        cycles[i].start = new Date(new Date(cycles[i].start).getTime() + delta).toISOString();
        cycles[i].end = new Date(new Date(cycles[i].end).getTime() + delta).toISOString();
        cycles[i].manual = true;
        touchOrderCycle(found.order, cycles[i]);
    }
    refreshOrderEstimate(found.order);
    saveState();
    renderSchedule();
}
function calculateScheduleFromSelectedTime() {
    var start = schedulePlanningStart();
    var orders = operationalOrders().filter(function (order) { return order.status === "Pendiente" && !order.block; }).sort(function (a, b) { return new Date(a.createdAt) - new Date(b.createdAt); });
    orders.forEach(function (order) {
        var manual = (order.cycles || []).filter(function (cycle) { return cycle.manual; });
        order.cycles = manual;
        if (manual.length)
            return;
        var service = getService(order.serviceId) || state.services[0];
        var scheduled = LaundryScheduler.scheduleOrder(state.orders, service, state.settings, start.toISOString());
        order.cycles = scheduled.cycles;
        ensureOrderCycleIds(order);
        refreshOrderEstimate(order);
    });
    saveState();
    renderSchedule();
}
function saveQuickMachineSlot(button) {
    var form = button.closest("form");
    var data = formDataToObject(form);
    var order = getOrder(data.orderId);
    if (!order) {
        alert("Elegí un pedido pendiente.");
        return;
    }
    var start = schedulePlanningStart();
    var minutes = Number(data.minutes || 0);
    if (!minutes) {
        alert("Indicá duración en minutos.");
        return;
    }
    var end = new Date(start.getTime() + minutes * 60000);
    var machine = button.getAttribute("data-machine");
    var conflicts = machineConflicts(machine, start, end);
    if (conflicts.length && !confirm("Esta máquina ya tiene un trabajo en ese horario. ¿Guardarlo igual?"))
        return;
    addCycleToOrder(order, { type: button.getAttribute("data-type") || "Lavado", machine: machine, start: start.toISOString(), end: end.toISOString(), minutes: minutes, manual: true });
    saveState();
    closeModal();
    render();
}
function findOrderCycle(orderId, cycleId) {
    var order = getOrder(orderId);
    if (!order)
        return null;
    ensureOrderCycleIds(order);
    for (var index = 0; index < (order.cycles || []).length; index += 1) {
        if (String(order.cycles[index].cycleId) === String(cycleId))
            return { order: order, cycle: order.cycles[index], index: index };
    }
    return null;
}
function cycleMachineType(cycle) { return cycle && cycle.type === "Secado" ? "Secado" : "Lavado"; }
function isMachineNameAvailable(machineName, startTime, endTime, currentScheduledTurnId) {
    var ids = String(currentScheduledTurnId || ":").split(":");
    var found = findOrderCycle(ids[0], ids[1]);
    var ignoreOrderId = found ? found.order.id : 0;
    var ignoreCycleId = found ? found.cycle.cycleId : "";
    return !machineConflicts(machineName, new Date(startTime), new Date(endTime), ignoreOrderId, ignoreCycleId).length;
}
function isResourceAvailable(resourceType, machineNumber, startTime, endTime, currentScheduledTurnId) {
    var machineName = (resourceType === "Secado" ? "Secadora " : "Lavarropas ") + String(machineNumber);
    return isMachineNameAvailable(machineName, startTime, endTime, currentScheduledTurnId);
}
function machineAvailabilityBoxes(startTime, endTime, currentScheduledTurnId) {
    return "";
}
function openMachineAssignModal(orderId, cycleId) {
    var found = findOrderCycle(orderId, cycleId); if (!found) return;
    var currentCycle = found.cycle;
    var currentType = currentCycle.type === "Secado" ? "Secado" : "Lavado";
    var selectLabel = currentType === "Secado" ? "Secadora" : "Lavarropas";
    function machineOptions(type, cycle) {
        var machines = scheduleMachines().filter(function (machine) { return machine.type === type; });
        var currentMachine = cycle && cycle.machine ? canonicalMachineName(cycle.machine) : "";
        var currentId = cycle ? String(found.order.id) + ":" + String(cycle.cycleId) : "";
        var opts = '<option value="">' + (type === "Secado" ? "Elegir secadora" : "Elegir lavarropas") + '</option>';
        machines.forEach(function (machine) {
            var blockedRecord = getMachineRecord(machine.name);
            var blocked = blockedRecord && blockedRecord.status !== "ok";
            var free = cycle ? isMachineNameAvailable(machine.name, cycle.start, cycle.end, currentId) : !blocked;
            var selected = currentMachine === canonicalMachineName(machine.name);
            var suffix = free ? ' (libre)' : blocked ? ' (bloqueada · En mantenimiento)' : ' (ocupada)';
            opts += '<option value="' + escapeHtml(machine.name) + '" ' + (selected ? 'selected' : '') + ' ' + (free ? '' : 'disabled') + '>' + escapeHtml(machine.name) + suffix + '</option>';
        });
        return opts;
    }
    var helperText = currentType === "Secado"
        ? 'Estás asignando el tramo de secado. Acá solo aparecen secadoras.'
        : 'Estás asignando el tramo de lavado. Acá solo aparecen lavarropas.';
    var html = '<form class="form-grid single-machine-assign-form"><label class="full">' + selectLabel + '<select name="machine">' + machineOptions(currentType, currentCycle) + '</select></label><p class="full assign-machine-helper">' + helperText + '</p><div class="actions full"><button class="primary" type="button" data-action="saveCycleMachine" data-id="' + found.order.id + '" data-cycle-id="' + escapeHtml(found.cycle.cycleId) + '">Guardar</button><button class="secondary" type="button" data-close-modal>Cancelar</button><button class="danger" type="button" data-action="clearCycleMachine" data-id="' + found.order.id + '" data-cycle-id="' + escapeHtml(found.cycle.cycleId) + '">Quitar asignación</button><button class="danger remove-calendar-button" type="button" data-action="removeOrderSchedule" data-id="' + found.order.id + '">Remover del calendario</button></div></form>';
    openModal(currentType === "Secado" ? "Asignar secadora" : "Asignar lavarropas", html);
}
function saveCycleMachine(button) {
    var found = findOrderCycle(button.getAttribute("data-id"), button.getAttribute("data-cycle-id")); if (!found) return;
    var data = formDataToObject(button.closest("form"));
    var machine = canonicalMachineName(data.machine || "");
    var typeLabel = found.cycle.type === "Secado" ? "secadora" : "lavarropas";
    if (machine && !isMachineNameAvailable(machine, found.cycle.start, found.cycle.end, String(found.order.id)+":"+String(found.cycle.cycleId))) {
        alert("Ese " + typeLabel + " ya está ocupado en ese horario.");
        return;
    }
    found.cycle.machine = machine || "";
    found.cycle.pendingMachine = !machine;
    touchOrderCycle(found.order, found.cycle);
    saveCycleAndRefresh(found);
}
function removeOrderSchedule(orderId) {
    var order = getOrder(orderId);
    if (!order || !(order.cycles || []).length)
        return;
    if (!confirm("¿Remover este pedido del calendario? El pedido queda pendiente y vuelve a poder ubicarse más tarde."))
        return;
    order.cycles = (order.cycles || []).filter(function (cycle) { return cycle.type === "Preparación"; });
    if (!order.cycles.length)
        order.estimate = order.createdAt || new Date().toISOString();
    else
        refreshOrderEstimate(order);
    saveState();
    closeModal();
    renderSchedule();
}
function clearCycleMachine(orderId, cycleId) {
    var found = findOrderCycle(orderId, cycleId); if (!found) return;
    found.cycle.machine = ""; found.cycle.pendingMachine = true;
    touchOrderCycle(found.order, found.cycle);
    saveCycleAndRefresh(found);
}
function openCycleEditModal(orderId, cycleId) {
    var found = findOrderCycle(orderId, cycleId);
    if (!found)
        return;
    var cycle = found.cycle;
    var start = localDateTimeValue(cycle.start);
    var html = '<div class="cycle-quick-actions"><button class="cycle-quick-button" data-action="shiftCycle" data-minutes="15" data-id="'.concat(found.order.id, '" data-cycle-id="').concat(escapeHtml(cycle.cycleId), '">+15 min</button><button class="cycle-quick-button" data-action="shiftCycle" data-minutes="-15" data-id="').concat(found.order.id, '" data-cycle-id="').concat(escapeHtml(cycle.cycleId), '">-15 min</button><button class="cycle-quick-button" data-action="moveCycleNextFree" data-id="').concat(found.order.id, '" data-cycle-id="').concat(escapeHtml(cycle.cycleId), '">Mover al próximo hueco</button><button class="cycle-quick-button" data-action="moveCycleFreeMachine" data-id="').concat(found.order.id, '" data-cycle-id="').concat(escapeHtml(cycle.cycleId), '">Cambiar a otra máquina libre</button><button class="cycle-quick-button" data-action="finishCycleNow" data-id="').concat(found.order.id, '" data-cycle-id="').concat(escapeHtml(cycle.cycleId), '">Termina ahora</button><button class="cycle-quick-button danger" data-action="deleteCycle" data-id="').concat(found.order.id, '" data-cycle-id="').concat(escapeHtml(cycle.cycleId), '">Borrar turno</button><button class="cycle-quick-button danger" data-action="removeOrderSchedule" data-id="').concat(found.order.id, '">Remover pedido del calendario</button></div><form class="form-grid"><label>Máquina<select name="machine" data-preview-field>').concat(machineOptionsHtml(cycle.machine), '</select></label><label>Tipo<select name="type">').concat(cycleOptionHtml(cycle.type), '</select></label><label>Inicio<input name="start" type="datetime-local" required data-preview-field value="').concat(escapeHtml(start), '" /></label><label>Minutos<input name="minutes" type="number" min="1" required data-preview-field value="').concat(Number(cycle.minutes || Math.max(1, Math.round((new Date(cycle.end) - new Date(cycle.start)) / 60000))), '" /></label><p class="full schedule-preview-note">Vista previa: cambiá inicio, duración o máquina para recalcular.</p><label class="full">Descripción / nota<input name="description" value="').concat(escapeHtml(cycle.description || ""), '" /></label><button class="primary full" type="button" data-action="saveCycleEdit" data-id="').concat(found.order.id, '" data-cycle-id="').concat(escapeHtml(cycle.cycleId), '">Guardar turno</button></form>');
    openModal("Editar turno", html);
}
function localDateTimeValue(value) {
    var date = new Date(value);
    if (isNaN(date.getTime()))
        return "";
    return date.getFullYear() + "-" + leftPad(date.getMonth() + 1, 2, "0") + "-" + leftPad(date.getDate(), 2, "0") + "T" + leftPad(date.getHours(), 2, "0") + ":" + leftPad(date.getMinutes(), 2, "0");
}
function saveCycleEdit(button) {
    var found = findOrderCycle(button.getAttribute("data-id"), button.getAttribute("data-cycle-id"));
    if (!found)
        return;
    var data = formDataToObject(button.closest("form"));
    var start = new Date(data.start);
    var minutes = Number(data.minutes || 0);
    if (isNaN(start.getTime()) || !minutes) {
        alert("Revisá inicio y duración.");
        return;
    }
    var end = new Date(start.getTime() + minutes * 60000);
    if (!data.machine) {
        alert("Elegí lavarropa o secadora para ocupar la máquina.");
        return;
    }
    var conflicts = machineConflicts(data.machine, start, end, found.order.id, found.cycle.cycleId);
    if (conflicts.length && !confirm("Este horario choca con otro trabajo en la misma máquina. ¿Guardar igual?"))
        return;
    found.cycle.machine = data.machine;
    found.cycle.type = data.type;
    found.cycle.start = start.toISOString();
    found.cycle.end = end.toISOString();
    found.cycle.minutes = minutes;
    found.cycle.description = data.description || "";
    found.cycle.pendingMachine = false;
    found.cycle.manual = true;
    touchOrderCycle(found.order, found.cycle);
    refreshOrderEstimate(found.order);
    saveState();
    closeModal();
    render();
}
function deleteCycle(orderId, cycleId) {
    var found = findOrderCycle(orderId, cycleId);
    if (!found || !confirm("¿Borrar este turno?"))
        return;
    touchOrderCycle(found.order, found.cycle);
    found.order.cycles.splice(found.index, 1);
    refreshOrderEstimate(found.order);
    saveState();
    closeModal();
    render();
}
function saveCycleAndRefresh(found) {
    refreshOrderEstimate(found.order);
    saveState();
    closeModal();
    render();
}
function shiftCycleMinutes(orderId, cycleId, minutes) {
    var found = findOrderCycle(orderId, cycleId);
    if (!found)
        return;
    var delta = Number(minutes || 0) * 60000;
    found.cycle.start = new Date(new Date(found.cycle.start).getTime() + delta).toISOString();
    found.cycle.end = new Date(new Date(found.cycle.end).getTime() + delta).toISOString();
    found.cycle.manual = true;
    touchOrderCycle(found.order, found.cycle);
    saveCycleAndRefresh(found);
}
function moveCycleToNextFreeSlot(orderId, cycleId) {
    var found = findOrderCycle(orderId, cycleId);
    if (!found)
        return;
    var minutes = Number(found.cycle.minutes || Math.max(1, Math.round((new Date(found.cycle.end) - new Date(found.cycle.start)) / 60000)));
    var slot = nextFreeMachineSlot(found.cycle.type === "Secado" ? "Secado" : "Lavado", minutes, new Date());
    if (!slot) {
        alert("No encontré un hueco libre cercano.");
        return;
    }
    found.cycle.machine = slot.machine;
    found.cycle.start = slot.start.toISOString();
    found.cycle.end = slot.end.toISOString();
    found.cycle.manual = true;
    touchOrderCycle(found.order, found.cycle);
    saveCycleAndRefresh(found);
}
function moveCycleToFreeMachine(orderId, cycleId) {
    var found = findOrderCycle(orderId, cycleId);
    if (!found)
        return;
    var start = new Date(found.cycle.start);
    var end = new Date(found.cycle.end);
    var machines = scheduleMachines().filter(function (machine) { return found.cycle.type === "Secado" ? machine.type === "Secado" : machine.type === "Lavado"; });
    for (var index = 0; index < machines.length; index += 1) {
        if (machines[index].name !== found.cycle.machine && !machineConflicts(machines[index].name, start, end, found.order.id, found.cycle.cycleId).length) {
            found.cycle.machine = machines[index].name;
            found.cycle.manual = true;
            touchOrderCycle(found.order, found.cycle);
            saveCycleAndRefresh(found);
            return;
        }
    }
    alert("No hay otra máquina libre en ese mismo horario.");
}
function finishCycleNow(orderId, cycleId) {
    var found = findOrderCycle(orderId, cycleId);
    if (!found)
        return;
    found.cycle.end = new Date().toISOString();
    found.cycle.minutes = Math.max(1, Math.round((new Date(found.cycle.end) - new Date(found.cycle.start)) / 60000));
    found.cycle.manual = true;
    touchOrderCycle(found.order, found.cycle);
    saveCycleAndRefresh(found);
}
function firstPendingOrderWithoutCycle() {
    var orders = operationalOrders().filter(function (order) { return order.status === "Pendiente" && !(order.cycles || []).length; });
    if (!orders.length)
        orders = operationalOrders().filter(function (order) { return order.status === "Pendiente"; });
    orders.sort(function (a, b) { return new Date(a.createdAt) - new Date(b.createdAt); });
    return orders[0] || null;
}
function openAssignAtSuggestedSlot(type) {
    var order = firstPendingOrderWithoutCycle();
    var duration = type === "Secado" ? state.settings.dryingMinutes : state.settings.washingMinutes;
    var slot = nextFreeMachineSlot(type, duration, schedulePlanningStart());
    if (!slot) {
        alert("No encontré una máquina libre cercana.");
        return;
    }
    openSuggestedAssignModal(type, slot, order);
}
function assignNextOrder() {
    var order = firstPendingOrderWithoutCycle();
    if (!order) {
        alert("No hay pedidos pendientes para asignar.");
        return;
    }
    var type = getService(order.serviceId) && getService(order.serviceId).dry && !getService(order.serviceId).wash ? "Secado" : "Lavado";
    var duration = type === "Secado" ? state.settings.dryingMinutes : state.settings.washingMinutes;
    var slot = nextFreeMachineSlot(type, duration, schedulePlanningStart());
    if (!slot) {
        alert("No encontré un hueco libre cercano.");
        return;
    }
    openSuggestedAssignModal(type, slot, order);
}
function openSuggestedAssignModal(type, slot, selectedOrder) {
    var orders = operationalOrders().filter(function (order) { return order.status === "Pendiente"; });
    var options = orders.map(function (order) { return '<option value="'.concat(order.id, '" ').concat(selectedOrder && selectedOrder.id === order.id ? 'selected' : '', '>').concat(escapeHtml(orderDisplayCode(order)), ' · ').concat(escapeHtml(orderClient(order)), '</option>'); }).join('');
    var html = '<form class="form-grid"><p class="full"><strong>'.concat(escapeHtml(slot.machine), '</strong> · ').concat(formatShortDateTime(slot.start), ' a ').concat(formatShortDateTime(slot.end).slice(-5), '</p><label class="full">Pedido<select name="orderId" required>').concat(options, '</select></label><button class="primary full" type="button" data-action="confirmSuggestedSlot" data-type="').concat(escapeHtml(type), '" data-machine="').concat(escapeHtml(slot.machine), '" data-start="').concat(slot.start.toISOString(), '" data-minutes="').concat(Math.round((slot.end - slot.start) / 60000), '">Asignar</button></form>');
    openModal("Asignar próximo pedido", html);
}
function confirmSuggestedSlot(button) {
    var form = button.closest("form");
    var data = formDataToObject(form);
    var order = getOrder(data.orderId);
    if (!order)
        return;
    var start = new Date(button.getAttribute("data-start"));
    var minutes = Number(button.getAttribute("data-minutes") || 30);
    addCycleToOrder(order, { type: button.getAttribute("data-type"), machine: button.getAttribute("data-machine"), start: start.toISOString(), end: new Date(start.getTime() + minutes * 60000).toISOString(), minutes: minutes, manual: true });
    saveState();
    closeModal();
    render();
}
function openMachineBlockModal() {
    var html = '<form class="form-grid"><label>Máquina<select name="machine" data-preview-field>'.concat(machineOptionsHtml(""), '</select></label><label>Inicio<input name="start" type="datetime-local" required data-preview-field /></label><label>Minutos<input name="minutes" type="number" min="1" value="60" required data-preview-field /></label><p class="full schedule-preview-note">Vista previa: completá inicio y duración.</p><label class="full">Motivo<input name="description" value="Mantenimiento" /></label><button class="primary full" type="button" data-action="saveMachineBlock">Guardar bloqueo</button></form>');
    openModal("Bloqueo / mantenimiento", html);
}
function saveMachineBlock(button) {
    var data = formDataToObject(button.closest("form"));
    var start = new Date(data.start);
    var minutes = Number(data.minutes || 0);
    if (isNaN(start.getTime()) || !minutes) {
        alert("Revisá inicio y duración.");
        return;
    }
    var blockOrder = { id: nextId(state.orders), number: "", clientId: 0, serviceId: 0, createdAt: new Date().toISOString(), estimate: start.toISOString(), cycles: [], status: "Pendiente", items: [{ name: data.description || "Bloqueo", quantity: 1, price: 0 }], total: 0, location: "", notes: "Bloqueo de máquina", paymentStatus: "Pendiente", paymentMethod: "Efectivo", block: true };
    blockOrder.number = "B#" + fourDigitId(blockOrder.id);
    addCycleToOrder(blockOrder, { type: "Bloqueo", machine: data.machine, start: start.toISOString(), end: new Date(start.getTime() + minutes * 60000).toISOString(), minutes: minutes, manual: true, description: data.description || "Bloqueo" });
    state.orders.push(blockOrder);
    saveState();
    closeModal();
    render();
}
function rescheduleActiveOrders() {
    calculateScheduleFromSelectedTime();
}

function openFreeSlotFinder() {
    var wash = nextFreeMachineSlot("Lavado", state.settings.washingMinutes, schedulePlanningStart());
    var dry = nextFreeMachineSlot("Secado", state.settings.dryingMinutes, schedulePlanningStart());
    openModal("Huecos libres", '<div class="schedule-free-slots"><article><h3>Lavado</h3><p>'.concat(wash ? escapeHtml(wash.machine) + ' · ' + formatDateTime(wash.start) : 'Sin hueco cercano', '</p></article><article><h3>Secado</h3><p>').concat(dry ? escapeHtml(dry.machine) + ' · ' + formatDateTime(dry.start) : 'Sin hueco cercano', '</p></article></div>'));
}
function openUnscheduledOrdersModal() {
    var orders = operationalOrders().filter(function (order) { return order.status !== "Retirado" && !(order.cycles || []).length; });
    openModal("Pedidos sin turno", '<div class="history-list">'.concat(orders.map(function (order) { return '<article class="history-item"><strong>'.concat(escapeHtml(orderDisplayCode(order)), '</strong><span>').concat(escapeHtml(orderClient(order)), '</span><button class="secondary" data-action="viewOrder" data-id="').concat(order.id, '">Ver</button></article>'); }).join('') || '<p>No hay pedidos sin turno.</p>', '</div>'));
}

function renderStorage() {
    var occupied = {};
    operationalOrders().filter(function (order) { return order.location && order.status !== "Retirado"; }).forEach(function (order) {
        occupied[order.location] = order;
    });
    document.getElementById("storage").innerHTML = "\n    <div class=\"card hero-card\"><div><p class=\"eyebrow-dark\">Dep\u00F3sito</p><h2>Ubicaciones y aviso de guarda</h2><p>Hac\u00E9 clic en una ubicaci\u00F3n ocupada para abrir el pedido correspondiente.</p></div><button class=\"secondary\" data-action=\"storageNotice\">Ver aviso general</button></div>\n    <div class=\"storage-grid\">".concat(state.locations.map(function (location) {
        var order = occupied[location.code];
        return order
            ? "<button class=\"location busy location-button\" data-action=\"openStorageOrder\" data-id=\"".concat(order.id, "\"><h3>").concat(escapeHtml(location.code), "</h3><strong>").concat(escapeHtml(orderDisplayCode(order)), "</strong><span>").concat(escapeHtml(orderClient(order)), "</span><small>").concat(escapeHtml(order.status), "</small></button>")
            : "<article class=\"location free\"><h3>".concat(escapeHtml(location.code), "</h3>Libre</article>");
    }).join(""), "</div>");
}
function openStorageOrder(id) {
    setView("orders");
    var input = document.getElementById("orderSearch");
    var order = getOrder(id);
    if (input && order) {
        input.value = orderDisplayCode(order);
        filterOrders(orderDisplayCode(order));
    }
    openOrderViewModal(id);
}
function cashReportHtml() {
    var rows = monthlyCashSummary();
    var latest = rows[rows.length - 1] || { month: "Sin datos", income: 0, expense: 0, balance: 0, margin: 0, orders: 0, topClients: [], hourlyCounts: emptyHourlyCounts() };
    if (!selectedMetricsMonth && rows.length)
        selectedMetricsMonth = latest.month;
    var selected = rows.find(function (row) { return row.month === selectedMetricsMonth; }) || latest;
    if (selectedMetricsCompareMonth === selected.month)
        selectedMetricsCompareMonth = "";
    var bestBalance = rows.slice().sort(function (a, b) { return b.balance - a.balance; })[0];
    var topClientHtml = (selected.topClients || []).map(function (client, index) { return '<button class="top-client-link" data-action="clientHistory" data-id="' + (client.id || '') + '"><span>#' + (index + 1) + '</span><strong>' + escapeHtml(client.name) + '</strong><small>' + client.count + ' pedido(s)</small></button>'; }).join('') || '<p>Sin clientes en este mes.</p>';
    if (!selectedMetricsYear && selected.month !== "Sin datos")
        selectedMetricsYear = selected.month.slice(0, 4);
    return `
    <div class="card report-panel metrics-panel"><div class="toolbar"><div><p class="eyebrow-dark">Históricos</p><h2>Evolución mensual y comparación anual</h2><p>El gráfico principal muestra la diferencia real mensual: ingresos menos egresos operativos y gastos internos del local.</p></div><div class="actions"><button class="secondary" data-action="exportHistoricalCash">Exportar Caja Histórica como hoja de cálculo</button></div>${rows.length ? monthSelectorHtml(rows, selected.month) : ""}</div>
      <div class="grid four report-metrics metric-hero-grid">
        <article class="mini-metric metric-glow"><span>Ingresos mensuales</span><strong>${money(selected.income)}</strong><small>Egresos operativos: ${money(selected.expense)}</small></article>
        <article class="mini-metric metric-glow"><span>Diferencia real</span><strong>${money(selected.balance)}</strong><small>Gastos local: ${money(selected.businessExpense || 0)}</small></article>
        <article class="mini-metric metric-glow"><span>Pedidos del mes</span><strong>${selected.orders}</strong><small>${escapeHtml(selected.month)}</small></article>
        <article class="mini-metric metric-glow"><span>Mejor mes histórico</span><strong>${bestBalance ? escapeHtml(bestBalance.month) : "Sin datos"}</strong><small>${bestBalance ? money(bestBalance.balance) : "Cerrá caja para comparar"}</small></article>
      </div>
      ${monthlyPerformanceLineChart(rows, selected.month, selectedMetricsCompareMonth, selectedMetricsYear)}
      <div class="metrics-focus-grid"><article class="metric-month-card"><h3>Top 5 clientes del mes</h3><div class="top-client-list">${topClientHtml}</div></article>${annualComparisonHtml(rows)}</div>
      ${monthlyCashHtml(selected.month)}
    </div>`;
}
function renderCash() {
    if (!cashUnlocked) {
        document.getElementById("cash").innerHTML = '<div class="card"><h2>Caja protegida</h2><p>Ingresá la clave del dueño para ver ingresos, egresos y saldos.</p><div class="form-grid"><label>Clave<input id="cashPinUnlock" type="password" placeholder="Clave" /></label></div><br><button class="primary" data-action="unlockCash">Entrar</button><p><small>La clave inicial es 1234 y puede cambiarse desde Configuración.</small></p></div>';
        return;
    }
    var income = state.cash.filter(function (entry) { return entry.type === "Ingreso"; }).reduce(function (sum, entry) { return sum + Number(entry.amount); }, 0);
    var expense = state.cash.filter(function (entry) { return entry.type === "Egreso"; }).reduce(function (sum, entry) { return sum + Number(entry.amount); }, 0);
    var cash = state.cash.filter(function (entry) { return entry.method === "Efectivo"; }).reduce(function (sum, entry) { return sum + (entry.type === "Ingreso" ? Number(entry.amount) : -Number(entry.amount)); }, 0);
    var transfer = state.cash.filter(function (entry) { return entry.method === "Transferencia"; }).reduce(function (sum, entry) { return sum + (entry.type === "Ingreso" ? Number(entry.amount) : -Number(entry.amount)); }, 0);
    document.getElementById("cash").innerHTML = '\n    <div class="grid four"><article class="card metric"><span>Ingresos</span><strong>'.concat(money(income), '</strong></article><article class="card metric"><span>Egresos</span><strong>').concat(money(expense), '</strong></article><article class="card metric"><span>Efectivo</span><strong>').concat(money(cash), '</strong></article><article class="card metric"><span>Transferencia</span><strong>').concat(money(transfer), '</strong></article></div>\n    <div class="card cash-day-hero"><div><p class="eyebrow-dark">Cierre diario</p><h2>Empezar nuevo día</h2><p>Guarda todos los movimientos actuales en la caja histórica y deja la caja diaria en cero.</p></div><button class="danger big-action new-day-button" data-action="closeCashDay">Empezar nuevo día</button></div>\n    <div class="card cash-section"><div class="toolbar"><h2>Caja del día / movimientos</h2><div class="actions"><button class="success" data-action="cashIncome">+ Ingreso</button><button class="danger" data-action="cashExpense">+ Egreso</button></div></div>').concat(cashTable(), cashMonthlyPanelHtml(), '</div>');
}
function cashTable() {
    var entries = __spreadArray([], state.cash, true).sort(function (a, b) {
        if (a.type !== b.type)
            return a.type === "Ingreso" ? -1 : 1;
        return new Date(b.date) - new Date(a.date);
    });
    var income = state.cash.filter(function (entry) { return entry.type === "Ingreso"; }).reduce(function (sum, entry) { return sum + Number(entry.amount || 0); }, 0);
    var expense = state.cash.filter(function (entry) { return entry.type === "Egreso"; }).reduce(function (sum, entry) { return sum + Number(entry.amount || 0); }, 0);
    var balance = income - expense;
    return '<div class="table-wrap"><table class="cash-movements-table"><thead><tr><th>Fecha</th><th>Tipo</th><th>Categoría</th><th>Descripción</th><th>Medio</th><th>Importe</th></tr></thead><tbody>'.concat(entries.map(function (entry) { return '<tr class="'.concat(entry.type === "Ingreso" ? "cash-income-row" : "cash-expense-row", '"><td>').concat(formatDateTime(entry.date), '</td><td><span class="cash-type-badge ').concat(entry.type === "Ingreso" ? "income" : "expense", '">').concat(escapeHtml(entry.type), '</span></td><td>').concat(escapeHtml(entry.category), '</td><td>').concat(escapeHtml(entry.description), '</td><td>').concat(paymentMethodLabel(entry.method), '</td><td>').concat(money(entry.amount), '</td></tr>'); }).join('') || '<tr><td colspan="6">Sin movimientos.</td></tr>', '</tbody><tfoot><tr><th colspan="5">Total ingresos</th><th>').concat(money(income), '</th></tr><tr><th colspan="5">Total egresos</th><th>').concat(money(expense), '</th></tr><tr><th colspan="5">Saldo final</th><th>').concat(money(balance), '</th></tr></tfoot></table></div>');
}
function cashMonthlyPanelHtml() {
    var month = selectedCashMonth || localDateInput().slice(0, 7);
    var rows = cashRowsForMonth(month);
    var income = rows.filter(function (entry) { return entry.type === "Ingreso"; }).reduce(function (sum, entry) { return sum + Number(entry.amount || 0); }, 0);
    var expense = rows.filter(function (entry) { return entry.type === "Egreso"; }).reduce(function (sum, entry) { return sum + Number(entry.amount || 0); }, 0);
    var balance = income - expense;
    var totalPages = Math.max(1, Math.ceil(rows.length / cashMonthlyPageSize));
    if (cashMonthlyPage > totalPages) cashMonthlyPage = totalPages;
    if (cashMonthlyPage < 1) cashMonthlyPage = 1;
    var start = (cashMonthlyPage - 1) * cashMonthlyPageSize;
    var pageRows = rows.slice(start, start + cashMonthlyPageSize);
    var pagination = cashMonthlyPaginationHtml(rows.length, cashMonthlyPage, totalPages, start, pageRows.length);
    return '<details class="monthly-cash-panel user-monthly-cash"' + (cashMonthlyPanelOpen ? ' open' : '') + '><summary class="secondary history-toggle">Ver caja mensual</summary><div class="toolbar compact-toolbar"><div><h3>Caja mensual</h3><p>Consulta operativa por mes, sin mezclar gastos privados del local.</p></div><label class="date-picker-label">Mes<span class="calendar-input-wrap"><input id="cashMonthFilter" class="date-picker-input" data-cash-month-filter type="month" value="' + escapeHtml(month) + '" inputmode="none" /><button class="calendar-open-button" type="button" data-action="openDatePicker" data-target="cashMonthFilter" aria-label="Abrir calendario">📅</button></span></label></div><div class="grid three compact-month-summary"><article class="mini-metric"><span>Ingresos</span><strong>' + money(income) + '</strong></article><article class="mini-metric"><span>Egresos</span><strong>' + money(expense) + '</strong></article><article class="mini-metric"><span>Saldo</span><strong>' + money(balance) + '</strong></article></div><div class="table-wrap"><table class="cash-history-table"><thead><tr><th>Cierre</th><th>Movimiento</th><th>Tipo</th><th>Categoría</th><th>Descripción</th><th>Medio</th><th>Importe</th></tr></thead><tbody>' + (pageRows.map(function (entry) { return '<tr class="' + (entry.type === "Ingreso" ? "cash-income-row" : "cash-expense-row") + '"><td>' + (entry.closedAt === "Caja actual" ? "Caja actual" : formatDateTime(entry.closedAt)) + '</td><td>' + formatDateTime(entry.date) + '</td><td>' + escapeHtml(entry.type) + '</td><td>' + escapeHtml(entry.category) + '</td><td>' + escapeHtml(entry.description) + '</td><td>' + paymentMethodLabel(entry.method) + '</td><td class="' + (signedCashAmount(entry) < 0 ? 'negative-amount' : '') + '">' + moneySigned(signedCashAmount(entry)) + '</td></tr>'; }).join('') || '<tr><td colspan="7">No hay movimientos para este mes.</td></tr>') + '</tbody></table></div>' + pagination + '</details>';
}
function cashMonthlyPaginationHtml(total, page, totalPages, start, count) {
    if (!total || total <= cashMonthlyPageSize)
        return "";
    var from = start + 1;
    var to = start + count;
    var firstPage = Math.max(1, page - 4);
    var lastPage = Math.min(totalPages, firstPage + 9);
    firstPage = Math.max(1, lastPage - 9);
    var buttons = [];
    for (var item = firstPage; item <= lastPage; item += 1) {
        buttons.push('<button class="page-button ' + (item === page ? 'active' : '') + '" data-action="cashMonthlyPage" data-page="' + item + '">' + item + '</button>');
    }
    return '<div class="orders-pagination cash-monthly-pagination"><div><strong>Mostrando ' + from + '-' + to + '</strong><span> de ' + total + ' movimientos</span></div><div class="page-controls"><button class="secondary" data-action="prevCashMonthlyPage" ' + (page <= 1 ? 'disabled' : '') + '>‹ Anterior</button>' + buttons.join('') + '<button class="secondary" data-action="nextCashMonthlyPage" ' + (page >= totalPages ? 'disabled' : '') + '>Siguiente ›</button></div></div>';
}
function setCashMonthlyPage(page) {
    cashMonthlyPage = Number(page || 1);
    cashMonthlyPanelOpen = true;
    renderCash();
}
function changeCashMonthlyPage(delta) {
    cashMonthlyPage += Number(delta || 0);
    cashMonthlyPanelOpen = true;
    renderCash();
}
function openDatePickerById(id) {
    var input = id ? document.getElementById(id) : null;
    if (input)
        openDatePickerInput(input);
}
function openDatePickerInput(input) {
    if (!input)
        return;
    try {
        if (input.showPicker)
            input.showPicker();
        else
            input.focus();
    }
    catch (error) {
        input.focus();
    }
}
function isCalendarOnlyInput(target) {
    return target && target.matches && target.matches('input[type="date"], input[type="month"]');
}
function showLoginScreen() {
    var screen = document.getElementById("loginScreen");
    if (!screen) {
        screen = document.createElement("section");
        screen.id = "loginScreen";
        screen.className = "login-screen";
        document.body.appendChild(screen);
    }
    document.body.classList.add("session-locked");
    screen.innerHTML = '<div class="login-card"><div class="login-brand"><img class="login-logo" src="' + escapeHtml(state.settings.logoDataUrl || "") + '" ' + (state.settings.logoDataUrl ? '' : 'hidden') + ' alt="Logo" /><p class="eyebrow-dark">Sistema local</p><h1>La Vieja Esquina</h1><p>Ingresá la clave para comenzar.</p></div><form id="loginForm" class="login-form"><label>Clave<input id="loginPin" type="password" autocomplete="current-password" autofocus /></label><button class="primary full" type="submit">Entrar</button></form></div>';
    setTimeout(function () { var input = document.getElementById("loginPin"); if (input) input.focus(); }, 0);
}
function hideLoginScreen() {
    document.body.classList.remove("session-locked");
    var screen = document.getElementById("loginScreen");
    if (screen && screen.parentNode)
        screen.parentNode.removeChild(screen);
}
function handleLogin() {
    var input = document.getElementById("loginPin");
    var pin = String((input && input.value) || "").trim();
    if (pin === MASTER_ADMIN_PIN) {
        sessionLoggedIn = true;
        sessionRole = "admin";
        sessionIsDev = true;
        state.settings.currentRole = "admin";
        currentView = "cashReports";
    }
    else if (pin === String(state.settings.adminPin || "1111")) {
        sessionLoggedIn = true;
        sessionRole = "admin";
        sessionIsDev = false;
        state.settings.currentRole = "admin";
        currentView = "cashReports";
    }
    else if (pin === String(state.settings.employeePin || "0000")) {
        sessionLoggedIn = true;
        sessionRole = "user";
        sessionIsDev = false;
        state.settings.currentRole = "user";
        currentView = "orders";
    }
    else {
        alert("Clave incorrecta.");
        if (input) input.select();
        return;
    }
    cashUnlocked = false;
    businessExpensesUnlocked = true;
    adminOrdersUnlocked = false;
    saveState();
    render();
}
function openRoleModal() {
    openModal('Sesión', '<div class="role-simple-modal"><p class="role-helper"><strong>Sesión actual:</strong> ' + (isAdmin() ? 'Administrador' : 'Empleado') + '.</p><button class="danger full" type="button" data-action="logout">Desconectarse</button><button class="secondary full" type="button" data-close-modal>Cancelar</button></div>');
}
function logout() {
    sessionLoggedIn = false;
    sessionRole = "";
    sessionIsDev = false;
    cashUnlocked = false;
    businessExpensesUnlocked = true;
    adminOrdersUnlocked = false;
    closeModal();
    render();
}
function saveRole(button) {
    openRoleModal();
}
function selectedBusinessExpenseMonth() {
    var input = document.getElementById("businessExpenseMonth");
    return input && input.value ? input.value : localDateInput().slice(0, 7);
}
function selectedBusinessExpenseYear() {
    var input = document.getElementById("businessExpenseYear");
    return input && input.value ? input.value : localDateInput().slice(0, 4);
}
function privateMetricCard(title, value, detail) {
    return '<article class="mini-metric private-expense-metric"><span>' + escapeHtml(title) + '</span><strong>' + escapeHtml(value) + '</strong><small>' + escapeHtml(detail || '') + '</small></article>';
}
function renderBusinessExpenses() {
    if (!isAdmin()) {
        document.getElementById("businessExpenses").innerHTML = accessDeniedHtml();
        return;
    }
    var today = localDateInput();
    var currentMonth = selectedBusinessExpenseMonth();
    var currentYear = selectedBusinessExpenseYear();
    var monthRows = businessExpensesForMonth(currentMonth);
    var yearRows = businessExpensesForYear(currentYear);
    var monthTotal = businessExpenseTotal(monthRows);
    var yearTotal = businessExpenseTotal(yearRows);
    var lastExpense = yearRows.length ? yearRows[0] : null;
    var availableYears = businessExpenseYearOptions(currentYear);
    var chartRows = businessExpenseMonthlyRows(currentYear);
    document.getElementById("businessExpenses").innerHTML = `
    <div class="card local-expense-hero"><div><p class="eyebrow-dark">Administración privada</p><h2>Gastos del local</h2><p>Gastos internos del negocio, separados de la caja operativa diaria.</p></div><div class="private-total-pill"><span>Total del mes</span><strong>${money(monthTotal)}</strong></div></div>
    <div class="card cash-section local-expense-section"><div class="toolbar"><div><p class="eyebrow-dark">Evolución privada</p><h2>Gastos mes a mes</h2><p>Vista anual de gastos internos del local.</p></div><div class="actions expense-filter-actions"><label>Año<select id="businessExpenseYear" data-business-expense-filter>${availableYears}</select></label></div></div>${businessExpenseLineChart(chartRows)}${businessExpenseAnnualCards(chartRows, currentYear)}</div>
    <div class="card cash-section local-expense-section"><div class="toolbar"><div><p class="eyebrow-dark">Consulta privada</p><h2>Movimientos de gastos internos</h2><p>Registrá gastos internos y consultalos por mes.</p></div><div class="actions expense-filter-actions"><button class="danger" data-action="openAddBusinessExpenseModal">+ Agregar gasto</button><label class="date-picker-label">Mes<span class="calendar-input-wrap"><input id="businessExpenseMonth" class="date-picker-input" data-business-expense-filter type="month" value="${escapeHtml(currentMonth)}" inputmode="none" /><button class="calendar-open-button" type="button" data-action="openDatePicker" data-target="businessExpenseMonth" aria-label="Abrir calendario">📅</button></span></label></div></div><h3>Gastos del mes</h3>${businessExpensesTable(monthRows, true)}</div>`;
}
function businessExpenseMonthlyRows(year) {
    var rows = [];
    for (var month = 1; month <= 12; month += 1) {
        var key = String(year) + "-" + leftPad(month, 2, "0");
        var list = businessExpensesForMonth(key);
        rows.push({ month: key, total: businessExpenseTotal(list), count: list.length });
    }
    return rows;
}
function businessExpenseLineChart(rows) {
    var chartRows = rows && rows.length ? rows : [{ month: "Sin datos", total: 0, count: 0 }];
    var values = chartRows.map(function (row) { return Number(row.total || 0); });
    var max = Math.max.apply(Math, values.concat([1]));
    var min = 0;
    var chartTop = 30;
    var chartBottom = 230;
    var chartLeft = 76;
    var chartRight = 760;
    var span = Math.max(1, max - min);
    var xFor = function (index) { return chartRows.length === 1 ? chartLeft : chartLeft + index * ((chartRight - chartLeft) / (chartRows.length - 1)); };
    var yFor = function (value) { return chartBottom - ((Number(value || 0) - min) / span) * (chartBottom - chartTop); };
    var points = chartRows.map(function (row, index) { return Math.round(xFor(index)) + "," + Math.round(yFor(row.total)); }).join(" ");
    var yTicks = [];
    for (var tick = 0; tick <= 4; tick += 1) {
        var value = min + (span / 4) * tick;
        yTicks.push({ value: value, y: Math.round(yFor(value)) });
    }
    var yLines = yTicks.map(function (tick) { return '<g><line class="grid-line" x1="' + chartLeft + '" y1="' + tick.y + '" x2="' + chartRight + '" y2="' + tick.y + '"></line><text x="6" y="' + (tick.y + 4) + '">' + escapeHtml(money(tick.value)) + '</text></g>'; }).join("");
    var dots = chartRows.map(function (row, index) { return '<circle class="expense-performance-point" cx="' + Math.round(xFor(index)) + '" cy="' + Math.round(yFor(row.total)) + '" r="5"><title>' + escapeHtml(row.month) + ': ' + escapeHtml(money(row.total)) + '</title></circle>'; }).join("");
    var xLabels = chartRows.map(function (row, index) {
        var anchor = index === 0 ? "start" : index === chartRows.length - 1 ? "end" : "middle";
        return '<text class="x-axis-label" x="' + Math.round(xFor(index)) + '" y="258" text-anchor="' + anchor + '">' + escapeHtml(row.month.slice(5, 7)) + '</text>';
    }).join("");
    return '<article class="performance-line-card private-expense-chart"><div class="metric-month-head"><div><h3>Evolución de gastos internos</h3><p>El eje X muestra los meses del año y el eje Y el total gastado.</p></div></div><div class="performance-chart-wrap"><span class="y-axis-title">Gastos ($)</span><svg viewBox="0 0 800 280" role="img" aria-label="Evolución de gastos del local"><g class="y-axis-labels">' + yLines + '</g><line class="axis-line" x1="' + chartLeft + '" y1="' + chartBottom + '" x2="' + chartRight + '" y2="' + chartBottom + '"></line><line class="axis-line" x1="' + chartLeft + '" y1="' + chartTop + '" x2="' + chartLeft + '" y2="' + chartBottom + '"></line><polyline points="' + points + '"></polyline><g class="performance-points">' + dots + '</g><g class="performance-x-labels">' + xLabels + '</g></svg><div class="x-axis-title">Meses del año</div></div></article>';
}
function businessExpenseAnnualCards(rows, year) {
    var total = rows.reduce(function (sum, row) { return sum + Number(row.total || 0); }, 0);
    var monthsWithData = rows.filter(function (row) { return Number(row.total || 0) > 0; });
    var average = monthsWithData.length ? Math.round(total / monthsWithData.length) : 0;
    var top = monthsWithData.slice().sort(function (a, b) { return b.total - a.total; })[0];
    return '<div class="grid three private-year-cards"><article class="mini-metric"><span>Total anual</span><strong>' + money(total) + '</strong><small>' + escapeHtml(year) + '</small></article><article class="mini-metric"><span>Promedio mensual activo</span><strong>' + money(average) + '</strong><small>Solo meses con gastos</small></article><article class="mini-metric"><span>Mes más caro</span><strong>' + (top ? escapeHtml(top.month) : '-') + '</strong><small>' + (top ? money(top.total) : 'Sin datos') + '</small></article></div><div class="private-year-strip">' + rows.map(function (row) { var percent = total ? Math.round((Number(row.total || 0) / total) * 100) : 0; return '<article><span>' + escapeHtml(row.month.slice(5, 7)) + '</span><strong>' + money(row.total) + '</strong><div class="private-year-bar"><i style="width:' + percent + '%"></i></div></article>'; }).join('') + '</div>';
}
function businessExpensesTable(rows, allowDelete) {
    var expenseRows = rows || [];
    var colCount = allowDelete ? 5 : 4;
    var body = expenseRows.map(function (expense) { return '<tr class="private-expense-row"><td>' + escapeHtml(formatDateTime(expense.date)) + '</td><td><strong>' + escapeHtml(expense.concept) + '</strong></td><td>' + money(expense.amount) + '</td><td>' + escapeHtml(expense.notes || '-') + '</td>' + (allowDelete ? '<td><button class="danger mini-button" data-action="deleteBusinessExpense" data-id="' + expense.id + '">Eliminar</button></td>' : '') + '</tr>'; }).join('');
    if (!body)
        body = '<tr><td colspan="' + colCount + '">No hay gastos cargados para este período.</td></tr>';
    else {
        var total = expenseRows.reduce(function (sum, expense) { return sum + Number(expense.amount || 0); }, 0);
        body += '<tr class="business-expenses-total-row"><td colspan="2"><strong>Total de gastos del mes</strong></td><td><strong>' + money(total) + '</strong></td><td></td>' + (allowDelete ? '<td></td>' : '') + '</tr>';
    }
    return '<div class="table-wrap"><table class="business-expenses-table"><thead><tr><th>Fecha</th><th>Concepto</th><th>Monto</th><th>Notas</th>' + (allowDelete ? '<th></th>' : '') + '</tr></thead><tbody>' + body + '</tbody></table></div>';
}
function businessExpenseYearOptions(selectedYear) {
    var years = {};
    allBusinessExpenses().forEach(function (expense) {
        if (expense && expense.date)
            years[String(expense.date).slice(0, 4)] = true;
    });
    years[String(new Date().getFullYear())] = true;
    years[String(selectedYear)] = true;
    var list = [];
    for (var year in years) { if (Object.prototype.hasOwnProperty.call(years, year)) list.push(year); }
    list.sort(function (a, b) { return Number(b) - Number(a); });
    return list.map(function (year) { return '<option value="' + escapeHtml(year) + '" ' + (String(year) === String(selectedYear) ? 'selected' : '') + '>' + escapeHtml(year) + '</option>'; }).join('');
}
function businessExpenseYearTable(year) {
    var months = {};
    businessExpensesForYear(year).forEach(function (expense) {
        var key = monthKey(expense.date);
        if (!months[key])
            months[key] = { month: key, total: 0, count: 0 };
        months[key].total += Number(expense.amount || 0);
        months[key].count += 1;
    });
    var list = [];
    for (var key in months) { if (Object.prototype.hasOwnProperty.call(months, key)) list.push(months[key]); }
    list.sort(function (a, b) { return a.month.localeCompare(b.month); });
    return '<div class="table-wrap"><table><thead><tr><th>Mes</th><th>Gastos</th><th>Cantidad</th></tr></thead><tbody>' + (list.map(function (row) { return '<tr><td>' + escapeHtml(row.month) + '</td><td>' + money(row.total) + '</td><td>' + row.count + '</td></tr>'; }).join('') || '<tr><td colspan="3">Sin gastos internos en el año elegido.</td></tr>') + '</tbody></table></div>';
}
function openAddBusinessExpenseModal() {
    var html = '<form class="form-grid business-expense-modal-form"><label class="full">Título / concepto<input id="businessExpenseConcept" placeholder="Ej: Luz, alquiler, reparación" required /></label><label>Monto<input id="businessExpenseAmount" type="number" min="0" step="0.01" required /></label><label class="full">Descripción<textarea id="businessExpenseNotes" placeholder="Detalle opcional"></textarea></label><p class="full assign-machine-helper">Se guarda con la fecha y hora actual.</p><div class="actions full"><button class="secondary" type="button" data-close-modal>Cancelar</button><button class="primary" type="button" data-action="saveBusinessExpense">Guardar gasto</button></div></form>';
    openModal('Agregar gasto del local', html);
}
function saveBusinessExpense(button) {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
    if (!businessExpensesUnlocked) { alert("Primero ingresá la clave de gastos del local."); return; }
    var concept = (document.getElementById("businessExpenseConcept") || {}).value || "";
    var amount = Number((document.getElementById("businessExpenseAmount") || {}).value || 0);
    var dateField = document.getElementById("businessExpenseDate");
    var date = dateField && dateField.value ? dateField.value : localDateInput();
    var notes = (document.getElementById("businessExpenseNotes") || {}).value || "";
    if (!concept.trim() || !amount || amount < 0 || !date) {
        alert(dateField ? "Completá concepto, monto y fecha." : "Completá concepto y monto.");
        return;
    }
    state.businessExpenses = state.businessExpenses || [];
    var nowIso = new Date().toISOString();
    var expenseDateIso = dateField && dateField.value ? new Date(date + "T12:00:00").toISOString() : nowIso;
    state.businessExpenses.push({ id: nextId(state.businessExpenses), concept: concept.trim(), amount: amount, date: expenseDateIso, notes: notes.trim(), createdAt: nowIso });
    saveState();
    closeModal();
    renderBusinessExpenses();
}
function deleteBusinessExpense(id) {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
    if (!businessExpensesUnlocked) { alert("Primero ingresá la clave de gastos del local."); return; }
    if (!confirm("¿Eliminar este gasto privado?"))
        return;
    state.businessExpenses = (state.businessExpenses || []).filter(function (expense) { return expense.id !== Number(id); });
    saveState();
    render();
}
function renderCashReports() {
    if (!isAdmin()) {
        document.getElementById("cashReports").innerHTML = accessDeniedHtml();
        return;
    }
    document.getElementById("cashReports").innerHTML = cashReportHtml();
}
function renderSettings() {
    if (!isAdmin()) {
        document.getElementById("settings").innerHTML = accessDeniedHtml();
        return;
    }
    var devControls = isDevAdmin() ? '<button class="danger" data-action="resetDemo">Reiniciar demo</button>' : '';
    var importCsvCard = isDevAdmin() ? '<div class="card"><h2>Importar CSV</h2><p>Importá clientes o pedidos desde un archivo CSV separado por coma o punto y coma. No borra los datos actuales.</p><div class="form-grid"><label>Tipo de datos<select id="csvImportType"><option value="clients">Clientes</option><option value="orders">Pedidos</option></select></label><label>Archivo CSV<input id="csvImportFile" type="file" accept=".csv,text/csv" /></label><p class="full"><strong>Columnas clientes:</strong> nombre, telefono, direccion, notas, autorizados. <strong>Columnas pedidos:</strong> cliente, telefono, prenda, cantidad, precio, estado, fecha_ingreso, fecha_retiro, pago, medio, deposito, notas.</p></div><br><button class="secondary" data-action="importCsvData">Importar CSV seleccionado</button></div>' : '';
    var servicePriceRows = (state.services || []).map(function (service) {
        return '<label>' + escapeHtml(service.name) + '<input id="servicePrice_' + service.id + '" type="number" min="0" step="1" value="' + Number(service.price || 0) + '" /></label>';
    }).join('');
    var servicePriceCard = '<div class="card service-price-card"><h2>Precios por defecto</h2><p>Estos valores se usan cuando cargás prendas o pedidos nuevos. No modifican pedidos ya cargados.</p><div class="form-grid">' + servicePriceRows + '</div></div>';
    var logoSettingsHtml = isDevAdmin() ? '<label>Logo PNG<input id="logoFile" data-logo-upload type="file" accept="image/png" /></label><div class="logo-settings-box"><span>Logo actual</span><div class="logo-preview-wrap"><img id="logoPreview" class="logo-preview" alt="Logo actual" /></div><button class="secondary" type="button" data-action="removeLogo">Quitar logo</button></div>' : '';
    document.getElementById("settings").innerHTML = `
    <div class="card"><h2>Configuración</h2><div class="form-grid">
      <label>Apertura<input id="openHour" type="time" value="${escapeHtml(state.settings.openHour)}" /></label>
      <label>Cierre<input id="closeHour" type="time" value="${escapeHtml(state.settings.closeHour)}" /></label>
      <label>Lavarropas chicos<input id="smallWashers" type="number" min="0" value="${Number(state.settings.smallWashers || 0)}" /></label>
      <label>Lavadoras grandes<input id="largeWashers" type="number" min="0" value="${Number(state.settings.largeWashers || 0)}" /></label>
      <label>Secadoras<input id="dryers" type="number" min="0" value="${Number(state.settings.dryers || 0)}" /></label>
      <label>Minutos lavado<input id="washingMinutes" type="number" min="1" value="${Number(state.settings.washingMinutes)}" /></label>
      <label>Minutos secado<input id="dryingMinutes" type="number" min="1" value="${Number(state.settings.dryingMinutes)}" /></label>
      <label>Clave de caja<input id="cashPin" type="password" value="${escapeHtml(state.settings.cashPin)}" /></label>
      <label>Clave de empleado<input id="employeePin" type="password" value="${escapeHtml(state.settings.employeePin || "0000")}" /></label>
      <label>Clave de Administrador<input id="adminPin" type="password" value="${escapeHtml(state.settings.adminPin || state.settings.metricsPin)}" /></label>
      <label>PIN para borrar pedidos<input id="deleteOrdersPin" type="password" value="${escapeHtml(state.settings.deleteOrdersPin || "1111")}" /></label>
      ${logoSettingsHtml}
      <label class="full">WhatsApp pedido recibido<textarea id="whatsappReceivedMessage">${escapeHtml(state.settings.whatsappReceivedMessage)}</textarea></label>
      <label class="full">WhatsApp pedido listo<textarea id="whatsappMessage">${escapeHtml(state.settings.whatsappMessage)}</textarea></label>
      <label class="full">WhatsApp retirado<textarea id="whatsappRetiredMessage">${escapeHtml(state.settings.whatsappRetiredMessage)}</textarea></label>
      <label>Días para aviso depósito<input id="storageNoticeDays" type="number" min="1" value="${Number(state.settings.storageNoticeDays)}" /></label>
      <label class="full">Cartel de depósito<textarea id="storageNoticeText">${escapeHtml(state.settings.storageNoticeText)}</textarea></label>
    </div><br><div class="actions"><button class="primary" data-action="saveSettings">Guardar</button>${devControls}</div></div>
    ${servicePriceCard}
    ${importCsvCard}`;
    refreshLogoPreview();
}
function refreshLogoPreview() {
    var preview = document.getElementById("logoPreview");
    if (!preview)
        return;
    var value = state.settings.logoDataUrl || "";
    if (value) {
        preview.src = value;
        preview.hidden = false;
    }
    else {
        preview.removeAttribute("src");
        preview.hidden = true;
    }
}
function trimLogoDataUrl(dataUrl, callback) {
    if (!dataUrl || !window.Image || !document.createElement) {
        callback(dataUrl);
        return;
    }
    var image = new Image();
    image.onload = function () {
        try {
            var source = document.createElement("canvas");
            var sourceContext = source.getContext && source.getContext("2d");
            if (!sourceContext) {
                callback(dataUrl);
                return;
            }
            source.width = image.width;
            source.height = image.height;
            sourceContext.drawImage(image, 0, 0);
            var pixels = sourceContext.getImageData(0, 0, source.width, source.height);
            var data = pixels.data;
            var minX = source.width;
            var minY = source.height;
            var maxX = 0;
            var maxY = 0;
            var found = false;
            for (var y = 0; y < source.height; y += 1) {
                for (var x = 0; x < source.width; x += 1) {
                    var alpha = data[(y * source.width + x) * 4 + 3];
                    if (alpha > 12) {
                        found = true;
                        if (x < minX) minX = x;
                        if (y < minY) minY = y;
                        if (x > maxX) maxX = x;
                        if (y > maxY) maxY = y;
                    }
                }
            }
            if (!found) {
                callback(dataUrl);
                return;
            }
            var width = Math.max(1, maxX - minX + 1);
            var height = Math.max(1, maxY - minY + 1);
            var targetSize = 320;
            var visualPadding = Math.max(8, Math.round(targetSize * 0.04));
            var scale = (targetSize - visualPadding * 2) / Math.max(width, height);
            var output = document.createElement("canvas");
            var outputContext = output.getContext && output.getContext("2d");
            if (!outputContext) {
                callback(dataUrl);
                return;
            }
            output.width = targetSize;
            output.height = targetSize;
            outputContext.clearRect(0, 0, targetSize, targetSize);
            var drawWidth = Math.round(width * scale);
            var drawHeight = Math.round(height * scale);
            var drawX = Math.round((targetSize - drawWidth) / 2);
            var drawY = Math.round((targetSize - drawHeight) / 2);
            outputContext.imageSmoothingEnabled = true;
            outputContext.imageSmoothingQuality = "high";
            outputContext.drawImage(source, minX, minY, width, height, drawX, drawY, drawWidth, drawHeight);
            callback(output.toDataURL("image/png"));
        }
        catch (error) {
            callback(dataUrl);
        }
    };
    image.onerror = function () { return callback(dataUrl); };
    image.src = dataUrl;
}
function importLogoFile(input) {
    var file = input && input.files && input.files[0];
    if (!file)
        return;
    if (file.type && file.type !== "image/png") {
        alert("El logo debe ser PNG.");
        input.value = "";
        return;
    }
    if (file.size > 1024 * 1024) {
        alert("El logo es demasiado pesado. Usá un PNG de hasta 1 MB.");
        input.value = "";
        return;
    }
    var reader = new FileReader();
    reader.onload = function () {
        var original = String(reader.result || "");
        trimLogoDataUrl(original, function (trimmed) {
            state.settings.logoDataUrl = trimmed || original;
            state.settings.logoAutoCropped = true;
            state.settings.logoCropVersion = LOGO_CROP_VERSION;
            saveState();
            updateBranding();
            refreshLogoPreview();
        });
    };
    reader.readAsDataURL(file);
}
function removeLogo() {
    if (!requireDevAccess())
        return;
    state.settings.logoDataUrl = "";
    state.settings.logoAutoCropped = false;
    state.settings.logoCropVersion = 0;
    saveState();
    updateBranding();
    refreshLogoPreview();
}
function openModal(title, html, onSubmit) {
    var template = document.getElementById("modalTemplate").content.cloneNode(true);
    template.querySelector("h2").textContent = title;
    template.querySelector(".modal-body").innerHTML = html;
    document.body.appendChild(template);
    var modal = document.querySelector(".modal-backdrop");
    var form = modal.querySelector("form");
    if (form)
        form.addEventListener("submit", function (event) { event.preventDefault(); if (onSubmit)
            onSubmit(form); });
    return modal;
}
function closeModal() {
    var modal = document.querySelector(".modal-backdrop");
    if (modal && modal.getAttribute("data-maintenance-alert") === "true") {
        dismissMaintenanceAlertForCurrentRole(modal.getAttribute("data-alert-key"));
    }
    if (modal)
        modal.remove();
}
function openClientModal(id) {
    var client = id ? getClient(id) : { name: "", phone: "", address: "", notes: "", authorizedPickups: "" };
    openModal(id ? "Editar cliente" : "Nuevo cliente", '<form class="form-grid"><label>Nombre<input name="name" required value="'.concat(escapeHtml(client.name), '" /></label><label>Teléfono WhatsApp<input name="phone" value="').concat(escapeHtml(client.phone), '" /></label><label>Dirección<input name="address" value="').concat(escapeHtml(client.address || ""), '" /></label><label class="full">Autorizados a retirar y celular de cada uno<textarea name="authorizedPickups" placeholder="Ej: Lucas Gómez - 11 5555-5555 (hijo)&#10;Ana Pérez - 11 4444-4444 (vecina)">').concat(escapeHtml(client.authorizedPickups || ""), '</textarea><small>Ingresá un autorizado por línea con su celular para poder contactarlo.</small></label><label class="full">Notas<input name="notes" value="').concat(escapeHtml(client.notes || ""), '" /></label><button class="primary full">Guardar cliente</button></form>'), function (form) {
        var data = formDataToObject(form);
        if (id)
            for (var key in data) { if (Object.prototype.hasOwnProperty.call(data, key)) client[key] = data[key]; }
        else
            state.clients.push(__assign({ id: nextId(state.clients) }, data));
        saveState();
        closeModal();
        render();
    });
}
function clientIdFromInput(form) {
    var input = form.querySelector("[data-client-autocomplete]");
    var value = input ? input.value : "";
    var normalized = value.toLowerCase();
    var matchedClientId = 0;
    var matchCount = 0;
    for (var index = 0; index < state.clients.length; index += 1) {
        var client = state.clients[index];
        var label = client.name + " · " + client.phone;
        if (value === label)
            return client.id;
        if (normalized && label.toLowerCase().indexOf(normalized) !== -1) {
            matchedClientId = client.id;
            matchCount += 1;
        }
    }
    return matchCount === 1 ? matchedClientId : 0;
}
function attachClientAutocomplete(modal) {
    var input = modal.querySelector("[data-client-autocomplete]");
    var hidden = modal.querySelector('[name="clientId"]');
    if (!input || !hidden)
        return;
    input.addEventListener("input", function () {
        hidden.value = "";
        var value = input.value;
        for (var index = 0; index < state.clients.length; index += 1) {
            var client = state.clients[index];
            if (value === client.name + " · " + client.phone) {
                hidden.value = client.id;
                return;
            }
        }
    });
}
function openOrderModal() {
    var defaultLocation = nextFreeLocation();
    var firstService = state.services[0];
    var modal = openModal("Nuevo pedido", '<form class="form-grid">\n    <label class="full">Cliente<input name="clientSearch" data-client-autocomplete list="clientOptions" placeholder="Escribí nombre o teléfono" required /><input name="clientId" type="hidden" /><datalist id="clientOptions">'.concat(state.clients.map(function (client) { return '<option value="'.concat(escapeHtml(client.name), ' · ').concat(escapeHtml(client.phone), '" data-id="').concat(client.id, '"></option>'); }).join(''), '</datalist></label>\n    <label>Depósito<select name="location" required>').concat(availableLocations().map(function (location) { return '<option '.concat(location.code === defaultLocation ? 'selected' : '', '>').concat(escapeHtml(location.code), '</option>'); }).join(''), '</select></label>\n    <label>Pago<select name="paymentStatus"><option>Pendiente</option><option>Abonado</option></select></label>\n    <label>Medio de pago<select name="paymentMethod"><option value="Efectivo">Efectivo</option><option value="Transferencia">Transferencia</option></select></label>\n    <div class="full items-builder"><h3>Prendas / trabajos</h3><div data-items-list>\n      ').concat(orderItemRow((firstService && firstService.id) || 1, (firstService && firstService.price) || 0, "", 1), '\n    </div><button class="secondary" type="button" data-add-item>+ Agregar prenda</button></div>\n    <label>Precio total<input name="total" data-items-total type="number" min="0" readonly value="').concat((firstService && firstService.price) || 0, '" /></label>\n    <label class="full">Observaciones<textarea name="notes" placeholder="Ej: Frasada polar roja, manchas, preferencias..."></textarea></label>\n    <button class="primary full">Crear pedido</button>\n  </form>'), function (form) {
        var data = formDataToObject(form);
        var selectedClientId = clientIdFromInput(form);
        if (!selectedClientId) {
            alert("Elegí un cliente válido de la lista.");
            return;
        }
        var createdAt = new Date().toISOString();
        var items = collectItems(form);
        var primaryService = getService((items[0] && items[0].serviceId) || (firstService && firstService.id));
        var schedule = createOrderSchedule(primaryService, createdAt);
        var orderId = nextId(state.orders);
        var location = data.location || nextFreeLocation();
        var total = orderItemsTotal(items);
        var order = { id: orderId, number: "", clientId: Number(selectedClientId), serviceId: Number(primaryService.id), createdAt: createdAt, retrievedAt: "", estimate: schedule.estimate, cycles: schedule.cycles, status: "Pendiente", items: items, total: total, location: location, notes: data.notes, paymentStatus: data.paymentStatus, paymentMethod: data.paymentMethod };
        ensureOrderCycleIds(order);
        order.number = orderDisplayCode(order);
        state.orders.push(order);
        if (order.paymentStatus === "Abonado")
            syncOrderPayment(order);
        saveState();
        closeModal();
        render();
    });
    attachClientAutocomplete(modal);
    attachItemBuilder(modal);
}
function orderItemRow(serviceId, price, name, quantity) {
    if (name === void 0) { name = ""; }
    if (quantity === void 0) { quantity = 1; }
    return "<div class=\"item-row\"><input name=\"itemQuantity\" type=\"number\" min=\"1\" value=\"".concat(Number(quantity || 1), "\" aria-label=\"Cantidad\" /><input name=\"itemName\" placeholder=\"Ej: Frasada polar roja\" value=\"").concat(escapeHtml(name), "\" /><select name=\"itemService\">").concat(state.services.map(function (service) { return "<option value=\"".concat(service.id, "\" data-price=\"").concat(service.price, "\" ").concat(Number(service.id) === Number(serviceId) ? "selected" : "", ">").concat(escapeHtml(service.name), "</option>"); }).join(""), "</select><input name=\"itemPrice\" type=\"number\" min=\"0\" value=\"").concat(Number(price || 0), "\" /><button class=\"danger\" type=\"button\" data-remove-item>×</button></div>");
}
function attachItemBuilder(modal) {
    var list = modal.querySelector("[data-items-list]");
    var recalc = function () {
        var total = collectItems(modal).reduce(function (sum, item) { return sum + itemLineTotal(item); }, 0);
        modal.querySelector("[data-items-total]").value = total;
    };
    modal.addEventListener("click", function (event) {
        if (event.target.matches("[data-add-item]")) {
            list.insertAdjacentHTML("beforeend", orderItemRow(state.services[0].id, state.services[0].price, "", 1));
            recalc();
        }
        if (event.target.matches("[data-remove-item]")) {
            var row = event.target.closest(".item-row");
            if (row)
                row.remove();
            recalc();
        }
    });
    modal.addEventListener("change", function (event) {
        if (event.target.matches('[name="itemService"]')) {
            var selectedOption = event.target.options[event.target.selectedIndex];
            var price = (selectedOption && selectedOption.getAttribute("data-price")) || 0;
            event.target.closest(".item-row").querySelector('[name="itemPrice"]').value = price;
            recalc();
        }
    });
    modal.addEventListener("input", function (event) { if (event.target.matches('[name="itemPrice"], [name="itemQuantity"]'))
        recalc(); });
}
function collectItems(form) {
    var rows = listFrom(form.querySelectorAll(".item-row"));
    return rows.map(function (row) {
        var serviceId = Number(row.querySelector('[name="itemService"]').value);
        var service = getService(serviceId);
        return { name: row.querySelector('[name="itemName"]').value || service.name, quantity: Number(row.querySelector('[name="itemQuantity"]').value || 1), serviceId: serviceId, serviceName: service.name, price: Number(row.querySelector('[name="itemPrice"]').value || 0) };
    }).filter(function (item) { return item.name || item.price; });
}
function syncOrderPayment(order, paymentDate) {
    var existing = state.cash.find(function (entry) { return entry.orderId === order.id && entry.category === "Pedido"; });
    if (order.paymentStatus !== "Abonado") {
        state.cash = state.cash.filter(function (entry) { return !(entry.orderId === order.id && entry.category === "Pedido"); });
        order.paymentSynced = false;
        return;
    }
    var payment = { type: "Ingreso", category: "Pedido", description: "".concat(orderClient(order), " ").concat(orderDisplayCode(order)), method: order.paymentMethod || "Efectivo", amount: order.total, orderId: order.id };
    if (existing) {
        for (var paymentKey in payment) { if (Object.prototype.hasOwnProperty.call(payment, paymentKey)) existing[paymentKey] = payment[paymentKey]; }
        if (paymentDate)
            existing.date = paymentDate;
    }
    else
        state.cash.push(__assign({ id: nextId(state.cash), date: paymentDate || new Date().toISOString() }, payment));
    order.paymentSynced = true;
}
function orderHistoryRows(orders) {
    return "<div class=\"history-list\">".concat(orders.map(function (order) { return "<article class=\"history-item\"><div><strong>".concat(escapeHtml(orderDisplayCode(order)), "</strong><small>Ingreso: ").concat(formatDateTime(order.createdAt), " · Retiro: ").concat(order.retrievedAt ? formatDateTime(order.retrievedAt) : "Pendiente", " · ").concat(escapeHtml(order.status), "</small></div><div>").concat(escapeHtml(itemSummary(order)), "</div><div><strong>").concat(money(order.total), "</strong> · ").concat(escapeHtml(order.paymentStatus || "Pendiente"), " · ").concat(escapeHtml(paymentMethodLabel(order.paymentMethod)), "</div><button class=\"secondary\" data-action=\"viewOrder\" data-id=\"").concat(order.id, "\">Ver</button></article>"); }).join("") || "<p>Este cliente todavía no tiene pedidos.</p>", "</div>");
}
function openClientHistoryModal(id) {
    var client = getClient(id);
    if (!client)
        return;
    var orders = operationalOrders().filter(function (order) { return order.clientId === Number(id); }).sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
    openModal("Historial de ".concat(escapeHtml(client.name)), orderHistoryRows(orders));
}
function orderDetailHtml(order) {
    return '<div class="order-detail"><p><strong>Cliente:</strong> '.concat(escapeHtml(orderClient(order)), '</p><p><strong>Depósito:</strong> ').concat(escapeHtml(order.location || "Sin asignar"), '</p><p><strong>Estado:</strong> ').concat(escapeHtml(order.status), '</p><p><strong>Pago:</strong> ').concat(escapeHtml(order.paymentStatus || "Pendiente"), ' · ').concat(escapeHtml(paymentMethodLabel(order.paymentMethod)), '</p><p><strong>Total:</strong> ').concat(money(order.total), '</p><p><strong>Ingreso:</strong> ').concat(formatDateTime(order.createdAt), '</p><p><strong>Retiro:</strong> ').concat(order.retrievedAt ? formatDateTime(order.retrievedAt) : "Pendiente", '</p><h3>Prendas / trabajos</h3><ul>').concat((order.items || []).map(function (item) { return '<li>'.concat(Number(item.quantity || 1), ' x ').concat(escapeHtml(item.name), ' · ').concat(escapeHtml(item.serviceName || ""), ' · ').concat(money(itemLineTotal(item)), '</li>'); }).join(""), '</ul>').concat('<p><strong>Observaciones:</strong> ').concat(escapeHtml(order.notes || "Sin observaciones"), '</p><div class="actions"><button class="secondary" data-action="editOrderStatus" data-id="').concat(order.id, '">Editar</button><button class="success" data-action="whatsapp" data-id="').concat(order.id, '">WhatsApp</button></div></div>');
}
function openOrderViewModal(id) {
    var order = getOrder(id);
    if (!order)
        return;
    openModal("Pedido ".concat(escapeHtml(orderDisplayCode(order))), orderDetailHtml(order));
}
function openOrderEditModal(id) {
    var order = getOrder(id);
    if (!order)
        return;
    var locations = availableLocations(order.id);
    if (order.location && !locations.some(function (location) { return location.code === order.location; }))
        locations.unshift({ id: 0, code: order.location });
    var modal = openModal("Editar pedido ".concat(escapeHtml(orderDisplayCode(order))), '<form class="form-grid">\n    <label>Depósito / número<select name="location"><option value="">Sin asignar</option>'.concat(locations.map(function (location) { return '<option '.concat(location.code === order.location ? 'selected' : '', '>').concat(escapeHtml(location.code), '</option>'); }).join(''), '</select></label>\n    <label>Pago<select name="paymentStatus"><option ').concat(order.paymentStatus !== "Abonado" ? 'selected' : '', '>Pendiente</option><option ').concat(order.paymentStatus === "Abonado" ? 'selected' : '', '>Abonado</option></select></label>\n    <label>Medio de pago<select name="paymentMethod"><option value="Efectivo" ').concat(order.paymentMethod !== "Transferencia" ? 'selected' : '', '>Efectivo</option><option value="Transferencia" ').concat(order.paymentMethod === "Transferencia" ? 'selected' : '', '>Transferencia</option></select></label>\n    <div class="full items-builder"><h3>Prendas / trabajos</h3><div data-items-list>').concat((order.items || []).map(function (item) { return orderItemRow(item.serviceId, item.price, item.name, item.quantity); }).join('') || orderItemRow(state.services[0].id, state.services[0].price, '', 1), '</div><button class="secondary" type="button" data-add-item>+ Agregar prenda</button></div>\n    <label>Precio total<input name="total" data-items-total type="number" min="0" readonly value="').concat(Number(order.total || 0), '" /></label>\n    <label class="full">Observaciones<textarea name="notes">').concat(escapeHtml(order.notes || ""), '</textarea></label>\n    <button class="primary full">Guardar cambios</button>\n  </form>'), function (form) {
        var data = formDataToObject(form);
        var items = collectItems(form);
        var primaryService = getService((items[0] && items[0].serviceId) || order.serviceId);
        order.location = data.location;
        order.number = orderDisplayCode(order);
        order.paymentStatus = data.paymentStatus;
        order.paymentMethod = data.paymentMethod;
        order.items = items;
        order.serviceId = Number(primaryService.id);
        order.total = orderItemsTotal(items);
        order.notes = data.notes;
        syncOrderPayment(order);
        saveState();
        closeModal();
        render();
    });
    attachItemBuilder(modal);
}
function openOrderStateModal(id) {
    var order = getOrder(id);
    if (!order)
        return;
    openModal("Cambiar estado ".concat(escapeHtml(orderDisplayCode(order))), "<form class=\"state-grid\">\n    ".concat(STATES.map(function (status) { return "<label class=\"state-option ".concat(status === order.status ? "selected" : "", "\"><input type=\"radio\" name=\"status\" value=\"").concat(status, "\" ").concat(status === order.status ? "checked" : "", " /> <span>").concat(status, "</span></label>"); }).join(""), "\n    <button class=\"primary full\">Guardar estado</button>\n  </form>"), function (form) {
        var data = formDataToObject(form);
        var previousStatus = order.status;
        order.status = data.status;
        if (order.status === "Retirado" && !order.retrievedAt)
            order.retrievedAt = new Date().toISOString();
        if (order.status !== "Retirado")
            order.retrievedAt = "";
        if (order.status === "Retirado") {
            order.wasPaidBeforeRetired = order.paymentStatus === "Abonado";
            order.paymentStatus = "Abonado";
            order.location = "";
            order.number = orderDisplayCode(order);
            syncOrderPayment(order);
        }
        else if (previousStatus === "Retirado") {
            order.location = "";
            order.number = orderDisplayCode(order);
            if (!order.wasPaidBeforeRetired)
                order.paymentStatus = "Pendiente";
            syncOrderPayment(order);
        }
        saveState();
        closeModal();
        render();
    });
}
function storageNoticeText(order) {
    if (order === void 0) { order = null; }
    var base = safeReplaceAll(state.settings.storageNoticeText, "{dias}", state.settings.storageNoticeDays);
    if (!order)
        return base;
    return "".concat(base, "\n\nPedido #").concat(orderDisplayCode(order), " - Cliente: ").concat(orderClient(order), " - Ubicaci\u00F3n: ").concat(order.location || "sin asignar", ".");
}
function sendWhatsapp(id, type) {
    var order = getOrder(id);
    var phone = ((getClient(order.clientId) && getClient(order.clientId).phone) || "").replace(/\D/g, "");
    window.open("https://wa.me/".concat(phone, "?text=").concat(encodeURIComponent(messageForOrder(order, type))), "_blank");
}
function openWhatsappMenu(id) {
    var order = getOrder(id);
    if (!order)
        return;
    var html = "<div class=\"message-list\">" +
        "<button class=\"secondary\" data-action=\"sendWhatsapp\" data-message-type=\"received\" data-id=\"" + order.id + "\">Recibimos tu pedido</button>" +
        "<button class=\"success\" data-action=\"sendWhatsapp\" data-message-type=\"ready\" data-id=\"" + order.id + "\">Tu pedido está listo</button>" +
        "<button class=\"secondary\" data-action=\"sendWhatsapp\" data-message-type=\"retired\" data-id=\"" + order.id + "\">Retiró su pedido</button>" +
        "<div class=\"copy-row\"><button class=\"secondary\" data-action=\"copyWhatsapp\" data-message-type=\"received\" data-id=\"" + order.id + "\">Copiar recibido</button><button class=\"secondary\" data-action=\"copyWhatsapp\" data-message-type=\"ready\" data-id=\"" + order.id + "\">Copiar listo</button><button class=\"secondary\" data-action=\"copyWhatsapp\" data-message-type=\"retired\" data-id=\"" + order.id + "\">Copiar retirado</button></div>" +
        "<p class=\"copy-status\" aria-live=\"polite\"></p>" +
        "<textarea readonly>" + escapeHtml(messageForOrder(order, "ready")) + "</textarea></div>";
    openModal("Mensajes WhatsApp #".concat(escapeHtml(orderDisplayCode(order))), html);
}
function copyWhatsapp(id, type) {
    if (type === void 0) { type = "ready"; }
    var order = getOrder(id);
    if (!order)
        return;
    var text = messageForOrder(order, type);
    var status = document.querySelector(".copy-status");
    function notify() {
        if (status)
            status.textContent = "Mensaje copiado: " + (type === "received" ? "recibido" : type === "retired" ? "retirado" : "listo");
    }
    if (window.navigator && navigator.clipboard && navigator.clipboard.writeText) {
        var result = navigator.clipboard.writeText(text);
        if (result && result.then)
            result.then(notify, function () { prompt("Copiá el mensaje para WhatsApp", text); notify(); });
        else
            notify();
    }
    else {
        prompt("Copiá el mensaje para WhatsApp", text);
        notify();
    }
}
function openStorageNoticeModal(id) {
    var order = id ? getOrder(id) : null;
    var text = storageNoticeText(order);
    openModal(order ? "Cartel dep\u00F3sito #".concat(escapeHtml(orderDisplayCode(order))) : "Cartel general de depósito", "\n    <textarea class=\"notice-text\" readonly>".concat(escapeHtml(text), "</textarea>\n    <div class=\"actions\"><button class=\"primary\" data-action=\"copyNotice\">Copiar cartel</button>").concat(order ? "<button class=\"success\" data-action=\"sendStorageNotice\" data-id=\"".concat(order.id, "\">Enviar al cliente</button>") : "", "</div>"));
}
function copyVisibleNotice() {
    var text = (document.querySelector(".notice-text") && document.querySelector(".notice-text").value) || "";
    if (navigator.clipboard)
        navigator.clipboard.writeText(text);
    else
        prompt("Copiá el cartel", text);
    alert("Cartel copiado/preparado.");
}
function sendStorageNotice(id) {
    var order = getOrder(id);
    var phone = ((getClient(order.clientId) && getClient(order.clientId).phone) || "").replace(/\D/g, "");
    window.open("https://wa.me/".concat(phone, "?text=").concat(encodeURIComponent(storageNoticeText(order))), "_blank");
}
function unlockCash() {
    var pinInput = document.getElementById("cashPinUnlock");
    cashUnlocked = pinInput && pinInput.value === state.settings.cashPin;
    if (!cashUnlocked)
        alert("Clave incorrecta");
    render();
}
function unlockBusinessExpenses() {
    businessExpensesUnlocked = true;
    render();
}
function openCashModal(type) {
    if (type === "Egreso") {
        openModal("Egreso de caja", '<form class="form-grid"><label class="full">Nombre / concepto<input name="description" required placeholder="Ej: Luz, bolsas, arreglo de máquina" /></label><label class="full">Valor / monto<input name="amount" type="number" min="0" step="0.01" required /></label><button class="primary full">Guardar egreso</button></form>', function (form) {
            var data = formDataToObject(form);
            state.cash.push({ id: nextId(state.cash), type: "Egreso", date: new Date().toISOString(), category: "Egreso", description: data.description, method: "Efectivo", amount: Number(data.amount || 0) });
            saveState();
            closeModal();
            render();
        });
        return;
    }
    var categories = ["Pedido", "Seña", "Otro"];
    openModal("Ingreso de caja", '<form class="form-grid"><label>Categoría<select name="category">' + categories.map(function (category) { return "<option>" + escapeHtml(category) + "</option>"; }).join("") + '</select></label><label>Medio<select name="method"><option value="Efectivo">Efectivo</option><option value="Transferencia">Transferencia</option></select></label><label>Importe<input name="amount" type="number" min="0" required /></label><label>Descripción<input name="description" required /></label><button class="primary full">Guardar ingreso</button></form>', function (form) {
        var data = formDataToObject(form);
        state.cash.push(__assign({ id: nextId(state.cash), type: "Ingreso", date: new Date().toISOString() }, data));
        saveState();
        closeModal();
        render();
    });
}
function closeCashDay() {
    if (!state.cash.length) {
        alert("La caja diaria ya está vacía.");
        return;
    }
    if (!confirm("¿Empezar nuevo día? Se guardará la caja actual en el histórico y la caja diaria quedará en cero."))
        return;
    var income = state.cash.filter(function (entry) { return entry.type === "Ingreso"; }).reduce(function (sum, entry) { return sum + Number(entry.amount || 0); }, 0);
    var expense = state.cash.filter(function (entry) { return entry.type === "Egreso"; }).reduce(function (sum, entry) { return sum + Number(entry.amount || 0); }, 0);
    state.cashHistory = state.cashHistory || [];
    state.cashHistory.push({ id: nextId(state.cashHistory), closedAt: new Date().toISOString(), entries: cloneData(state.cash), income: income, expense: expense, balance: income - expense });
    state.cash = [];
    saveState();
    render();
}
function csvEscape(value) {
    return '"' + safeReplaceAll(String(value == null ? "" : value), '"', '""') + '"';
}
function cashExportRows(entries) {
    var rows = [["Cierre", "Fecha movimiento", "Tipo", "Categoría", "Descripción", "Medio", "Importe"]];
    entries.forEach(function (entry) { rows.push([entry.closedAt === "Caja actual" ? "Caja actual" : formatDateTime(entry.closedAt), formatDateTime(entry.date), entry.type, entry.category, entry.description, paymentMethodLabel(entry.method), signedCashAmount(entry)]); });
    return rows;
}
function downloadCsv(rows, fileName, label) {
    var csv = rows.map(function (row) { return row.map(csvEscape).join(";"); }).join("\n");
    if (window.Blob && window.URL && document.createElement) {
        var blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
        var link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        alert(label + " exportada como " + fileName + ". Se guarda en Descargas o en la ubicación configurada por tu navegador.");
    }
    else {
        prompt("Copiá este CSV y guardalo como " + fileName, csv);
    }
}
function exportHistoricalCash() {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
    downloadCsv(cashExportRows(historicalCashRows()), "caja-historica-" + localDateInput() + ".csv", "Caja histórica compatible con hoja de cálculo");
}
function exportGlobalTurnHistory() {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
    var rows = [["Fecha de modificación", "Fecha agendada", "Pedido", "Cliente", "Tipo", "Máquina", "Inicio", "Fin", "Nota"]];
    scheduleHistoryRows(calendarScheduleCycles()).forEach(function (cycle) {
        rows.push([formatShortDateTime(cycleModifiedAt(cycle)), formatShortDateTime(cycle.start).slice(0, 8), orderDisplayCode(cycle.order), orderClient(cycle.order), cycle.type, canonicalMachineName(cycle.machine) || "Sin máquina asignada", formatShortDateTime(cycle.start).slice(-5), formatShortDateTime(cycle.end).slice(-5), cycle.description || (cycle.pendingMachine ? "Pendiente de asignar" : "-")]);
    });
    downloadCsv(rows, "historial-turnos-" + localDateInput() + ".csv", "Historial global de turnos compatible con hoja de cálculo");
}
function exportMonthlyCash(month) {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
    var selectedMonth = month || selectedMetricsMonth || localDateInput().slice(0, 7);
    var rows = cashRowsForMonth(selectedMonth);
    downloadCsv(cashExportRows(rows), "caja-mensual-" + selectedMonth + ".csv", "Caja mensual " + selectedMonth);
}
function csvRows(text) {
    var rows = [];
    var row = [];
    var value = "";
    var quoted = false;
    for (var index = 0; index < text.length; index += 1) {
        var character = text.charAt(index);
        var next = text.charAt(index + 1);
        if (quoted) {
            if (character === '"' && next === '"') {
                value += '"';
                index += 1;
            }
            else if (character === '"')
                quoted = false;
            else
                value += character;
        }
        else if (character === '"')
            quoted = true;
        else if (character === ";" || character === ",") {
            row.push(value);
            value = "";
        }
        else if (character === "\n") {
            row.push(value);
            rows.push(row);
            row = [];
            value = "";
        }
        else if (character !== "\r")
            value += character;
    }
    row.push(value);
    rows.push(row);
    return rows.filter(function (csvRow) { return csvRow.join("").trim(); });
}
function headerIndex(headers, names) {
    for (var index = 0; index < headers.length; index += 1) {
        var header = headers[index].toLowerCase().trim();
        for (var nameIndex = 0; nameIndex < names.length; nameIndex += 1) {
            if (header === names[nameIndex])
                return index;
        }
    }
    return -1;
}
function csvValue(row, headers, names) {
    var index = headerIndex(headers, names);
    return index >= 0 ? row[index] || "" : "";
}
function importClientsCsv(rows) {
    var headers = rows[0] || [];
    var added = 0;
    for (var rowIndex = 1; rowIndex < rows.length; rowIndex += 1) {
        var row = rows[rowIndex];
        var name = csvValue(row, headers, ["nombre", "name", "cliente", "client"]);
        var phone = csvValue(row, headers, ["telefono", "teléfono", "phone", "whatsapp", "celular"]);
        if (!name || !phone)
            continue;
        var exists = state.clients.some(function (client) { return client.phone === phone; });
        if (exists)
            continue;
        state.clients.push({ id: nextId(state.clients), name: name, phone: phone, address: csvValue(row, headers, ["direccion", "dirección", "address"]), notes: csvValue(row, headers, ["notas", "notes"]), authorizedPickups: csvValue(row, headers, ["autorizados", "authorizedpickups", "retira"]) });
        added += 1;
    }
    return added;
}
function findOrCreateClient(name, phone) {
    var cleanPhone = phone || "Sin teléfono";
    for (var index = 0; index < state.clients.length; index += 1) {
        if (state.clients[index].phone === cleanPhone || state.clients[index].name === name)
            return state.clients[index];
    }
    var client = { id: nextId(state.clients), name: name || "Cliente CSV", phone: cleanPhone, address: "", notes: "Importado por CSV", authorizedPickups: "" };
    state.clients.push(client);
    return client;
}
function importOrdersCsv(rows) {
    var headers = rows[0] || [];
    var added = 0;
    for (var rowIndex = 1; rowIndex < rows.length; rowIndex += 1) {
        var row = rows[rowIndex];
        var client = findOrCreateClient(csvValue(row, headers, ["cliente", "client", "nombre", "name"]), csvValue(row, headers, ["telefono", "teléfono", "phone", "whatsapp"]));
        var service = state.services[0];
        var quantity = Number(csvValue(row, headers, ["cantidad", "quantity", "qty"]) || 1);
        var price = Number(csvValue(row, headers, ["precio", "price", "importe", "amount"]) || service.price || 0);
        var itemName = csvValue(row, headers, ["prenda", "item", "itemname", "trabajo"]) || service.name;
        var createdAt = parseCsvDateValue(csvValue(row, headers, ["fecha_ingreso", "fecha ingreso", "ingreso", "createdat", "created_at", "date"]), new Date().toISOString());
        var rawStatus = csvValue(row, headers, ["estado", "status"]);
        var status = normalizeOrderStatus(rawStatus || "Pendiente", true);
        var retrievedAt = parseCsvDateValue(csvValue(row, headers, ["fecha_retiro", "fecha retiro", "retiro", "retrievedat", "retrieved_at"]), "");
        var schedule = createOrderSchedule(service, createdAt);
        var orderId = nextId(state.orders);
        var location = csvValue(row, headers, ["deposito", "depósito", "location"]);
        if (!location && status !== "Retirado")
            location = nextFreeLocation();
        var items = [{ name: itemName, quantity: quantity || 1, serviceId: service.id, serviceName: service.name, price: price }];
        var order = { id: orderId, number: "", clientId: client.id, serviceId: service.id, createdAt: createdAt, retrievedAt: retrievedAt, estimate: retrievedAt || schedule.estimate, cycles: schedule.cycles, status: status, items: items, total: orderItemsTotal(items), location: status === "Retirado" ? "" : location, notes: csvValue(row, headers, ["notas", "notes", "observaciones"]), paymentStatus: normalizePaymentStatus(csvValue(row, headers, ["pago", "paymentstatus", "payment_status"])), paymentMethod: normalizePaymentMethod(csvValue(row, headers, ["medio", "paymentmethod", "payment_method"])) };
        if (order.status === "Retirado" && !order.retrievedAt)
            order.retrievedAt = createdAt;
        ensureOrderCycleIds(order);
        order.number = orderDisplayCode(order);
        state.orders.push(order);
        if (order.paymentStatus === "Abonado")
            syncOrderPayment(order, order.retrievedAt || order.createdAt);
        added += 1;
    }
    return added;
}
function importCsvData() {
    if (!isDevAdmin()) { alert("Esta acción está reservada para soporte técnico."); return; }
    var fileInput = document.getElementById("csvImportFile");
    var typeInput = document.getElementById("csvImportType");
    var file = fileInput && fileInput.files && fileInput.files[0];
    if (!file || !window.FileReader) {
        alert("Elegí un archivo CSV para importar.");
        return;
    }
    var reader = new FileReader();
    reader.onload = function () {
        var rows = csvRows(String(reader.result || ""));
        if (!rows.length) {
            alert("El CSV está vacío o no se pudo leer.");
            return;
        }
        var imported = typeInput && typeInput.value === "orders" ? importOrdersCsv(rows) : importClientsCsv(rows);
        saveState();
        render();
        alert("Importación CSV completa: " + imported + " registros agregados.");
    };
    reader.readAsText(file);
}
function saveSettings() {
    if (!isAdmin()) { alert("Acceso restringido: necesitás rol Administrador."); return; }
        ["openHour", "closeHour", "whatsappReceivedMessage", "whatsappMessage", "whatsappRetiredMessage", "storageNoticeText", "cashPin", "adminPin", "employeePin", "deleteOrdersPin"].forEach(function (key) { var field = document.getElementById(key); if (field) state.settings[key] = field.value; });
    ["smallWashers", "largeWashers", "dryers", "washingMinutes", "dryingMinutes", "storageNoticeDays"].forEach(function (key) { return state.settings[key] = Number(document.getElementById(key).value); });
    (state.services || []).forEach(function (service) {
        var field = document.getElementById("servicePrice_" + service.id);
        if (field)
            service.price = Number(field.value || 0);
    });
    applyThemePreference();
    if (!isViewAllowed(currentView))
        currentView = fallbackViewForRole();
    saveState();
    alert("Configuración guardada con éxito.");
    render();
}
function resetDemo() {
    if (!isDevAdmin()) { alert("Esta acción está reservada para soporte técnico."); return; }
    if (!confirm("¿Reiniciar datos de demostración?"))
        return;
    state = cloneData(defaultData);
    cashUnlocked = false;
    businessExpensesUnlocked = true;
    adminOrdersUnlocked = false;
    sessionLoggedIn = false;
    sessionRole = "";
    sessionIsDev = false;
    applyThemePreference();
    saveState();
    render();
}
applyThemePreference();
updateBranding();
setupSystemThemeListener();
render();
setInterval(function () { checkMaintenanceAlerts(false); }, 5000);
appStarted = true;
